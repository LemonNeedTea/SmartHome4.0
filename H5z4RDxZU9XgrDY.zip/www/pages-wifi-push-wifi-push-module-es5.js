(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-wifi-push-wifi-push-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/pages/wifi-push/wifi-push.page.html":
/*!*******************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/pages/wifi-push/wifi-push.page.html ***!
  \*******************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n  <ion-toolbar color=\"light\">\n    <ion-buttons slot=\"start\">\n      <ion-back-button></ion-back-button>\n    </ion-buttons>\n    <ion-title>连接设备</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content padding>\n  <div class=\"wifi-icon\">\n    <ion-icon name=\"wifi\"></ion-icon>\n  </div>\n<div style=\"width: 100%;height: 100px;\">\n  <div class=\"loader\">\n    <div class=\"loading-3\">\n      <i></i>\n      <i></i>\n      <i></i>\n      <i></i>\n      <i></i>\n      <i></i>\n      <i></i>\n      <i></i>\n    </div>\n  </div>\n</div>\n  <div class=\"loading-div\">\n    <!-- Crescent -->\n\n    <ion-text class=\"text1\">正在发送信息给设备...</ion-text>\n    <ion-text color='medium' class=\"text2\">请将手机靠近设备与路由器</ion-text>\n\n  </div>\n</ion-content>"

/***/ }),

/***/ "./src/app/pages/wifi-push/wifi-push-routing.module.ts":
/*!*************************************************************!*\
  !*** ./src/app/pages/wifi-push/wifi-push-routing.module.ts ***!
  \*************************************************************/
/*! exports provided: WifiPushPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "WifiPushPageRoutingModule", function() { return WifiPushPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _wifi_push_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./wifi-push.page */ "./src/app/pages/wifi-push/wifi-push.page.ts");




var routes = [
    {
        path: '',
        component: _wifi_push_page__WEBPACK_IMPORTED_MODULE_3__["WifiPushPage"]
    }
];
var WifiPushPageRoutingModule = /** @class */ (function () {
    function WifiPushPageRoutingModule() {
    }
    WifiPushPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
        })
    ], WifiPushPageRoutingModule);
    return WifiPushPageRoutingModule;
}());



/***/ }),

/***/ "./src/app/pages/wifi-push/wifi-push.module.ts":
/*!*****************************************************!*\
  !*** ./src/app/pages/wifi-push/wifi-push.module.ts ***!
  \*****************************************************/
/*! exports provided: WifiPushPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "WifiPushPageModule", function() { return WifiPushPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _wifi_push_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./wifi-push-routing.module */ "./src/app/pages/wifi-push/wifi-push-routing.module.ts");
/* harmony import */ var _wifi_push_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./wifi-push.page */ "./src/app/pages/wifi-push/wifi-push.page.ts");







var WifiPushPageModule = /** @class */ (function () {
    function WifiPushPageModule() {
    }
    WifiPushPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
                _wifi_push_routing_module__WEBPACK_IMPORTED_MODULE_5__["WifiPushPageRoutingModule"]
            ],
            declarations: [_wifi_push_page__WEBPACK_IMPORTED_MODULE_6__["WifiPushPage"]]
        })
    ], WifiPushPageModule);
    return WifiPushPageModule;
}());



/***/ }),

/***/ "./src/app/pages/wifi-push/wifi-push.page.scss":
/*!*****************************************************!*\
  !*** ./src/app/pages/wifi-push/wifi-push.page.scss ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "@charset \"UTF-8\";\n.wifi-icon {\n  font-size: 130px;\n  text-align: center;\n}\n.loading-div {\n  text-align: center;\n}\n.loading-div .text1 {\n  display: block;\n  font-size: 16px;\n}\n.loading-div .text2 {\n  font-size: 12px;\n}\n.loader {\n  width: 100%;\n  height: 100px;\n  box-sizing: border-box;\n  display: -webkit-box;\n  display: flex;\n  /*多轮布局*/\n  -webkit-box-align: center;\n          align-items: center;\n  /*垂直*/\n  -webkit-box-pack: center;\n          justify-content: center;\n  /*水平*/\n}\n@-webkit-keyframes loading-3 {\n  50% {\n    -webkit-transform: scale(0.4);\n            transform: scale(0.4);\n    opacity: 0.4;\n  }\n  100% {\n    -webkit-transform: scale(1);\n            transform: scale(1);\n    opacity: 1;\n  }\n}\n.loading-3 {\n  position: relative;\n}\n.loading-3 i {\n  display: block;\n  width: 15px;\n  height: 15px;\n  border-radius: 50%;\n  background-color: #333;\n  position: absolute;\n}\n.loading-3 i:nth-child(1) {\n  top: 25px;\n  left: 0;\n  -webkit-animation: loading-3 1s ease 0s infinite;\n}\n.loading-3 i:nth-child(2) {\n  top: 17px;\n  left: 17px;\n  -webkit-animation: loading-3 1s ease -0.12s infinite;\n}\n.loading-3 i:nth-child(3) {\n  top: 0px;\n  left: 25px;\n  -webkit-animation: loading-3 1s ease -0.24s infinite;\n}\n.loading-3 i:nth-child(4) {\n  top: -17px;\n  left: 17px;\n  -webkit-animation: loading-3 1s ease -0.36s infinite;\n}\n.loading-3 i:nth-child(5) {\n  top: -25px;\n  left: 0;\n  -webkit-animation: loading-3 1s ease -0.48s infinite;\n}\n.loading-3 i:nth-child(6) {\n  top: -17px;\n  left: -17px;\n  -webkit-animation: loading-3 1s ease -0.6s infinite;\n}\n.loading-3 i:nth-child(7) {\n  top: 0px;\n  left: -25px;\n  -webkit-animation: loading-3 1s ease -0.72s infinite;\n}\n.loading-3 i:nth-child(8) {\n  top: 17px;\n  left: -17px;\n  -webkit-animation: loading-3 1s ease -0.84s infinite;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvd2lmaS1wdXNoL3dpZmktcHVzaC5wYWdlLnNjc3MiLCIvVXNlcnMvemhvdWJvL1Byb2plY3QvU21hcnRIb21lNC4wL3NyYy9hcHAvcGFnZXMvd2lmaS1wdXNoL3dpZmktcHVzaC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsZ0JBQWdCO0FDQWhCO0VBQ0UsZ0JBQUE7RUFDQSxrQkFBQTtBREVGO0FDQUE7RUFDRSxrQkFBQTtBREdGO0FDREE7RUFDRSxjQUFBO0VBQ0EsZUFBQTtBRElGO0FDRkE7RUFDRSxlQUFBO0FES0Y7QUNIQTtFQUNFLFdBQUE7RUFDQSxhQUFBO0VBS0Esc0JBQUE7RUFDQSxvQkFBQTtFQUFBLGFBQUE7RUFBZSxPQUFBO0VBQ2YseUJBQUE7VUFBQSxtQkFBQTtFQUFxQixLQUFBO0VBQ3JCLHdCQUFBO1VBQUEsdUJBQUE7RUFBeUIsS0FBQTtBREszQjtBQ0ZBO0VBQ0U7SUFDRSw2QkFBQTtZQUFBLHFCQUFBO0lBQ0EsWUFBQTtFREtGO0VDSEE7SUFDRSwyQkFBQTtZQUFBLG1CQUFBO0lBQ0EsVUFBQTtFREtGO0FBQ0Y7QUNIQTtFQUNFLGtCQUFBO0FES0Y7QUNIQTtFQUNFLGNBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0VBQ0Esc0JBQUE7RUFDQSxrQkFBQTtBRE1GO0FDSkE7RUFDRSxTQUFBO0VBQ0EsT0FBQTtFQUNBLGdEQUFBO0FET0Y7QUNMQTtFQUNFLFNBQUE7RUFDQSxVQUFBO0VBQ0Esb0RBQUE7QURRRjtBQ05BO0VBQ0UsUUFBQTtFQUNBLFVBQUE7RUFDQSxvREFBQTtBRFNGO0FDUEE7RUFDRSxVQUFBO0VBQ0EsVUFBQTtFQUNBLG9EQUFBO0FEVUY7QUNSQTtFQUNFLFVBQUE7RUFDQSxPQUFBO0VBQ0Esb0RBQUE7QURXRjtBQ1RBO0VBQ0UsVUFBQTtFQUNBLFdBQUE7RUFDQSxtREFBQTtBRFlGO0FDVkE7RUFDRSxRQUFBO0VBQ0EsV0FBQTtFQUNBLG9EQUFBO0FEYUY7QUNYQTtFQUNFLFNBQUE7RUFDQSxXQUFBO0VBQ0Esb0RBQUE7QURjRiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL3dpZmktcHVzaC93aWZpLXB1c2gucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiQGNoYXJzZXQgXCJVVEYtOFwiO1xuLndpZmktaWNvbiB7XG4gIGZvbnQtc2l6ZTogMTMwcHg7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbn1cblxuLmxvYWRpbmctZGl2IHtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xufVxuXG4ubG9hZGluZy1kaXYgLnRleHQxIHtcbiAgZGlzcGxheTogYmxvY2s7XG4gIGZvbnQtc2l6ZTogMTZweDtcbn1cblxuLmxvYWRpbmctZGl2IC50ZXh0MiB7XG4gIGZvbnQtc2l6ZTogMTJweDtcbn1cblxuLmxvYWRlciB7XG4gIHdpZHRoOiAxMDAlO1xuICBoZWlnaHQ6IDEwMHB4O1xuICBib3gtc2l6aW5nOiBib3JkZXItYm94O1xuICBkaXNwbGF5OiBmbGV4O1xuICAvKuWkmui9ruW4g+WxgCovXG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIC8q5Z6C55u0Ki9cbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gIC8q5rC05bmzKi9cbn1cblxuQC13ZWJraXQta2V5ZnJhbWVzIGxvYWRpbmctMyB7XG4gIDUwJSB7XG4gICAgdHJhbnNmb3JtOiBzY2FsZSgwLjQpO1xuICAgIG9wYWNpdHk6IDAuNDtcbiAgfVxuICAxMDAlIHtcbiAgICB0cmFuc2Zvcm06IHNjYWxlKDEpO1xuICAgIG9wYWNpdHk6IDE7XG4gIH1cbn1cbi5sb2FkaW5nLTMge1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG59XG5cbi5sb2FkaW5nLTMgaSB7XG4gIGRpc3BsYXk6IGJsb2NrO1xuICB3aWR0aDogMTVweDtcbiAgaGVpZ2h0OiAxNXB4O1xuICBib3JkZXItcmFkaXVzOiA1MCU7XG4gIGJhY2tncm91bmQtY29sb3I6ICMzMzM7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbn1cblxuLmxvYWRpbmctMyBpOm50aC1jaGlsZCgxKSB7XG4gIHRvcDogMjVweDtcbiAgbGVmdDogMDtcbiAgLXdlYmtpdC1hbmltYXRpb246IGxvYWRpbmctMyAxcyBlYXNlIDBzIGluZmluaXRlO1xufVxuXG4ubG9hZGluZy0zIGk6bnRoLWNoaWxkKDIpIHtcbiAgdG9wOiAxN3B4O1xuICBsZWZ0OiAxN3B4O1xuICAtd2Via2l0LWFuaW1hdGlvbjogbG9hZGluZy0zIDFzIGVhc2UgLTAuMTJzIGluZmluaXRlO1xufVxuXG4ubG9hZGluZy0zIGk6bnRoLWNoaWxkKDMpIHtcbiAgdG9wOiAwcHg7XG4gIGxlZnQ6IDI1cHg7XG4gIC13ZWJraXQtYW5pbWF0aW9uOiBsb2FkaW5nLTMgMXMgZWFzZSAtMC4yNHMgaW5maW5pdGU7XG59XG5cbi5sb2FkaW5nLTMgaTpudGgtY2hpbGQoNCkge1xuICB0b3A6IC0xN3B4O1xuICBsZWZ0OiAxN3B4O1xuICAtd2Via2l0LWFuaW1hdGlvbjogbG9hZGluZy0zIDFzIGVhc2UgLTAuMzZzIGluZmluaXRlO1xufVxuXG4ubG9hZGluZy0zIGk6bnRoLWNoaWxkKDUpIHtcbiAgdG9wOiAtMjVweDtcbiAgbGVmdDogMDtcbiAgLXdlYmtpdC1hbmltYXRpb246IGxvYWRpbmctMyAxcyBlYXNlIC0wLjQ4cyBpbmZpbml0ZTtcbn1cblxuLmxvYWRpbmctMyBpOm50aC1jaGlsZCg2KSB7XG4gIHRvcDogLTE3cHg7XG4gIGxlZnQ6IC0xN3B4O1xuICAtd2Via2l0LWFuaW1hdGlvbjogbG9hZGluZy0zIDFzIGVhc2UgLTAuNnMgaW5maW5pdGU7XG59XG5cbi5sb2FkaW5nLTMgaTpudGgtY2hpbGQoNykge1xuICB0b3A6IDBweDtcbiAgbGVmdDogLTI1cHg7XG4gIC13ZWJraXQtYW5pbWF0aW9uOiBsb2FkaW5nLTMgMXMgZWFzZSAtMC43MnMgaW5maW5pdGU7XG59XG5cbi5sb2FkaW5nLTMgaTpudGgtY2hpbGQoOCkge1xuICB0b3A6IDE3cHg7XG4gIGxlZnQ6IC0xN3B4O1xuICAtd2Via2l0LWFuaW1hdGlvbjogbG9hZGluZy0zIDFzIGVhc2UgLTAuODRzIGluZmluaXRlO1xufSIsIi53aWZpLWljb24ge1xuICBmb250LXNpemU6IDEzMHB4O1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG59XG4ubG9hZGluZy1kaXYge1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG59XG4ubG9hZGluZy1kaXYgLnRleHQxIHtcbiAgZGlzcGxheTogYmxvY2s7XG4gIGZvbnQtc2l6ZTogMTZweDtcbn1cbi5sb2FkaW5nLWRpdiAudGV4dDIge1xuICBmb250LXNpemU6IDEycHg7XG59XG4ubG9hZGVyIHtcbiAgd2lkdGg6IDEwMCU7XG4gIGhlaWdodDogMTAwcHg7XG4gIC8vIG1hcmdpbi1ib3R0b206IDIwcHg7XG4gIC8vIGZsb2F0OiBsZWZ0O1xuICAvLyBtYXJnaW4tbGVmdDogMyU7XG4gIC8vIGJvcmRlcjogMXB4IHNvbGlkICNjY2M7XG4gIGJveC1zaXppbmc6IGJvcmRlci1ib3g7XG4gIGRpc3BsYXk6IGZsZXg7IC8q5aSa6L2u5biD5bGAKi9cbiAgYWxpZ24taXRlbXM6IGNlbnRlcjsgLyrlnoLnm7QqL1xuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjsgLyrmsLTlubMqL1xufVxuXG5ALXdlYmtpdC1rZXlmcmFtZXMgbG9hZGluZy0zIHtcbiAgNTAlIHtcbiAgICB0cmFuc2Zvcm06IHNjYWxlKDAuNCk7XG4gICAgb3BhY2l0eTogMC40O1xuICB9XG4gIDEwMCUge1xuICAgIHRyYW5zZm9ybTogc2NhbGUoMSk7XG4gICAgb3BhY2l0eTogMTtcbiAgfVxufVxuLmxvYWRpbmctMyB7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbn1cbi5sb2FkaW5nLTMgaSB7XG4gIGRpc3BsYXk6IGJsb2NrO1xuICB3aWR0aDogMTVweDtcbiAgaGVpZ2h0OiAxNXB4O1xuICBib3JkZXItcmFkaXVzOiA1MCU7XG4gIGJhY2tncm91bmQtY29sb3I6ICMzMzM7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbn1cbi5sb2FkaW5nLTMgaTpudGgtY2hpbGQoMSkge1xuICB0b3A6IDI1cHg7XG4gIGxlZnQ6IDA7XG4gIC13ZWJraXQtYW5pbWF0aW9uOiBsb2FkaW5nLTMgMXMgZWFzZSAwcyBpbmZpbml0ZTtcbn1cbi5sb2FkaW5nLTMgaTpudGgtY2hpbGQoMikge1xuICB0b3A6IDE3cHg7XG4gIGxlZnQ6IDE3cHg7XG4gIC13ZWJraXQtYW5pbWF0aW9uOiBsb2FkaW5nLTMgMXMgZWFzZSAtMC4xMnMgaW5maW5pdGU7XG59XG4ubG9hZGluZy0zIGk6bnRoLWNoaWxkKDMpIHtcbiAgdG9wOiAwcHg7XG4gIGxlZnQ6IDI1cHg7XG4gIC13ZWJraXQtYW5pbWF0aW9uOiBsb2FkaW5nLTMgMXMgZWFzZSAtMC4yNHMgaW5maW5pdGU7XG59XG4ubG9hZGluZy0zIGk6bnRoLWNoaWxkKDQpIHtcbiAgdG9wOiAtMTdweDtcbiAgbGVmdDogMTdweDtcbiAgLXdlYmtpdC1hbmltYXRpb246IGxvYWRpbmctMyAxcyBlYXNlIC0wLjM2cyBpbmZpbml0ZTtcbn1cbi5sb2FkaW5nLTMgaTpudGgtY2hpbGQoNSkge1xuICB0b3A6IC0yNXB4O1xuICBsZWZ0OiAwO1xuICAtd2Via2l0LWFuaW1hdGlvbjogbG9hZGluZy0zIDFzIGVhc2UgLTAuNDhzIGluZmluaXRlO1xufVxuLmxvYWRpbmctMyBpOm50aC1jaGlsZCg2KSB7XG4gIHRvcDogLTE3cHg7XG4gIGxlZnQ6IC0xN3B4O1xuICAtd2Via2l0LWFuaW1hdGlvbjogbG9hZGluZy0zIDFzIGVhc2UgLTAuNnMgaW5maW5pdGU7XG59XG4ubG9hZGluZy0zIGk6bnRoLWNoaWxkKDcpIHtcbiAgdG9wOiAwcHg7XG4gIGxlZnQ6IC0yNXB4O1xuICAtd2Via2l0LWFuaW1hdGlvbjogbG9hZGluZy0zIDFzIGVhc2UgLTAuNzJzIGluZmluaXRlO1xufVxuLmxvYWRpbmctMyBpOm50aC1jaGlsZCg4KSB7XG4gIHRvcDogMTdweDtcbiAgbGVmdDogLTE3cHg7XG4gIC13ZWJraXQtYW5pbWF0aW9uOiBsb2FkaW5nLTMgMXMgZWFzZSAtMC44NHMgaW5maW5pdGU7XG59XG4iXX0= */"

/***/ }),

/***/ "./src/app/pages/wifi-push/wifi-push.page.ts":
/*!***************************************************!*\
  !*** ./src/app/pages/wifi-push/wifi-push.page.ts ***!
  \***************************************************/
/*! exports provided: WifiPushPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "WifiPushPage", function() { return WifiPushPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _services_esptouch_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../services/esptouch.service */ "./src/app/services/esptouch.service.ts");
/* harmony import */ var _services_tools_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../services/tools.service */ "./src/app/services/tools.service.ts");
/* harmony import */ var _services_request_device_request_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../services/request/device-request.service */ "./src/app/services/request/device-request.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");







var WifiPushPage = /** @class */ (function () {
    function WifiPushPage(route, router, esptouch, actionSheetController, device, navCtrl, tools, alertController) {
        this.route = route;
        this.router = router;
        this.esptouch = esptouch;
        this.actionSheetController = actionSheetController;
        this.device = device;
        this.navCtrl = navCtrl;
        this.tools = tools;
        this.alertController = alertController;
        this.queryParams = this.route.snapshot.queryParams; // queryParams.wifi queryParams.password
    }
    WifiPushPage.prototype.ngOnInit = function () {
        var _this = this;
        this.esptouch.start(this.queryParams.ssid, this.queryParams.password).then(function (res) {
            var bssidArr = [];
            if (res.length && res.length > 0) { // 返回超过一个设备
            }
            else if (res) {
                _this.addDevice(res.bssid);
            }
        }, function (err) {
            _this.esptouch.close();
            _this.presentActionSheet();
        }).catch(function (res) {
            _this.esptouch.close();
            _this.presentActionSheet();
        });
    };
    WifiPushPage.prototype.presentAlertPrompt = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                return [2 /*return*/, new Promise(function (resolve, reject) {
                        _this.alertController.create({
                            header: '设备名称',
                            inputs: [
                                {
                                    name: 'name',
                                    type: 'text',
                                    placeholder: '名称'
                                }
                            ],
                            buttons: [
                                {
                                    text: 'Cancel',
                                    role: 'cancel',
                                    cssClass: 'secondary',
                                    handler: function () {
                                        reject(false);
                                    }
                                }, {
                                    text: 'Ok',
                                    handler: function (res) {
                                        resolve(res.name);
                                    }
                                }
                            ]
                        }).then(function (res) {
                            res.present();
                        });
                    })];
            });
        });
    };
    WifiPushPage.prototype.addDevice = function (mac) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                this.device.getDeviceInfoBymac(mac, this.queryParams.code).then(function (res) {
                    _this.presentAlertPrompt().then(function (data) {
                        var param = {
                            deviceId: res.id,
                            name: data ? data : _this.queryParams.name,
                            roomId: 1,
                            sort: 1,
                        };
                        // alert(JSON.stringify(param));
                        _this.device.addUserDeviceInfo(param).then(function (res1) {
                        }, function (err1) {
                            _this.tools.showToast('设备添加失败');
                        }).finally(function () {
                            // this.navCtrl.navigateForward('tabs/main');
                            // this.router.navigate(['tabs/main']);
                            _this.navCtrl.navigateRoot(['tabs/main']).then(function (res) {
                                location.reload();
                            });
                        });
                    });
                    // alert(JSON.stringify(res));
                }, function (err) {
                    _this.presentActionSheet();
                });
                return [2 /*return*/];
            });
        });
    };
    WifiPushPage.prototype.ngOnDestroy = function () {
        this.esptouch.close();
    };
    WifiPushPage.prototype.ionViewWillLeave = function () {
        return false;
    };
    WifiPushPage.prototype.presentActionSheet = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var actionSheet;
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.actionSheetController.create({
                            header: '配网失败',
                            subHeader: '设备连接失败, 请确认网络设置正确。',
                            buttons: [{
                                    text: '再次尝试',
                                    icon: 'share',
                                    handler: function () {
                                        _this.ngOnInit();
                                    }
                                }, {
                                    text: 'Cancel',
                                    role: 'cancel',
                                    handler: function () {
                                        // this.navCtrl.navigateRoot('tabs/main');
                                        _this.navCtrl.navigateRoot(['tabs/main']).then(function (res) {
                                            location.reload();
                                        });
                                    }
                                }]
                        })];
                    case 1:
                        actionSheet = _a.sent();
                        return [4 /*yield*/, actionSheet.present()];
                    case 2:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    WifiPushPage.ctorParameters = function () { return [
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] },
        { type: _services_esptouch_service__WEBPACK_IMPORTED_MODULE_3__["EsptouchService"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["ActionSheetController"] },
        { type: _services_request_device_request_service__WEBPACK_IMPORTED_MODULE_5__["DeviceRequestService"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["NavController"] },
        { type: _services_tools_service__WEBPACK_IMPORTED_MODULE_4__["ToolsService"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["AlertController"] }
    ]; };
    WifiPushPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-wifi-push',
            template: __webpack_require__(/*! raw-loader!./wifi-push.page.html */ "./node_modules/raw-loader/index.js!./src/app/pages/wifi-push/wifi-push.page.html"),
            styles: [__webpack_require__(/*! ./wifi-push.page.scss */ "./src/app/pages/wifi-push/wifi-push.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"],
            _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"],
            _services_esptouch_service__WEBPACK_IMPORTED_MODULE_3__["EsptouchService"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["ActionSheetController"],
            _services_request_device_request_service__WEBPACK_IMPORTED_MODULE_5__["DeviceRequestService"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["NavController"],
            _services_tools_service__WEBPACK_IMPORTED_MODULE_4__["ToolsService"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["AlertController"]])
    ], WifiPushPage);
    return WifiPushPage;
}());



/***/ }),

/***/ "./src/app/services/esptouch.service.ts":
/*!**********************************************!*\
  !*** ./src/app/services/esptouch.service.ts ***!
  \**********************************************/
/*! exports provided: EsptouchService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EsptouchService", function() { return EsptouchService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");



var EsptouchService = /** @class */ (function () {
    function EsptouchService(loadingController, toastController) {
        this.loadingController = loadingController;
        this.toastController = toastController;
    }
    EsptouchService.prototype.start = function (ssid, pwd) {
        return new Promise(function (resolve, reject) {
            esptouch.start(ssid, '00:00:00:00:00:00', pwd, '1', '1', function (res) { resolve(res); }, function (err) { reject(err); });
        });
    };
    EsptouchService.prototype.close = function () {
        return new Promise(function (resolve, reject) {
            esptouch.stop(function (res) {
                resolve(res);
            }, function (err) { reject(err); });
        });
    };
    EsptouchService.ctorParameters = function () { return [
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["LoadingController"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ToastController"] }
    ]; };
    EsptouchService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["LoadingController"], _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ToastController"]])
    ], EsptouchService);
    return EsptouchService;
}());



/***/ })

}]);
//# sourceMappingURL=pages-wifi-push-wifi-push-module-es5.js.map