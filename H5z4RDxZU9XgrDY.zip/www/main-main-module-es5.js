(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main-main-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/pages/main/main.page.html":
/*!*********************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/pages/main/main.page.html ***!
  \*********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header no-border>\n    <ion-toolbar>\n        <ion-buttons slot=\"start\">\n            <ion-button color='medium'>\n                <ion-text class=\"username\">admin的家庭</ion-text>\n                <ion-icon name=\"arrow-forward\"></ion-icon>\n            </ion-button>\n        </ion-buttons>\n        <ion-buttons slot=\"end\">\n            <ion-button (click)=\"addDevice()\">\n                <ion-icon color=\"medium\" name=\"add\" slot=\"icon-only\"></ion-icon>\n            </ion-button>\n        </ion-buttons>\n    </ion-toolbar>\n</ion-header>\n\n<ion-content fullscreen [forceOverscroll]=\"forceOverscroll\">\n    <ion-grid>\n        <ion-row>\n            <ion-col>\n                <ion-text color='medium' style=\"font-size: 12px;\">\n                    <ion-icon name=\"tablet-portrait\"></ion-icon>\n                    {{this.deviceList.length}}个设备 | 4个智能场景\n                </ion-text>\n            </ion-col>\n        </ion-row>\n    </ion-grid>\n\n    <!--设备标题-->\n    <ion-grid style=\"margin-top:20px\">\n        <ion-row>\n            <ion-col>\n                <ion-text color='medium' style=\"font-size: 16px;\">\n                    设备\n                </ion-text>\n            </ion-col>\n        </ion-row>\n    </ion-grid>\n    <!--设备内容-->\n    <ion-grid>\n        <ion-row dragula=\"bag\">\n            <ion-col size=\"4\" *ngFor=\"let item of deviceList\">\n                <ion-grid class=\"device\" (click)=\"goDetail(item)\">\n                    <ion-row>\n                        <ion-text>{{item.name}}</ion-text>\n                    </ion-row>\n                    <ion-row>\n                        <ion-text>在线({{item.roomName}})</ion-text>\n                    </ion-row>\n                    <ion-row>\n                        <!-- <img [src]=\"item.img\" width=\"50\" height=\"50\"> -->\n                        <ion-img [src]=\"item.img\" style=\"height: 50px;width:50px;\"></ion-img>\n                        <!-- <ion-img src=\"../../../assets/air.png\" style=\"height: 50px;width:50px;\"></ion-img> -->\n                        \n                        <span [ngClass]=\"{'open': item.open}\">\n                            <img *ngIf=\"!item.open\" src=\"../../../assets/icon/open.png\" width=\"16\" height=\"16\">\n                            <img  *ngIf=\"item.open\"  src=\"../../assets/check.png\" width=\"16\" height=\"16\">\n                            \n                        </span>\n                    </ion-row>\n                </ion-grid>\n            </ion-col>\n           \n        </ion-row>\n\n\n        <!-- <ion-row no-padding class=\"matrix\">\n            <ion-col size=\"6\" class=\"q1\">\n                <div class=\"q-header\">Do</div>\n                <ion-list dragula=\"bag\" [(dragulaModel)]=\"q1\" lines=\"none\">\n                    <ion-item *ngFor=\"let item of q1\" [color]=\"item.color\" expand=\"block\" text-wrap>\n                        {{ item.value }}\n                    </ion-item>\n                </ion-list>\n            </ion-col>\n\n          \n        </ion-row> -->\n    </ion-grid>\n\n</ion-content>"

/***/ }),

/***/ "./src/app/pages/main/main.module.ts":
/*!*******************************************!*\
  !*** ./src/app/pages/main/main.module.ts ***!
  \*******************************************/
/*! exports provided: MainPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MainPageModule", function() { return MainPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var ng2_dragula__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ng2-dragula */ "./node_modules/ng2-dragula/dist/fesm5/ng2-dragula.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _main_page__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./main.page */ "./src/app/pages/main/main.page.ts");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ngx-translate/core */ "./node_modules/@ngx-translate/core/fesm5/ngx-translate-core.js");









var routes = [
    {
        path: '',
        component: _main_page__WEBPACK_IMPORTED_MODULE_7__["MainPage"]
    }
];
var MainPageModule = /** @class */ (function () {
    function MainPageModule() {
    }
    MainPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes),
                ng2_dragula__WEBPACK_IMPORTED_MODULE_5__["DragulaModule"],
                _ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__["TranslateModule"]
            ],
            declarations: [_main_page__WEBPACK_IMPORTED_MODULE_7__["MainPage"]]
        })
    ], MainPageModule);
    return MainPageModule;
}());



/***/ }),

/***/ "./src/app/pages/main/main.page.scss":
/*!*******************************************!*\
  !*** ./src/app/pages/main/main.page.scss ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".home-header {\n  width: 100%;\n  background-size: 100% auto;\n  background-repeat: no-repeat;\n  background-position: center;\n  display: -webkit-box;\n  display: flex;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n          flex-direction: column;\n}\n.home-header .home-header-content {\n  width: 100%;\n  display: -webkit-box;\n  display: flex;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n          flex-direction: column;\n}\n.home-header .home-header-content .col-left p {\n  margin-top: 6px !important;\n  color: white;\n  font-size: 1.2rem;\n}\n.home-header .home-header-content .col-right {\n  color: white;\n  display: -webkit-box;\n  display: flex;\n  -webkit-box-align: center;\n          align-items: center;\n}\n.home-header .home-header-content .col-right img {\n  width: 16px;\n}\n.home-header .home-header-content .city {\n  border: 1px solid white;\n  border-radius: 15px;\n  padding-left: 10px;\n  padding-right: 10px;\n  display: inline-block;\n  height: 20px;\n  line-height: 19px;\n  text-align: center;\n  color: white;\n}\n.home-header .weather {\n  color: #fff;\n  text-align: center;\n  margin-top: 170px;\n}\n.home-header .weather p {\n  margin: 0;\n}\n.home-header .weather .degree {\n  font-size: 7rem;\n}\n.home-header .weather .city {\n  font-size: 1.8rem;\n}\n.home-header .weather-bottom {\n  background: rgba(0, 0, 0, 0.35);\n  margin-bottom: 0;\n  height: 50px;\n  width: 100%;\n  color: #fff;\n  text-align: center;\n  line-height: 40px;\n}\n.device {\n  display: inline-block;\n  width: 100%;\n  height: 105px;\n  background-color: white;\n  color: #333;\n  border-radius: 5px;\n}\n.device ion-row:nth-child(2) {\n  font-size: 8px;\n  color: #888;\n}\n.device ion-row:nth-child(1) {\n  font-size: 14px;\n}\n.device ion-row:nth-child(3) {\n  margin-top: 5px;\n  display: -webkit-box;\n  display: flex;\n  -webkit-box-pack: justify;\n          justify-content: space-between;\n  -webkit-box-align: end;\n          align-items: flex-end;\n}\n.device ion-row:nth-child(3) span {\n  width: 25px;\n  height: 25px;\n  border-radius: 50%;\n  text-align: center;\n  display: -webkit-box;\n  display: flex;\n  -webkit-box-align: center;\n          align-items: center;\n  -webkit-box-pack: center;\n          justify-content: center;\n  border: 1px solid #aaa;\n}\n.delete-area {\n  border: 2px dashed var(--ion-color-medium);\n  margin: 10px;\n  height: 100px;\n}\n.delete-area ion-icon {\n  font-size: 64px;\n}\nion-content {\n  --background: #fff url('bg3.jpg') no-repeat center center / cover;\n  background-repeat: no-repeat;\n  background-size: 100% 100%;\n  margin-bottom: 0 !important;\n}\n.inner-scroll {\n  background: transparent !important;\n  margin-bottom: 0 !important;\n}\nion-toolbar {\n  --background: transparent !important;\n}\n.username {\n  font-size: 20px;\n  overflow: hidden;\n  white-space: nowrap;\n  text-overflow: ellipsis;\n  max-width: 150px;\n}\nion-toolbar {\n  --background: transparent !important;\n  --ion-color-base: transparent !important;\n  --min-height: 60px;\n}\nion-header {\n  --ion-toolbar-background-color: rgba(0, 0, 0, 0);\n}\n.open {\n  background-color: var(--ion-color-primary) !important;\n  border-color: var(--ion-color-primary) !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy96aG91Ym8vUHJvamVjdC9TbWFydEhvbWU0LjAvc3JjL2FwcC9wYWdlcy9tYWluL21haW4ucGFnZS5zY3NzIiwic3JjL2FwcC9wYWdlcy9tYWluL21haW4ucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBR0UsV0FBQTtFQUVBLDBCQUFBO0VBQ0EsNEJBQUE7RUFDQSwyQkFBQTtFQUNBLG9CQUFBO0VBQUEsYUFBQTtFQUNBLDRCQUFBO0VBQUEsNkJBQUE7VUFBQSxzQkFBQTtBQ0ZGO0FESUU7RUFDRSxXQUFBO0VBRUEsb0JBQUE7RUFBQSxhQUFBO0VBQ0EsNEJBQUE7RUFBQSw2QkFBQTtVQUFBLHNCQUFBO0FDSEo7QURXTTtFQUNFLDBCQUFBO0VBQ0EsWUFBQTtFQUVBLGlCQUFBO0FDVlI7QURhSTtFQUNFLFlBQUE7RUFDQSxvQkFBQTtFQUFBLGFBQUE7RUFDQSx5QkFBQTtVQUFBLG1CQUFBO0FDWE47QURZTTtFQUNFLFdBQUE7QUNWUjtBRGFJO0VBQ0UsdUJBQUE7RUFDQSxtQkFBQTtFQUVBLGtCQUFBO0VBQ0EsbUJBQUE7RUFDQSxxQkFBQTtFQUNBLFlBQUE7RUFDQSxpQkFBQTtFQUNBLGtCQUFBO0VBQ0EsWUFBQTtBQ1pOO0FEZUU7RUFDRSxXQUFBO0VBQ0Esa0JBQUE7RUFDQSxpQkFBQTtBQ2JKO0FEY0k7RUFDRSxTQUFBO0FDWk47QURjSTtFQUNFLGVBQUE7QUNaTjtBRGNJO0VBQ0UsaUJBQUE7QUNaTjtBRGVFO0VBQ0UsK0JBQUE7RUFDQSxnQkFBQTtFQUNBLFlBQUE7RUFDQSxXQUFBO0VBQ0EsV0FBQTtFQUNBLGtCQUFBO0VBQ0EsaUJBQUE7QUNiSjtBRGdCQTtFQUNFLHFCQUFBO0VBQ0EsV0FBQTtFQUNBLGFBQUE7RUFDQSx1QkFBQTtFQUNBLFdBQUE7RUFDQSxrQkFBQTtBQ2JGO0FEZUE7RUFDRSxjQUFBO0VBQ0EsV0FBQTtBQ1pGO0FEY0E7RUFDRSxlQUFBO0FDWEY7QURhQTtFQUNFLGVBQUE7RUFDQSxvQkFBQTtFQUFBLGFBQUE7RUFDQSx5QkFBQTtVQUFBLDhCQUFBO0VBQ0Esc0JBQUE7VUFBQSxxQkFBQTtBQ1ZGO0FEWUE7RUFDRSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0VBQ0Esa0JBQUE7RUFDQSxvQkFBQTtFQUFBLGFBQUE7RUFDQSx5QkFBQTtVQUFBLG1CQUFBO0VBQ0Esd0JBQUE7VUFBQSx1QkFBQTtFQUNBLHNCQUFBO0FDVEY7QURZQTtFQUNFLDBDQUFBO0VBQ0EsWUFBQTtFQUNBLGFBQUE7QUNURjtBRFdFO0VBQ0UsZUFBQTtBQ1RKO0FEYUE7RUFFRSxpRUFBQTtFQUNBLDRCQUFBO0VBQ0EsMEJBQUE7RUFDQSwyQkFBQTtBQ1hGO0FEY0E7RUFDRSxrQ0FBQTtFQUNBLDJCQUFBO0FDWEY7QURhQTtFQUNFLG9DQUFBO0FDVkY7QURhQTtFQUNFLGVBQUE7RUFFQSxnQkFBQTtFQUNBLG1CQUFBO0VBQ0EsdUJBQUE7RUFDQSxnQkFBQTtBQ1hGO0FEYUE7RUFDRSxvQ0FBQTtFQUNBLHdDQUFBO0VBQ0Esa0JBQUE7QUNWRjtBRFlBO0VBQ0UsZ0RBQUE7QUNURjtBRFdBO0VBQ0UscURBQUE7RUFDQSxpREFBQTtBQ1JGIiwiZmlsZSI6InNyYy9hcHAvcGFnZXMvbWFpbi9tYWluLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5ob21lLWhlYWRlciB7XG4gIC8vIG1hcmdpbi10b3A6IC0xNTBweDtcbiAgLy8gYmFja2dyb3VuZC1pbWFnZTogdXJsKFwiLi4vLi4vYXNzZXRzL2JnMS5wbmdcIik7XG4gIHdpZHRoOiAxMDAlO1xuICAvLyBoZWlnaHQ6IDIwMHB4O1xuICBiYWNrZ3JvdW5kLXNpemU6IDEwMCUgYXV0bztcbiAgYmFja2dyb3VuZC1yZXBlYXQ6IG5vLXJlcGVhdDtcbiAgYmFja2dyb3VuZC1wb3NpdGlvbjogY2VudGVyO1xuICBkaXNwbGF5OiBmbGV4O1xuICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xuICAvLyBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XG4gIC5ob21lLWhlYWRlci1jb250ZW50IHtcbiAgICB3aWR0aDogMTAwJTtcbiAgICAvLyBoZWlnaHQ6IDEyMHB4O1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcbiAgICAvLyBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XG4gICAgLy8gZGlzcGxheTogZmxleDtcbiAgICAvLyBhbGlnbi1pdGVtczogZmxleC1lbmQ7XG4gICAgLy8gLmhlYWRlci1kaXYge1xuICAgIC8vICAgcGFkZGluZzogMCAxMHB4IDAgMTBweDtcbiAgICAvLyB9XG4gICAgLmNvbC1sZWZ0IHtcbiAgICAgIHAge1xuICAgICAgICBtYXJnaW4tdG9wOiA2cHggIWltcG9ydGFudDtcbiAgICAgICAgY29sb3I6IHdoaXRlO1xuICAgICAgICAvLyBtYXJnaW4tbGVmdDogMHB4ICFpbXBvcnRhbnQ7XG4gICAgICAgIGZvbnQtc2l6ZTogMS4ycmVtO1xuICAgICAgfVxuICAgIH1cbiAgICAuY29sLXJpZ2h0IHtcbiAgICAgIGNvbG9yOiB3aGl0ZTtcbiAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgICAgaW1nIHtcbiAgICAgICAgd2lkdGg6IDE2cHg7XG4gICAgICB9XG4gICAgfVxuICAgIC5jaXR5IHtcbiAgICAgIGJvcmRlcjogMXB4IHNvbGlkIHdoaXRlO1xuICAgICAgYm9yZGVyLXJhZGl1czogMTVweDtcbiAgICAgIC8vIHdpZHRoOiA0MHB4O1xuICAgICAgcGFkZGluZy1sZWZ0OiAxMHB4O1xuICAgICAgcGFkZGluZy1yaWdodDogMTBweDtcbiAgICAgIGRpc3BsYXk6IGlubGluZS1ibG9jaztcbiAgICAgIGhlaWdodDogMjBweDtcbiAgICAgIGxpbmUtaGVpZ2h0OiAxOXB4O1xuICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgICAgY29sb3I6IHdoaXRlO1xuICAgIH1cbiAgfVxuICAud2VhdGhlciB7XG4gICAgY29sb3I6ICNmZmY7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgIG1hcmdpbi10b3A6IDE3MHB4O1xuICAgIHAge1xuICAgICAgbWFyZ2luOiAwO1xuICAgIH1cbiAgICAuZGVncmVlIHtcbiAgICAgIGZvbnQtc2l6ZTogN3JlbTtcbiAgICB9XG4gICAgLmNpdHkge1xuICAgICAgZm9udC1zaXplOiAxLjhyZW07XG4gICAgfVxuICB9XG4gIC53ZWF0aGVyLWJvdHRvbSB7XG4gICAgYmFja2dyb3VuZDogcmdiYSgwLCAwLCAwLCAwLjM1KTtcbiAgICBtYXJnaW4tYm90dG9tOiAwO1xuICAgIGhlaWdodDogNTBweDtcbiAgICB3aWR0aDogMTAwJTtcbiAgICBjb2xvcjogI2ZmZjtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgbGluZS1oZWlnaHQ6IDQwcHg7XG4gIH1cbn1cbi5kZXZpY2Uge1xuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG4gIHdpZHRoOiAxMDAlO1xuICBoZWlnaHQ6IDEwNXB4O1xuICBiYWNrZ3JvdW5kLWNvbG9yOiB3aGl0ZTtcbiAgY29sb3I6ICMzMzM7XG4gIGJvcmRlci1yYWRpdXM6IDVweDtcbn1cbi5kZXZpY2UgaW9uLXJvdzpudGgtY2hpbGQoMikge1xuICBmb250LXNpemU6IDhweDtcbiAgY29sb3I6ICM4ODg7XG59XG4uZGV2aWNlIGlvbi1yb3c6bnRoLWNoaWxkKDEpIHtcbiAgZm9udC1zaXplOiAxNHB4O1xufVxuLmRldmljZSBpb24tcm93Om50aC1jaGlsZCgzKSB7XG4gIG1hcmdpbi10b3A6IDVweDtcbiAgZGlzcGxheTogZmxleDtcbiAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xuICBhbGlnbi1pdGVtczogZmxleC1lbmQ7XG59XG4uZGV2aWNlIGlvbi1yb3c6bnRoLWNoaWxkKDMpIHNwYW4ge1xuICB3aWR0aDogMjVweDtcbiAgaGVpZ2h0OiAyNXB4O1xuICBib3JkZXItcmFkaXVzOiA1MCU7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgZGlzcGxheTogZmxleDtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gIGJvcmRlcjogMXB4IHNvbGlkICNhYWE7XG59XG5cbi5kZWxldGUtYXJlYSB7XG4gIGJvcmRlcjogMnB4IGRhc2hlZCB2YXIoLS1pb24tY29sb3ItbWVkaXVtKTtcbiAgbWFyZ2luOiAxMHB4O1xuICBoZWlnaHQ6IDEwMHB4O1xuXG4gIGlvbi1pY29uIHtcbiAgICBmb250LXNpemU6IDY0cHg7XG4gIH1cbn1cblxuaW9uLWNvbnRlbnQge1xuICAvLyAgIGJhY2tncm91bmQtaW1hZ2U6IHVybCguLi8uLi8uLi9hc3NldHMvYmcuanBnKTtcbiAgLS1iYWNrZ3JvdW5kOiAjZmZmIHVybCguLi8uLi8uLi9hc3NldHMvYmczLmpwZykgbm8tcmVwZWF0IGNlbnRlciBjZW50ZXIgLyBjb3ZlcjtcbiAgYmFja2dyb3VuZC1yZXBlYXQ6IG5vLXJlcGVhdDtcbiAgYmFja2dyb3VuZC1zaXplOiAxMDAlIDEwMCU7XG4gIG1hcmdpbi1ib3R0b206IDAgIWltcG9ydGFudDtcbn1cblxuLmlubmVyLXNjcm9sbCB7XG4gIGJhY2tncm91bmQ6IHRyYW5zcGFyZW50ICFpbXBvcnRhbnQ7XG4gIG1hcmdpbi1ib3R0b206IDAgIWltcG9ydGFudDtcbn1cbmlvbi10b29sYmFyIHtcbiAgLS1iYWNrZ3JvdW5kOiB0cmFuc3BhcmVudCAhaW1wb3J0YW50O1xufVxuXG4udXNlcm5hbWUge1xuICBmb250LXNpemU6IDIwcHg7XG4gIC8vICAgY29sb3I6ICMzMzM7XG4gIG92ZXJmbG93OiBoaWRkZW47XG4gIHdoaXRlLXNwYWNlOiBub3dyYXA7XG4gIHRleHQtb3ZlcmZsb3c6IGVsbGlwc2lzO1xuICBtYXgtd2lkdGg6IDE1MHB4O1xufVxuaW9uLXRvb2xiYXIge1xuICAtLWJhY2tncm91bmQ6IHRyYW5zcGFyZW50ICFpbXBvcnRhbnQ7XG4gIC0taW9uLWNvbG9yLWJhc2U6IHRyYW5zcGFyZW50ICFpbXBvcnRhbnQ7XG4gIC0tbWluLWhlaWdodDogNjBweDtcbn1cbmlvbi1oZWFkZXIge1xuICAtLWlvbi10b29sYmFyLWJhY2tncm91bmQtY29sb3I6IHJnYmEoMCwgMCwgMCwgMCk7XG59XG4ub3BlbiB7XG4gIGJhY2tncm91bmQtY29sb3I6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KSAhaW1wb3J0YW50O1xuICBib3JkZXItY29sb3I6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KSAhaW1wb3J0YW50O1xufVxuIiwiLmhvbWUtaGVhZGVyIHtcbiAgd2lkdGg6IDEwMCU7XG4gIGJhY2tncm91bmQtc2l6ZTogMTAwJSBhdXRvO1xuICBiYWNrZ3JvdW5kLXJlcGVhdDogbm8tcmVwZWF0O1xuICBiYWNrZ3JvdW5kLXBvc2l0aW9uOiBjZW50ZXI7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XG59XG4uaG9tZS1oZWFkZXIgLmhvbWUtaGVhZGVyLWNvbnRlbnQge1xuICB3aWR0aDogMTAwJTtcbiAgZGlzcGxheTogZmxleDtcbiAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcbn1cbi5ob21lLWhlYWRlciAuaG9tZS1oZWFkZXItY29udGVudCAuY29sLWxlZnQgcCB7XG4gIG1hcmdpbi10b3A6IDZweCAhaW1wb3J0YW50O1xuICBjb2xvcjogd2hpdGU7XG4gIGZvbnQtc2l6ZTogMS4ycmVtO1xufVxuLmhvbWUtaGVhZGVyIC5ob21lLWhlYWRlci1jb250ZW50IC5jb2wtcmlnaHQge1xuICBjb2xvcjogd2hpdGU7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG59XG4uaG9tZS1oZWFkZXIgLmhvbWUtaGVhZGVyLWNvbnRlbnQgLmNvbC1yaWdodCBpbWcge1xuICB3aWR0aDogMTZweDtcbn1cbi5ob21lLWhlYWRlciAuaG9tZS1oZWFkZXItY29udGVudCAuY2l0eSB7XG4gIGJvcmRlcjogMXB4IHNvbGlkIHdoaXRlO1xuICBib3JkZXItcmFkaXVzOiAxNXB4O1xuICBwYWRkaW5nLWxlZnQ6IDEwcHg7XG4gIHBhZGRpbmctcmlnaHQ6IDEwcHg7XG4gIGRpc3BsYXk6IGlubGluZS1ibG9jaztcbiAgaGVpZ2h0OiAyMHB4O1xuICBsaW5lLWhlaWdodDogMTlweDtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBjb2xvcjogd2hpdGU7XG59XG4uaG9tZS1oZWFkZXIgLndlYXRoZXIge1xuICBjb2xvcjogI2ZmZjtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBtYXJnaW4tdG9wOiAxNzBweDtcbn1cbi5ob21lLWhlYWRlciAud2VhdGhlciBwIHtcbiAgbWFyZ2luOiAwO1xufVxuLmhvbWUtaGVhZGVyIC53ZWF0aGVyIC5kZWdyZWUge1xuICBmb250LXNpemU6IDdyZW07XG59XG4uaG9tZS1oZWFkZXIgLndlYXRoZXIgLmNpdHkge1xuICBmb250LXNpemU6IDEuOHJlbTtcbn1cbi5ob21lLWhlYWRlciAud2VhdGhlci1ib3R0b20ge1xuICBiYWNrZ3JvdW5kOiByZ2JhKDAsIDAsIDAsIDAuMzUpO1xuICBtYXJnaW4tYm90dG9tOiAwO1xuICBoZWlnaHQ6IDUwcHg7XG4gIHdpZHRoOiAxMDAlO1xuICBjb2xvcjogI2ZmZjtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBsaW5lLWhlaWdodDogNDBweDtcbn1cblxuLmRldmljZSB7XG4gIGRpc3BsYXk6IGlubGluZS1ibG9jaztcbiAgd2lkdGg6IDEwMCU7XG4gIGhlaWdodDogMTA1cHg7XG4gIGJhY2tncm91bmQtY29sb3I6IHdoaXRlO1xuICBjb2xvcjogIzMzMztcbiAgYm9yZGVyLXJhZGl1czogNXB4O1xufVxuXG4uZGV2aWNlIGlvbi1yb3c6bnRoLWNoaWxkKDIpIHtcbiAgZm9udC1zaXplOiA4cHg7XG4gIGNvbG9yOiAjODg4O1xufVxuXG4uZGV2aWNlIGlvbi1yb3c6bnRoLWNoaWxkKDEpIHtcbiAgZm9udC1zaXplOiAxNHB4O1xufVxuXG4uZGV2aWNlIGlvbi1yb3c6bnRoLWNoaWxkKDMpIHtcbiAgbWFyZ2luLXRvcDogNXB4O1xuICBkaXNwbGF5OiBmbGV4O1xuICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XG4gIGFsaWduLWl0ZW1zOiBmbGV4LWVuZDtcbn1cblxuLmRldmljZSBpb24tcm93Om50aC1jaGlsZCgzKSBzcGFuIHtcbiAgd2lkdGg6IDI1cHg7XG4gIGhlaWdodDogMjVweDtcbiAgYm9yZGVyLXJhZGl1czogNTAlO1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICBib3JkZXI6IDFweCBzb2xpZCAjYWFhO1xufVxuXG4uZGVsZXRlLWFyZWEge1xuICBib3JkZXI6IDJweCBkYXNoZWQgdmFyKC0taW9uLWNvbG9yLW1lZGl1bSk7XG4gIG1hcmdpbjogMTBweDtcbiAgaGVpZ2h0OiAxMDBweDtcbn1cbi5kZWxldGUtYXJlYSBpb24taWNvbiB7XG4gIGZvbnQtc2l6ZTogNjRweDtcbn1cblxuaW9uLWNvbnRlbnQge1xuICAtLWJhY2tncm91bmQ6ICNmZmYgdXJsKC4uLy4uLy4uL2Fzc2V0cy9iZzMuanBnKSBuby1yZXBlYXQgY2VudGVyIGNlbnRlciAvIGNvdmVyO1xuICBiYWNrZ3JvdW5kLXJlcGVhdDogbm8tcmVwZWF0O1xuICBiYWNrZ3JvdW5kLXNpemU6IDEwMCUgMTAwJTtcbiAgbWFyZ2luLWJvdHRvbTogMCAhaW1wb3J0YW50O1xufVxuXG4uaW5uZXItc2Nyb2xsIHtcbiAgYmFja2dyb3VuZDogdHJhbnNwYXJlbnQgIWltcG9ydGFudDtcbiAgbWFyZ2luLWJvdHRvbTogMCAhaW1wb3J0YW50O1xufVxuXG5pb24tdG9vbGJhciB7XG4gIC0tYmFja2dyb3VuZDogdHJhbnNwYXJlbnQgIWltcG9ydGFudDtcbn1cblxuLnVzZXJuYW1lIHtcbiAgZm9udC1zaXplOiAyMHB4O1xuICBvdmVyZmxvdzogaGlkZGVuO1xuICB3aGl0ZS1zcGFjZTogbm93cmFwO1xuICB0ZXh0LW92ZXJmbG93OiBlbGxpcHNpcztcbiAgbWF4LXdpZHRoOiAxNTBweDtcbn1cblxuaW9uLXRvb2xiYXIge1xuICAtLWJhY2tncm91bmQ6IHRyYW5zcGFyZW50ICFpbXBvcnRhbnQ7XG4gIC0taW9uLWNvbG9yLWJhc2U6IHRyYW5zcGFyZW50ICFpbXBvcnRhbnQ7XG4gIC0tbWluLWhlaWdodDogNjBweDtcbn1cblxuaW9uLWhlYWRlciB7XG4gIC0taW9uLXRvb2xiYXItYmFja2dyb3VuZC1jb2xvcjogcmdiYSgwLCAwLCAwLCAwKTtcbn1cblxuLm9wZW4ge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSkgIWltcG9ydGFudDtcbiAgYm9yZGVyLWNvbG9yOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSkgIWltcG9ydGFudDtcbn0iXX0= */"

/***/ }),

/***/ "./src/app/pages/main/main.page.ts":
/*!*****************************************!*\
  !*** ./src/app/pages/main/main.page.ts ***!
  \*****************************************/
/*! exports provided: MainPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MainPage", function() { return MainPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _services_services_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../services/services.service */ "./src/app/services/services.service.ts");
/* harmony import */ var _services_request_login_request_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../services/request/login-request.service */ "./src/app/services/request/login-request.service.ts");
/* harmony import */ var _services_request_device_request_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../services/request/device-request.service */ "./src/app/services/request/device-request.service.ts");
/* harmony import */ var _services_socket_helper_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../services/socket-helper.service */ "./src/app/services/socket-helper.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var ng2_dragula__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ng2-dragula */ "./node_modules/ng2-dragula/dist/fesm5/ng2-dragula.js");
/* harmony import */ var _services_global_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../services/global.service */ "./src/app/services/global.service.ts");
/* harmony import */ var _services_tools_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../services/tools.service */ "./src/app/services/tools.service.ts");











var MainPage = /** @class */ (function () {
    function MainPage(router, services, login, dragulaService, toastController, device, socketHelper, globalService$, tools, route) {
        var _this = this;
        this.router = router;
        this.services = services;
        this.login = login;
        this.dragulaService = dragulaService;
        this.toastController = toastController;
        this.device = device;
        this.socketHelper = socketHelper;
        this.globalService$ = globalService$;
        this.tools = tools;
        this.route = route;
        this.forceOverscroll = true;
        this.todo = { value: '', color: '' };
        this.selectedQuadrant = 'q1';
        this.deviceList = [];
        // const queryParams = this.route.snapshot.queryParams; // queryParams.wifi queryParams.password
        this.dragulaService.drag('bag')
            .subscribe(function (_a) {
            var name = _a.name, el = _a.el, source = _a.source;
            console.log('drag');
            _this.forceOverscroll = false;
        });
        this.dragulaService.removeModel('bag')
            .subscribe(function (_a) {
            var item = _a.item;
            _this.toastController.create({
                message: 'Removed: ' + item.value,
                duration: 2000
            }).then(function (toast) { return toast.present(); });
        });
        this.dragulaService.dropModel('bag')
            .subscribe(function (_a) {
            var item = _a.item;
            item['color'] = 'success';
        });
        this.dragulaService.over('bag').subscribe(function (value) {
            console.log('voer');
        });
        this.dragulaService.out('bag').subscribe(function (value) {
            console.log('out');
            _this.forceOverscroll = true;
        });
        // this.dragulaService.createGroup('bag', {
        //   removeOnSpill: true
        // });
    }
    MainPage.prototype.ngOnInit = function () {
        var _this = this;
        console.warn('ngOnInit');
        this.logued();
        this.device.getDeviceDetailList().then(function (res) {
            _this.deviceList = res;
            _this.initData();
        });
    };
    MainPage.prototype.ionViewDidEnter = function () {
        // this.fresh();
        console.log('ionViewDidEnter');
    };
    MainPage.prototype.ionViewDidLeave = function () {
        console.log('ionViewDidLeave');
    };
    MainPage.prototype.fresh = function () {
        var _this = this;
        this.device.getDeviceDetailList().then(function (res) {
            _this.deviceList = res;
        });
    };
    MainPage.prototype.initData = function () {
        var _this = this;
        // 设备实时数据接收
        this.initDeviceData();
        this.deviceDataSubscribe = this.globalService$.globalVar.subscribe(function (res) {
            _this.initDeviceData();
        });
    };
    MainPage.prototype.initDeviceData = function () {
        var _this = this;
        var deviceDatas = this.globalService$.DeviceData;
        if (!deviceDatas) {
            return;
        }
        this.deviceList.forEach(function (res) {
            if (deviceDatas[res.mac]) {
                res.open = _this.tools.parseToBooleanByString(deviceDatas[res.mac].switch_state);
            }
        });
    };
    MainPage.prototype.logued = function () {
        // this.login.checkToken();
    };
    MainPage.prototype.signOut = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                return [2 /*return*/];
            });
        });
    };
    MainPage.prototype.getProfile = function (id) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                return [2 /*return*/];
            });
        });
    };
    MainPage.prototype.profile = function () {
        this.router.navigateByUrl("profile");
    };
    MainPage.prototype.addDevice = function () {
        this.router.navigateByUrl('device-catalogue');
    };
    MainPage.prototype.goDetail = function (device) {
        this.router.navigate(['/thermostat'], { queryParams: device });
    };
    MainPage.ctorParameters = function () { return [
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] },
        { type: _services_services_service__WEBPACK_IMPORTED_MODULE_3__["ServicesService"] },
        { type: _services_request_login_request_service__WEBPACK_IMPORTED_MODULE_4__["LoginRequestService"] },
        { type: ng2_dragula__WEBPACK_IMPORTED_MODULE_8__["DragulaService"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__["ToastController"] },
        { type: _services_request_device_request_service__WEBPACK_IMPORTED_MODULE_5__["DeviceRequestService"] },
        { type: _services_socket_helper_service__WEBPACK_IMPORTED_MODULE_6__["SocketHelperService"] },
        { type: _services_global_service__WEBPACK_IMPORTED_MODULE_9__["GlobalService"] },
        { type: _services_tools_service__WEBPACK_IMPORTED_MODULE_10__["ToolsService"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"] }
    ]; };
    MainPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-main',
            template: __webpack_require__(/*! raw-loader!./main.page.html */ "./node_modules/raw-loader/index.js!./src/app/pages/main/main.page.html"),
            styles: [__webpack_require__(/*! ./main.page.scss */ "./src/app/pages/main/main.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"],
            _services_services_service__WEBPACK_IMPORTED_MODULE_3__["ServicesService"],
            _services_request_login_request_service__WEBPACK_IMPORTED_MODULE_4__["LoginRequestService"],
            ng2_dragula__WEBPACK_IMPORTED_MODULE_8__["DragulaService"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_7__["ToastController"],
            _services_request_device_request_service__WEBPACK_IMPORTED_MODULE_5__["DeviceRequestService"],
            _services_socket_helper_service__WEBPACK_IMPORTED_MODULE_6__["SocketHelperService"],
            _services_global_service__WEBPACK_IMPORTED_MODULE_9__["GlobalService"],
            _services_tools_service__WEBPACK_IMPORTED_MODULE_10__["ToolsService"],
            _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"]])
    ], MainPage);
    return MainPage;
}());



/***/ })

}]);
//# sourceMappingURL=main-main-module-es5.js.map