(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-langset-langset-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/pages/langset/langset.page.html":
/*!***************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/pages/langset/langset.page.html ***!
  \***************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button text=\"{{ 'generic_goback' | translate }}\"></ion-back-button>\n    </ion-buttons>\n    <ion-title>{{ 'meComSet_translate' | translate }}</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-list>\n    <ion-radio-group>\n      <ion-list-header>\n\n      </ion-list-header>\n      <ion-item>\n        <ion-label>{{ 'generic_zh_language' | translate }}</ion-label>\n        <ion-radio value=\"zh\" [checked]=\"getChecked('zh')\" (click)=\"changeLanguage('zh')\"></ion-radio>\n      </ion-item>\n      <ion-item>\n        <ion-label>{{ 'generic_en_language' | translate }}</ion-label>\n        <ion-radio value=\"en\" [checked]=\"getChecked('en')\" (click)=\"changeLanguage('en')\"></ion-radio>\n      </ion-item>\n    </ion-radio-group>\n  </ion-list>\n</ion-content>"

/***/ }),

/***/ "./src/app/pages/langset/langset-routing.module.ts":
/*!*********************************************************!*\
  !*** ./src/app/pages/langset/langset-routing.module.ts ***!
  \*********************************************************/
/*! exports provided: LangsetPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LangsetPageRoutingModule", function() { return LangsetPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _langset_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./langset.page */ "./src/app/pages/langset/langset.page.ts");




var routes = [
    {
        path: '',
        component: _langset_page__WEBPACK_IMPORTED_MODULE_3__["LangsetPage"]
    }
];
var LangsetPageRoutingModule = /** @class */ (function () {
    function LangsetPageRoutingModule() {
    }
    LangsetPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
        })
    ], LangsetPageRoutingModule);
    return LangsetPageRoutingModule;
}());



/***/ }),

/***/ "./src/app/pages/langset/langset.module.ts":
/*!*************************************************!*\
  !*** ./src/app/pages/langset/langset.module.ts ***!
  \*************************************************/
/*! exports provided: LangsetPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LangsetPageModule", function() { return LangsetPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _langset_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./langset-routing.module */ "./src/app/pages/langset/langset-routing.module.ts");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ngx-translate/core */ "./node_modules/@ngx-translate/core/fesm5/ngx-translate-core.js");
/* harmony import */ var _langset_page__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./langset.page */ "./src/app/pages/langset/langset.page.ts");








var LangsetPageModule = /** @class */ (function () {
    function LangsetPageModule() {
    }
    LangsetPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
                _langset_routing_module__WEBPACK_IMPORTED_MODULE_5__["LangsetPageRoutingModule"],
                _ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__["TranslateModule"]
            ],
            declarations: [_langset_page__WEBPACK_IMPORTED_MODULE_7__["LangsetPage"]]
        })
    ], LangsetPageModule);
    return LangsetPageModule;
}());



/***/ }),

/***/ "./src/app/pages/langset/langset.page.scss":
/*!*************************************************!*\
  !*** ./src/app/pages/langset/langset.page.scss ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL2xhbmdzZXQvbGFuZ3NldC5wYWdlLnNjc3MifQ== */"

/***/ }),

/***/ "./src/app/pages/langset/langset.page.ts":
/*!***********************************************!*\
  !*** ./src/app/pages/langset/langset.page.ts ***!
  \***********************************************/
/*! exports provided: LangsetPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LangsetPage", function() { return LangsetPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ngx-translate/core */ "./node_modules/@ngx-translate/core/fesm5/ngx-translate-core.js");



var LangsetPage = /** @class */ (function () {
    function LangsetPage(translate) {
        this.translate = translate;
    }
    LangsetPage.prototype.ngOnInit = function () {
    };
    /**
     * 获取选中状态
     * @param lang 传入的语言
     */
    LangsetPage.prototype.getChecked = function (lang) {
        if (lang === this.translate.getDefaultLang()) {
            return true;
        }
        else {
            return false;
        }
    };
    /**
     * 更改当前语言
     * @param lang 要更改的语言
     */
    LangsetPage.prototype.changeLanguage = function (lang) {
        console.log('lang=' + lang);
        this.translate.setDefaultLang(lang);
        this.translate.use(lang).subscribe(function () {
            console.log('语言切换=' + lang);
        });
    };
    LangsetPage.ctorParameters = function () { return [
        { type: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_2__["TranslateService"] }
    ]; };
    LangsetPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-langset',
            template: __webpack_require__(/*! raw-loader!./langset.page.html */ "./node_modules/raw-loader/index.js!./src/app/pages/langset/langset.page.html"),
            styles: [__webpack_require__(/*! ./langset.page.scss */ "./src/app/pages/langset/langset.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ngx_translate_core__WEBPACK_IMPORTED_MODULE_2__["TranslateService"]])
    ], LangsetPage);
    return LangsetPage;
}());



/***/ })

}]);
//# sourceMappingURL=pages-langset-langset-module-es5.js.map