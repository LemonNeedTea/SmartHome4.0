(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["profile-profile-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/pages/profile/profile.page.html":
/*!***************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/pages/profile/profile.page.html ***!
  \***************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header no-border>\n    <ion-toolbar no-border>\n\n        <ion-title mode=\"ios\" color=\"primary\"></ion-title>\n\n        <!-- <ion-buttons slot=\"end\">\n            <ion-button (click)=\"goedit()\">\n                <ion-icon color=\"primary\" name=\"more\" slot=\"icon-only\"></ion-icon>\n\n            </ion-button>\n        </ion-buttons> -->\n\n    </ion-toolbar>\n</ion-header>\n\n<ion-content>\n\n    <div class=\"form\" *ngIf=\"empty\">\n\n\n        <div text-center>\n\n            <img text-center class=\"circle\" src=\"../../../assets/profile.jpg\" alt=\"\">\n        </div>\n\n\n        <h3 text-center>admin</h3>\n\n        <div text-center>\n            <!--  More thing of the profile \n      <p> {{item[0].payload.doc.data().phone}}</p>\n      <p> {{item[0].payload.doc.data().mail}}</p>\n      <p> {{item[0].payload.doc.data().adress}}</p> -->\n\n        </div>\n        <br><br>\n\n        <br>\n\n        <ion-list padding>\n            <ion-item>\n                <ion-icon slot=\"start\" name=\"moon\"></ion-icon>\n                Dark mode\n                <ion-toggle (ionChange)=\"update($event)\" slot=\"end\" color=\"primary\" [(ngModel)]=\"darkMode\"></ion-toggle>\n            </ion-item>\n\n            <!-- <ion-item>\n                <ion-icon color=\"primary\" slot=\"start\" name=\"notifications\"></ion-icon>\n                Notifications\n            </ion-item> -->\n            <!-- <ion-item>\n                <ion-icon color=\"tertiary\" slot=\"start\" name=\"mail-unread\"></ion-icon>\n                News\n                <ion-toggle slot=\"end\" color=\"primary\"></ion-toggle>\n            </ion-item>\n            <ion-item>\n                <ion-icon color=\"secondary\" slot=\"start\" name=\"settings\"></ion-icon>\n                Setting and privacy\n            </ion-item>\n\n            <ion-item>\n                <ion-icon color=\"success\" slot=\"start\" name=\"help\"></ion-icon>\n                Help center\n            </ion-item> -->\n            <ion-item (click)=\"signOut()\">\n                <ion-icon color=\"danger\" slot=\"start\" name=\"log-out\"></ion-icon>\n                Logout\n            </ion-item>\n        </ion-list>\n        <!-- <br>\n        <br>\n        <br>\n        <br>\n        <br>\n        <p style=\"color: gray; font-size: 13px\" text-center bold>User id : {{ uid }} </p>\n\n        <br>\n        <br> -->\n    </div>\n\n    <!-- <div class=\"form\" text-center *ngIf=\"!empty\">\n\n\n\n\n        <ion-grid>\n            <ion-row>\n                <ion-col size=\"12\" text-center>\n                    <img width=\"200px\" style=\"margin-top:32px;\" src=\"assets/user.svg\" alt=\"\">\n                </ion-col>\n                <ion-col size=\"12\" text-center>\n                    <h3>Fill your profile</h3>\n                </ion-col>\n                <ion-col size=\"12\" text-center>\n                    <ion-button (click)=\"goedit()\">Fill it</ion-button>\n                </ion-col>\n            </ion-row>\n        </ion-grid>\n\n    </div> -->\n\n\n\n\n\n</ion-content>"

/***/ }),

/***/ "./src/app/pages/profile/profile.module.ts":
/*!*************************************************!*\
  !*** ./src/app/pages/profile/profile.module.ts ***!
  \*************************************************/
/*! exports provided: ProfilePageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProfilePageModule", function() { return ProfilePageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _profile_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./profile.page */ "./src/app/pages/profile/profile.page.ts");







const routes = [
    {
        path: '',
        component: _profile_page__WEBPACK_IMPORTED_MODULE_6__["ProfilePage"]
    }
];
let ProfilePageModule = class ProfilePageModule {
};
ProfilePageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
            _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
        ],
        declarations: [_profile_page__WEBPACK_IMPORTED_MODULE_6__["ProfilePage"]]
    })
], ProfilePageModule);



/***/ }),

/***/ "./src/app/pages/profile/profile.page.scss":
/*!*************************************************!*\
  !*** ./src/app/pages/profile/profile.page.scss ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "h3 {\n  color: var(--ion-color-primary);\n}\n\nh5 {\n  color: var(--ion-color-primary);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy96aG91Ym8vUHJvamVjdC9TbWFydEhvbWU0LjAvc3JjL2FwcC9wYWdlcy9wcm9maWxlL3Byb2ZpbGUucGFnZS5zY3NzIiwic3JjL2FwcC9wYWdlcy9wcm9maWxlL3Byb2ZpbGUucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUVBO0VBQ0ksK0JBQUE7QUNESjs7QURJQTtFQUNJLCtCQUFBO0FDREoiLCJmaWxlIjoic3JjL2FwcC9wYWdlcy9wcm9maWxlL3Byb2ZpbGUucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiXG5cbmgzIHtcbiAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xufVxuXG5oNSB7XG4gICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KTtcbiAgICBcblxufSIsImgzIHtcbiAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KTtcbn1cblxuaDUge1xuICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xufSJdfQ== */"

/***/ }),

/***/ "./src/app/pages/profile/profile.page.ts":
/*!***********************************************!*\
  !*** ./src/app/pages/profile/profile.page.ts ***!
  \***********************************************/
/*! exports provided: ProfilePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProfilePage", function() { return ProfilePage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _services_services_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../services/services.service */ "./src/app/services/services.service.ts");
/* harmony import */ var _services_theme_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../services/theme.service */ "./src/app/services/theme.service.ts");
/* harmony import */ var _services_request_login_request_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../services/request/login-request.service */ "./src/app/services/request/login-request.service.ts");







let ProfilePage = class ProfilePage {
    constructor(nav, services, theme, login, router) {
        this.nav = nav;
        this.services = services;
        this.theme = theme;
        this.login = login;
        this.router = router;
    }
    enableDark() {
        this.theme.enableDark();
        this.theme.setDarkStorage();
    }
    enableLight() {
        this.theme.enableLight();
        this.theme.setLightStorage();
    }
    update(e) {
        e.detail.checked ? this.enableDark() : this.enableLight();
    }
    ngOnInit() {
        this.getLogueado();
        this.darkMode = this.theme.isDarkMode();
    }
    getLogueado() {
        this.getProfile(this.uid);
        // this.aut.authState
        //   .subscribe(
        //     user => {
        //       if (user) {
        //         console.log('logeado');
        //         this.uid = user.uid;
        //         console.log(this.uid);
        //         this.getProfile(this.uid);
        //       } else {
        //         this.rout.navigateByUrl('/login');
        //       }
        //     },
        //     () => {
        //       this.rout.navigateByUrl('/login');
        //     }
        //   );
    }
    getProfile(id) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            this.empty = true;
            // await this.services.getProfile(id).subscribe((data => {
            //   console.log(data);
            //   if (data.length === 0) {
            //     this.empty = false;
            //     console.log('empty');
            //   } else {
            //     this.empty = true;
            //     this.item = data;
            //   }
            // }));
        });
    }
    goedit() {
        // this.rout.navigateByUrl(`/edit-profile`);
    }
    signOut() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const res = yield this.login.logout();
            this.nav.navigateRoot('login');
        });
    }
};
ProfilePage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"] },
    { type: _services_services_service__WEBPACK_IMPORTED_MODULE_4__["ServicesService"] },
    { type: _services_theme_service__WEBPACK_IMPORTED_MODULE_5__["ThemeService"] },
    { type: _services_request_login_request_service__WEBPACK_IMPORTED_MODULE_6__["LoginRequestService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"] }
];
ProfilePage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-profile',
        template: __webpack_require__(/*! raw-loader!./profile.page.html */ "./node_modules/raw-loader/index.js!./src/app/pages/profile/profile.page.html"),
        styles: [__webpack_require__(/*! ./profile.page.scss */ "./src/app/pages/profile/profile.page.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"],
        _services_services_service__WEBPACK_IMPORTED_MODULE_4__["ServicesService"],
        _services_theme_service__WEBPACK_IMPORTED_MODULE_5__["ThemeService"],
        _services_request_login_request_service__WEBPACK_IMPORTED_MODULE_6__["LoginRequestService"],
        _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"]])
], ProfilePage);



/***/ })

}]);
//# sourceMappingURL=profile-profile-module-es2015.js.map