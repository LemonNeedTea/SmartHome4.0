(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-thermostat-thermostat-module"],{

/***/ "./node_modules/progressbar.js/src/circle.js":
/*!***************************************************!*\
  !*** ./node_modules/progressbar.js/src/circle.js ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Circle shaped progress bar

var Shape = __webpack_require__(/*! ./shape */ "./node_modules/progressbar.js/src/shape.js");
var utils = __webpack_require__(/*! ./utils */ "./node_modules/progressbar.js/src/utils.js");

var Circle = function Circle(container, options) {
    // Use two arcs to form a circle
    // See this answer http://stackoverflow.com/a/10477334/1446092
    this._pathTemplate =
        'M 50,50 m 0,-{radius}' +
        ' a {radius},{radius} 0 1 1 0,{2radius}' +
        ' a {radius},{radius} 0 1 1 0,-{2radius}';

    this.containerAspectRatio = 1;

    Shape.apply(this, arguments);
};

Circle.prototype = new Shape();
Circle.prototype.constructor = Circle;

Circle.prototype._pathString = function _pathString(opts) {
    var widthOfWider = opts.strokeWidth;
    if (opts.trailWidth && opts.trailWidth > opts.strokeWidth) {
        widthOfWider = opts.trailWidth;
    }

    var r = 50 - widthOfWider / 2;

    return utils.render(this._pathTemplate, {
        radius: r,
        '2radius': r * 2
    });
};

Circle.prototype._trailString = function _trailString(opts) {
    return this._pathString(opts);
};

module.exports = Circle;


/***/ }),

/***/ "./node_modules/progressbar.js/src/line.js":
/*!*************************************************!*\
  !*** ./node_modules/progressbar.js/src/line.js ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Line shaped progress bar

var Shape = __webpack_require__(/*! ./shape */ "./node_modules/progressbar.js/src/shape.js");
var utils = __webpack_require__(/*! ./utils */ "./node_modules/progressbar.js/src/utils.js");

var Line = function Line(container, options) {
    this._pathTemplate = 'M 0,{center} L 100,{center}';
    Shape.apply(this, arguments);
};

Line.prototype = new Shape();
Line.prototype.constructor = Line;

Line.prototype._initializeSvg = function _initializeSvg(svg, opts) {
    svg.setAttribute('viewBox', '0 0 100 ' + opts.strokeWidth);
    svg.setAttribute('preserveAspectRatio', 'none');
};

Line.prototype._pathString = function _pathString(opts) {
    return utils.render(this._pathTemplate, {
        center: opts.strokeWidth / 2
    });
};

Line.prototype._trailString = function _trailString(opts) {
    return this._pathString(opts);
};

module.exports = Line;


/***/ }),

/***/ "./node_modules/progressbar.js/src/main.js":
/*!*************************************************!*\
  !*** ./node_modules/progressbar.js/src/main.js ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = {
    // Higher level API, different shaped progress bars
    Line: __webpack_require__(/*! ./line */ "./node_modules/progressbar.js/src/line.js"),
    Circle: __webpack_require__(/*! ./circle */ "./node_modules/progressbar.js/src/circle.js"),
    SemiCircle: __webpack_require__(/*! ./semicircle */ "./node_modules/progressbar.js/src/semicircle.js"),
    Square: __webpack_require__(/*! ./square */ "./node_modules/progressbar.js/src/square.js"),

    // Lower level API to use any SVG path
    Path: __webpack_require__(/*! ./path */ "./node_modules/progressbar.js/src/path.js"),

    // Base-class for creating new custom shapes
    // to be in line with the API of built-in shapes
    // Undocumented.
    Shape: __webpack_require__(/*! ./shape */ "./node_modules/progressbar.js/src/shape.js"),

    // Internal utils, undocumented.
    utils: __webpack_require__(/*! ./utils */ "./node_modules/progressbar.js/src/utils.js")
};


/***/ }),

/***/ "./node_modules/progressbar.js/src/path.js":
/*!*************************************************!*\
  !*** ./node_modules/progressbar.js/src/path.js ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Lower level API to animate any kind of svg path

var shifty = __webpack_require__(/*! shifty */ "./node_modules/shifty/dist/shifty.js");
var utils = __webpack_require__(/*! ./utils */ "./node_modules/progressbar.js/src/utils.js");

var Tweenable = shifty.Tweenable;

var EASING_ALIASES = {
    easeIn: 'easeInCubic',
    easeOut: 'easeOutCubic',
    easeInOut: 'easeInOutCubic'
};

var Path = function Path(path, opts) {
    // Throw a better error if not initialized with `new` keyword
    if (!(this instanceof Path)) {
        throw new Error('Constructor was called without new keyword');
    }

    // Default parameters for animation
    opts = utils.extend({
        delay: 0,
        duration: 800,
        easing: 'linear',
        from: {},
        to: {},
        step: function() {}
    }, opts);

    var element;
    if (utils.isString(path)) {
        element = document.querySelector(path);
    } else {
        element = path;
    }

    // Reveal .path as public attribute
    this.path = element;
    this._opts = opts;
    this._tweenable = null;

    // Set up the starting positions
    var length = this.path.getTotalLength();
    this.path.style.strokeDasharray = length + ' ' + length;
    this.set(0);
};

Path.prototype.value = function value() {
    var offset = this._getComputedDashOffset();
    var length = this.path.getTotalLength();

    var progress = 1 - offset / length;
    // Round number to prevent returning very small number like 1e-30, which
    // is practically 0
    return parseFloat(progress.toFixed(6), 10);
};

Path.prototype.set = function set(progress) {
    this.stop();

    this.path.style.strokeDashoffset = this._progressToOffset(progress);

    var step = this._opts.step;
    if (utils.isFunction(step)) {
        var easing = this._easing(this._opts.easing);
        var values = this._calculateTo(progress, easing);
        var reference = this._opts.shape || this;
        step(values, reference, this._opts.attachment);
    }
};

Path.prototype.stop = function stop() {
    this._stopTween();
    this.path.style.strokeDashoffset = this._getComputedDashOffset();
};

// Method introduced here:
// http://jakearchibald.com/2013/animated-line-drawing-svg/
Path.prototype.animate = function animate(progress, opts, cb) {
    opts = opts || {};

    if (utils.isFunction(opts)) {
        cb = opts;
        opts = {};
    }

    var passedOpts = utils.extend({}, opts);

    // Copy default opts to new object so defaults are not modified
    var defaultOpts = utils.extend({}, this._opts);
    opts = utils.extend(defaultOpts, opts);

    var shiftyEasing = this._easing(opts.easing);
    var values = this._resolveFromAndTo(progress, shiftyEasing, passedOpts);

    this.stop();

    // Trigger a layout so styles are calculated & the browser
    // picks up the starting position before animating
    this.path.getBoundingClientRect();

    var offset = this._getComputedDashOffset();
    var newOffset = this._progressToOffset(progress);

    var self = this;
    this._tweenable = new Tweenable();
    this._tweenable.tween({
        from: utils.extend({ offset: offset }, values.from),
        to: utils.extend({ offset: newOffset }, values.to),
        duration: opts.duration,
        delay: opts.delay,
        easing: shiftyEasing,
        step: function(state) {
            self.path.style.strokeDashoffset = state.offset;
            var reference = opts.shape || self;
            opts.step(state, reference, opts.attachment);
        }
    }).then(function(state) {
        if (utils.isFunction(cb)) {
            cb();
        }
    });
};

Path.prototype._getComputedDashOffset = function _getComputedDashOffset() {
    var computedStyle = window.getComputedStyle(this.path, null);
    return parseFloat(computedStyle.getPropertyValue('stroke-dashoffset'), 10);
};

Path.prototype._progressToOffset = function _progressToOffset(progress) {
    var length = this.path.getTotalLength();
    return length - progress * length;
};

// Resolves from and to values for animation.
Path.prototype._resolveFromAndTo = function _resolveFromAndTo(progress, easing, opts) {
    if (opts.from && opts.to) {
        return {
            from: opts.from,
            to: opts.to
        };
    }

    return {
        from: this._calculateFrom(easing),
        to: this._calculateTo(progress, easing)
    };
};

// Calculate `from` values from options passed at initialization
Path.prototype._calculateFrom = function _calculateFrom(easing) {
    return shifty.interpolate(this._opts.from, this._opts.to, this.value(), easing);
};

// Calculate `to` values from options passed at initialization
Path.prototype._calculateTo = function _calculateTo(progress, easing) {
    return shifty.interpolate(this._opts.from, this._opts.to, progress, easing);
};

Path.prototype._stopTween = function _stopTween() {
    if (this._tweenable !== null) {
        this._tweenable.stop();
        this._tweenable = null;
    }
};

Path.prototype._easing = function _easing(easing) {
    if (EASING_ALIASES.hasOwnProperty(easing)) {
        return EASING_ALIASES[easing];
    }

    return easing;
};

module.exports = Path;


/***/ }),

/***/ "./node_modules/progressbar.js/src/semicircle.js":
/*!*******************************************************!*\
  !*** ./node_modules/progressbar.js/src/semicircle.js ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Semi-SemiCircle shaped progress bar

var Shape = __webpack_require__(/*! ./shape */ "./node_modules/progressbar.js/src/shape.js");
var Circle = __webpack_require__(/*! ./circle */ "./node_modules/progressbar.js/src/circle.js");
var utils = __webpack_require__(/*! ./utils */ "./node_modules/progressbar.js/src/utils.js");

var SemiCircle = function SemiCircle(container, options) {
    // Use one arc to form a SemiCircle
    // See this answer http://stackoverflow.com/a/10477334/1446092
    this._pathTemplate =
        'M 50,50 m -{radius},0' +
        ' a {radius},{radius} 0 1 1 {2radius},0';

    this.containerAspectRatio = 2;

    Shape.apply(this, arguments);
};

SemiCircle.prototype = new Shape();
SemiCircle.prototype.constructor = SemiCircle;

SemiCircle.prototype._initializeSvg = function _initializeSvg(svg, opts) {
    svg.setAttribute('viewBox', '0 0 100 50');
};

SemiCircle.prototype._initializeTextContainer = function _initializeTextContainer(
    opts,
    container,
    textContainer
) {
    if (opts.text.style) {
        // Reset top style
        textContainer.style.top = 'auto';
        textContainer.style.bottom = '0';

        if (opts.text.alignToBottom) {
            utils.setStyle(textContainer, 'transform', 'translate(-50%, 0)');
        } else {
            utils.setStyle(textContainer, 'transform', 'translate(-50%, 50%)');
        }
    }
};

// Share functionality with Circle, just have different path
SemiCircle.prototype._pathString = Circle.prototype._pathString;
SemiCircle.prototype._trailString = Circle.prototype._trailString;

module.exports = SemiCircle;


/***/ }),

/***/ "./node_modules/progressbar.js/src/shape.js":
/*!**************************************************!*\
  !*** ./node_modules/progressbar.js/src/shape.js ***!
  \**************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Base object for different progress bar shapes

var Path = __webpack_require__(/*! ./path */ "./node_modules/progressbar.js/src/path.js");
var utils = __webpack_require__(/*! ./utils */ "./node_modules/progressbar.js/src/utils.js");

var DESTROYED_ERROR = 'Object is destroyed';

var Shape = function Shape(container, opts) {
    // Throw a better error if progress bars are not initialized with `new`
    // keyword
    if (!(this instanceof Shape)) {
        throw new Error('Constructor was called without new keyword');
    }

    // Prevent calling constructor without parameters so inheritance
    // works correctly. To understand, this is how Shape is inherited:
    //
    //   Line.prototype = new Shape();
    //
    // We just want to set the prototype for Line.
    if (arguments.length === 0) {
        return;
    }

    // Default parameters for progress bar creation
    this._opts = utils.extend({
        color: '#555',
        strokeWidth: 1.0,
        trailColor: null,
        trailWidth: null,
        fill: null,
        text: {
            style: {
                color: null,
                position: 'absolute',
                left: '50%',
                top: '50%',
                padding: 0,
                margin: 0,
                transform: {
                    prefix: true,
                    value: 'translate(-50%, -50%)'
                }
            },
            autoStyleContainer: true,
            alignToBottom: true,
            value: null,
            className: 'progressbar-text'
        },
        svgStyle: {
            display: 'block',
            width: '100%'
        },
        warnings: false
    }, opts, true);  // Use recursive extend

    // If user specifies e.g. svgStyle or text style, the whole object
    // should replace the defaults to make working with styles easier
    if (utils.isObject(opts) && opts.svgStyle !== undefined) {
        this._opts.svgStyle = opts.svgStyle;
    }
    if (utils.isObject(opts) && utils.isObject(opts.text) && opts.text.style !== undefined) {
        this._opts.text.style = opts.text.style;
    }

    var svgView = this._createSvgView(this._opts);

    var element;
    if (utils.isString(container)) {
        element = document.querySelector(container);
    } else {
        element = container;
    }

    if (!element) {
        throw new Error('Container does not exist: ' + container);
    }

    this._container = element;
    this._container.appendChild(svgView.svg);
    if (this._opts.warnings) {
        this._warnContainerAspectRatio(this._container);
    }

    if (this._opts.svgStyle) {
        utils.setStyles(svgView.svg, this._opts.svgStyle);
    }

    // Expose public attributes before Path initialization
    this.svg = svgView.svg;
    this.path = svgView.path;
    this.trail = svgView.trail;
    this.text = null;

    var newOpts = utils.extend({
        attachment: undefined,
        shape: this
    }, this._opts);
    this._progressPath = new Path(svgView.path, newOpts);

    if (utils.isObject(this._opts.text) && this._opts.text.value !== null) {
        this.setText(this._opts.text.value);
    }
};

Shape.prototype.animate = function animate(progress, opts, cb) {
    if (this._progressPath === null) {
        throw new Error(DESTROYED_ERROR);
    }

    this._progressPath.animate(progress, opts, cb);
};

Shape.prototype.stop = function stop() {
    if (this._progressPath === null) {
        throw new Error(DESTROYED_ERROR);
    }

    // Don't crash if stop is called inside step function
    if (this._progressPath === undefined) {
        return;
    }

    this._progressPath.stop();
};

Shape.prototype.pause = function pause() {
    if (this._progressPath === null) {
        throw new Error(DESTROYED_ERROR);
    }

    if (this._progressPath === undefined) {
        return;
    }

    if (!this._progressPath._tweenable) {
        // It seems that we can't pause this
        return;
    }

    this._progressPath._tweenable.pause();
};

Shape.prototype.resume = function resume() {
    if (this._progressPath === null) {
        throw new Error(DESTROYED_ERROR);
    }

    if (this._progressPath === undefined) {
        return;
    }

    if (!this._progressPath._tweenable) {
        // It seems that we can't resume this
        return;
    }

    this._progressPath._tweenable.resume();
};

Shape.prototype.destroy = function destroy() {
    if (this._progressPath === null) {
        throw new Error(DESTROYED_ERROR);
    }

    this.stop();
    this.svg.parentNode.removeChild(this.svg);
    this.svg = null;
    this.path = null;
    this.trail = null;
    this._progressPath = null;

    if (this.text !== null) {
        this.text.parentNode.removeChild(this.text);
        this.text = null;
    }
};

Shape.prototype.set = function set(progress) {
    if (this._progressPath === null) {
        throw new Error(DESTROYED_ERROR);
    }

    this._progressPath.set(progress);
};

Shape.prototype.value = function value() {
    if (this._progressPath === null) {
        throw new Error(DESTROYED_ERROR);
    }

    if (this._progressPath === undefined) {
        return 0;
    }

    return this._progressPath.value();
};

Shape.prototype.setText = function setText(newText) {
    if (this._progressPath === null) {
        throw new Error(DESTROYED_ERROR);
    }

    if (this.text === null) {
        // Create new text node
        this.text = this._createTextContainer(this._opts, this._container);
        this._container.appendChild(this.text);
    }

    // Remove previous text and add new
    if (utils.isObject(newText)) {
        utils.removeChildren(this.text);
        this.text.appendChild(newText);
    } else {
        this.text.innerHTML = newText;
    }
};

Shape.prototype._createSvgView = function _createSvgView(opts) {
    var svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    this._initializeSvg(svg, opts);

    var trailPath = null;
    // Each option listed in the if condition are 'triggers' for creating
    // the trail path
    if (opts.trailColor || opts.trailWidth) {
        trailPath = this._createTrail(opts);
        svg.appendChild(trailPath);
    }

    var path = this._createPath(opts);
    svg.appendChild(path);

    return {
        svg: svg,
        path: path,
        trail: trailPath
    };
};

Shape.prototype._initializeSvg = function _initializeSvg(svg, opts) {
    svg.setAttribute('viewBox', '0 0 100 100');
};

Shape.prototype._createPath = function _createPath(opts) {
    var pathString = this._pathString(opts);
    return this._createPathElement(pathString, opts);
};

Shape.prototype._createTrail = function _createTrail(opts) {
    // Create path string with original passed options
    var pathString = this._trailString(opts);

    // Prevent modifying original
    var newOpts = utils.extend({}, opts);

    // Defaults for parameters which modify trail path
    if (!newOpts.trailColor) {
        newOpts.trailColor = '#eee';
    }
    if (!newOpts.trailWidth) {
        newOpts.trailWidth = newOpts.strokeWidth;
    }

    newOpts.color = newOpts.trailColor;
    newOpts.strokeWidth = newOpts.trailWidth;

    // When trail path is set, fill must be set for it instead of the
    // actual path to prevent trail stroke from clipping
    newOpts.fill = null;

    return this._createPathElement(pathString, newOpts);
};

Shape.prototype._createPathElement = function _createPathElement(pathString, opts) {
    var path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
    path.setAttribute('d', pathString);
    path.setAttribute('stroke', opts.color);
    path.setAttribute('stroke-width', opts.strokeWidth);

    if (opts.fill) {
        path.setAttribute('fill', opts.fill);
    } else {
        path.setAttribute('fill-opacity', '0');
    }

    return path;
};

Shape.prototype._createTextContainer = function _createTextContainer(opts, container) {
    var textContainer = document.createElement('div');
    textContainer.className = opts.text.className;

    var textStyle = opts.text.style;
    if (textStyle) {
        if (opts.text.autoStyleContainer) {
            container.style.position = 'relative';
        }

        utils.setStyles(textContainer, textStyle);
        // Default text color to progress bar's color
        if (!textStyle.color) {
            textContainer.style.color = opts.color;
        }
    }

    this._initializeTextContainer(opts, container, textContainer);
    return textContainer;
};

// Give custom shapes possibility to modify text element
Shape.prototype._initializeTextContainer = function(opts, container, element) {
    // By default, no-op
    // Custom shapes should respect API options, such as text.style
};

Shape.prototype._pathString = function _pathString(opts) {
    throw new Error('Override this function for each progress bar');
};

Shape.prototype._trailString = function _trailString(opts) {
    throw new Error('Override this function for each progress bar');
};

Shape.prototype._warnContainerAspectRatio = function _warnContainerAspectRatio(container) {
    if (!this.containerAspectRatio) {
        return;
    }

    var computedStyle = window.getComputedStyle(container, null);
    var width = parseFloat(computedStyle.getPropertyValue('width'), 10);
    var height = parseFloat(computedStyle.getPropertyValue('height'), 10);
    if (!utils.floatEquals(this.containerAspectRatio, width / height)) {
        console.warn(
            'Incorrect aspect ratio of container',
            '#' + container.id,
            'detected:',
            computedStyle.getPropertyValue('width') + '(width)',
            '/',
            computedStyle.getPropertyValue('height') + '(height)',
            '=',
            width / height
        );

        console.warn(
            'Aspect ratio of should be',
            this.containerAspectRatio
        );
    }
};

module.exports = Shape;


/***/ }),

/***/ "./node_modules/progressbar.js/src/square.js":
/*!***************************************************!*\
  !*** ./node_modules/progressbar.js/src/square.js ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Square shaped progress bar
// Note: Square is not core part of API anymore. It's left here
//       for reference. square is not included to the progressbar
//       build anymore

var Shape = __webpack_require__(/*! ./shape */ "./node_modules/progressbar.js/src/shape.js");
var utils = __webpack_require__(/*! ./utils */ "./node_modules/progressbar.js/src/utils.js");

var Square = function Square(container, options) {
    this._pathTemplate =
        'M 0,{halfOfStrokeWidth}' +
        ' L {width},{halfOfStrokeWidth}' +
        ' L {width},{width}' +
        ' L {halfOfStrokeWidth},{width}' +
        ' L {halfOfStrokeWidth},{strokeWidth}';

    this._trailTemplate =
        'M {startMargin},{halfOfStrokeWidth}' +
        ' L {width},{halfOfStrokeWidth}' +
        ' L {width},{width}' +
        ' L {halfOfStrokeWidth},{width}' +
        ' L {halfOfStrokeWidth},{halfOfStrokeWidth}';

    Shape.apply(this, arguments);
};

Square.prototype = new Shape();
Square.prototype.constructor = Square;

Square.prototype._pathString = function _pathString(opts) {
    var w = 100 - opts.strokeWidth / 2;

    return utils.render(this._pathTemplate, {
        width: w,
        strokeWidth: opts.strokeWidth,
        halfOfStrokeWidth: opts.strokeWidth / 2
    });
};

Square.prototype._trailString = function _trailString(opts) {
    var w = 100 - opts.strokeWidth / 2;

    return utils.render(this._trailTemplate, {
        width: w,
        strokeWidth: opts.strokeWidth,
        halfOfStrokeWidth: opts.strokeWidth / 2,
        startMargin: opts.strokeWidth / 2 - opts.trailWidth / 2
    });
};

module.exports = Square;


/***/ }),

/***/ "./node_modules/progressbar.js/src/utils.js":
/*!**************************************************!*\
  !*** ./node_modules/progressbar.js/src/utils.js ***!
  \**************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

// Utility functions

var PREFIXES = 'Webkit Moz O ms'.split(' ');
var FLOAT_COMPARISON_EPSILON = 0.001;

// Copy all attributes from source object to destination object.
// destination object is mutated.
function extend(destination, source, recursive) {
    destination = destination || {};
    source = source || {};
    recursive = recursive || false;

    for (var attrName in source) {
        if (source.hasOwnProperty(attrName)) {
            var destVal = destination[attrName];
            var sourceVal = source[attrName];
            if (recursive && isObject(destVal) && isObject(sourceVal)) {
                destination[attrName] = extend(destVal, sourceVal, recursive);
            } else {
                destination[attrName] = sourceVal;
            }
        }
    }

    return destination;
}

// Renders templates with given variables. Variables must be surrounded with
// braces without any spaces, e.g. {variable}
// All instances of variable placeholders will be replaced with given content
// Example:
// render('Hello, {message}!', {message: 'world'})
function render(template, vars) {
    var rendered = template;

    for (var key in vars) {
        if (vars.hasOwnProperty(key)) {
            var val = vars[key];
            var regExpString = '\\{' + key + '\\}';
            var regExp = new RegExp(regExpString, 'g');

            rendered = rendered.replace(regExp, val);
        }
    }

    return rendered;
}

function setStyle(element, style, value) {
    var elStyle = element.style;  // cache for performance

    for (var i = 0; i < PREFIXES.length; ++i) {
        var prefix = PREFIXES[i];
        elStyle[prefix + capitalize(style)] = value;
    }

    elStyle[style] = value;
}

function setStyles(element, styles) {
    forEachObject(styles, function(styleValue, styleName) {
        // Allow disabling some individual styles by setting them
        // to null or undefined
        if (styleValue === null || styleValue === undefined) {
            return;
        }

        // If style's value is {prefix: true, value: '50%'},
        // Set also browser prefixed styles
        if (isObject(styleValue) && styleValue.prefix === true) {
            setStyle(element, styleName, styleValue.value);
        } else {
            element.style[styleName] = styleValue;
        }
    });
}

function capitalize(text) {
    return text.charAt(0).toUpperCase() + text.slice(1);
}

function isString(obj) {
    return typeof obj === 'string' || obj instanceof String;
}

function isFunction(obj) {
    return typeof obj === 'function';
}

function isArray(obj) {
    return Object.prototype.toString.call(obj) === '[object Array]';
}

// Returns true if `obj` is object as in {a: 1, b: 2}, not if it's function or
// array
function isObject(obj) {
    if (isArray(obj)) {
        return false;
    }

    var type = typeof obj;
    return type === 'object' && !!obj;
}

function forEachObject(object, callback) {
    for (var key in object) {
        if (object.hasOwnProperty(key)) {
            var val = object[key];
            callback(val, key);
        }
    }
}

function floatEquals(a, b) {
    return Math.abs(a - b) < FLOAT_COMPARISON_EPSILON;
}

// https://coderwall.com/p/nygghw/don-t-use-innerhtml-to-empty-dom-elements
function removeChildren(el) {
    while (el.firstChild) {
        el.removeChild(el.firstChild);
    }
}

module.exports = {
    extend: extend,
    render: render,
    setStyle: setStyle,
    setStyles: setStyles,
    capitalize: capitalize,
    isString: isString,
    isFunction: isFunction,
    isObject: isObject,
    forEachObject: forEachObject,
    floatEquals: floatEquals,
    removeChildren: removeChildren
};


/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/pages/modals/air-setting-modal/air-setting-modal.page.html":
/*!******************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/pages/modals/air-setting-modal/air-setting-modal.page.html ***!
  \******************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-content fullscreen>\n\n</ion-content>\n<ion-footer>\n  <ion-grid class=\"mode\">\n    <ion-row>\n      <ion-col *ngFor=\"let item of dataList\" size='4'>\n        <img src=\"../../../assets/air/{{item.F_Icon}}\" (click)=\"dismiss(item)\" />\n        {{item.F_Name?item.F_Name:item.F_ParamsName}}\n        <!-- {{config.chinese?item.F_ParamsName:item.F_ParamsName_En}} -->\n      </ion-col>\n\n    </ion-row>\n  </ion-grid>\n  <div class=\"dismiss\">\n    <ion-icon name=\"arrow-down\" (click)=\"dismiss()\"></ion-icon>\n  </div>\n</ion-footer>"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/pages/thermostat/thermostat.page.html":
/*!*********************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/pages/thermostat/thermostat.page.html ***!
  \*********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header no-border>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button></ion-back-button>\n    </ion-buttons>\n    <ion-title color='primary'>{{name}}</ion-title>\n    <ion-buttons slot=\"end\">\n      <ion-button (click)=\"goMorePage()\">\n        <ion-icon slot=\"icon-only\" name=\"more\"></ion-icon>\n      </ion-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n<!-- <ion-content>\n\n  <ion-textarea rows=\"6\" cols=\"20\" [(ngModel)]=\"text\">\n\n\n  </ion-textarea>\n\n  <ion-input [(ngModel)]=\"code\"></ion-input>\n  <ion-input  [(ngModel)]=\"value\"></ion-input>\n  <ion-button (click)=\"onClick()\">\n    发 送\n  </ion-button>\n\n</ion-content> -->\n\n<ion-content fullscreen>\n  <div style=\"width: 100%;\">\n    <div class=\"room-temp-row\">\n      <div class=\"room-temp\">{{'室温'|translate}}&nbsp;&nbsp;{{roomTempData}}°C</div>\n    </div>\n  </div>\n  <ion-grid>\n    <ion-row>\n      <ion-col size=\"6\" class=\"col-clock\">\n        <div *ngIf=\"keyboardLock | bool\">\n          <img src=\"../../assets/air/lock.png\" />\n          <div>键盘锁</div>\n        </div>\n\n      </ion-col>\n      <ion-col size=\"6\" class=\"col-clock\">\n        <div *ngIf=\"linkage | bool\">\n          <img src=\"../../assets/air/connect.png\" />\n          <div>{{'联动'|translate}}</div>\n        </div>\n\n      </ion-col>\n    </ion-row>\n    <ion-row>\n\n      <ion-col class=\"temp-add\" size=\"2\">\n        <div (click)=\"tempAdd()\" [hidden]=\"!open\">\n          <ion-icon name=\"add\"></ion-icon>\n        </div>\n        <!-- <button ion-button icon-only (click)=\"tempAdd()\" [hidden]=\"!open\">\n          <ion-icon name=\"add\"></ion-icon>\n        </button> -->\n        <!-- <ion-button> -->\n        <!-- </ion-button> -->\n\n\n      </ion-col>\n      <ion-col size=\"8\" style=\"display: flex;justify-content: center;align-items: center;\">\n        <div id=\"circlebar\" class=\"container\">\n          <div class=\"temp-show\">\n            <p><span>\n                {{temp | number:'1.1-1'}}\n                <!-- <ion-multi-picker [multiPickerColumns]=\"tempColumns\" cancelText=\"{{'取消' | translate}}\"\n                  doneText=\"{{'确定' | translate}}\" [(ngModel)]=\"temp\" (ngModelChange)=\"changeTemp()\" [disabled]=\"!open\">\n                </ion-multi-picker> -->\n\n              </span>°C</p>\n            <p [hidden]=\"!open\">\n              {{selectedSpped.F_ParamsName?selectedSpped.F_ParamsName:'自动'}}\n              <!-- {{(selectedSpped.F_ParamsName?selectedSpped.F_ParamsName:'自动') |translate}} -->\n              &nbsp;&nbsp;\n              {{selectedMode.F_ParamsName}}\n              <!-- {{config.chinese?selectedMode.F_ParamsName:selectedMode.F_ParamsName_En}} -->\n            </p>\n\n          </div>\n        </div>\n      </ion-col>\n\n\n      <ion-col class=\"temp-sub\" size=\"2\">\n        <!-- <button ion-button icon-only (click)=\"tempSub()\"> -->\n      <div (click)=\"tempSub()\" [hidden]=\"!open\">\n        <ion-icon name=\"remove\"></ion-icon>\n\n      </div>\n      </ion-col>\n    </ion-row>\n    <ion-row>\n      <ion-col size=\"6\" class=\"col-clock\">\n        <div *ngIf=\"valve1  | bool\">\n\n          <img src=\"../../assets/air/valve.png\" />\n          <div>{{'水阀'|translate}}1</div>\n        </div>\n\n      </ion-col>\n      <ion-col size=\"6\" class=\"col-clock\">\n        <div *ngIf=\"valve2 | bool\">\n\n          <img src=\"../../assets/air/valve.png\" />\n          <div>{{'水阀'|translate}}2</div>\n        </div>\n\n      </ion-col>\n    </ion-row>\n    <!-- <ion-row >\n      <ion-col size=\"3\" class=\"col-center\">\n        <div class=\"timer-div\" (click)=\"presentShowModal(1,'定时1')\">\n          <span [ngClass]=\"{'timer-close': !timer1Open}\"></span>\n          {{'定时'|translate}}1\n        </div>\n      </ion-col>\n      <ion-col size=\"3\" class=\"col-center\">\n        <div class=\"timer-div\" (click)=\"presentShowModal(2,'定时2')\">\n          <span [ngClass]=\"{'timer-close': !timer2Open}\"></span>\n          {{'定时'|translate}}2\n        </div>\n      </ion-col>\n      <ion-col size=\"3\" class=\"col-center\">\n        <div class=\"timer-div\" (click)=\"presentShowModal(3,'定时3')\">\n          <span [ngClass]=\"{'timer-close': !timer3Open}\"></span>\n          {{'定时'|translate}}3\n        </div>\n      </ion-col>\n      <ion-col size=\"3\" class=\"col-center\">\n        <div class=\"timer-div\" (click)=\"presentShowModal(4,'定时4')\">\n          <span [ngClass]=\"{'timer-close': !timer4Open}\"></span>\n          {{'定时'|translate}}4\n        </div>\n      </ion-col>\n    </ion-row> -->\n  </ion-grid>\n\n\n</ion-content>\n<ion-footer>\n  <ion-grid>\n    <ion-row class=\"speed\">\n      <ion-col size=\"4\">\n        {{'风速设定'|translate}}\n      </ion-col>\n      <ion-col size=\"8\">\n        <ul>\n          <li [ngClass]=\"{'selected': !speedMode}\" (click)=\"setSpeedMode()\">自</li>\n          <li *ngFor=\"let item of speedKV\" [ngClass]=\"{'selected': selectedSpped.F_ID==item.F_ID}\"\n            (click)=\"setSpeed(item)\">{{item.F_ParamsName |translate}}</li>\n          <!-- <li [ngClass]=\"{'selected': speedModel==0}\" (click)=\"setSpeed(0)\">自动</li>\n          <li [ngClass]=\"{'selected': speedModel==3}\" (click)=\"setSpeed(3)\">高</li>\n          <li [ngClass]=\"{'selected': speedModel==2}\" (click)=\"setSpeed(2)\">中</li>\n          <li [ngClass]=\"{'selected': speedModel==1}\" (click)=\"setSpeed(1)\">低</li> -->\n        </ul>\n      </ion-col>\n    </ion-row>\n    <ion-row>\n      <ion-grid class=\"mode\" [ngClass]=\"{'border-top-none': !open}\">\n        <ion-row>\n          <ion-col size=\"4\">\n            <div class=\"mode-div\" [hidden]=\"!open\">\n              <img *ngIf=\"selectedMode.F_Icon\" [src]=\"'../../../assets/air/'+selectedMode.F_Icon\" [ngClass]=\"selectedMode.F_Class\"\n                (click)=\"setMode()\" />\n              <img *ngIf=\" false\" (click)=\"setMode()\" />\n              {{selectedMode.F_ParamsName}}\n              <!-- {{config.chinese?selectedMode.F_ParamsName:selectedMode.F_ParamsName_En}} -->\n            </div>\n\n          </ion-col>\n          <ion-col size=\"4\">\n            <img src=\"../../assets/check.png\" [ngClass]=\"{'selected': open}\" (click)=\"setOpen()\" />\n\n\n            {{'开关'|translate}}\n          </ion-col>\n          <ion-col size=\"4\" [hidden]=\"!open\">\n            <img src=\"../../assets/air/eco.png\" [ngClass]=\"{'eco-color': eco}\" (click)='setEco()' />\n\n\n\n            {{'节能'|translate}}\n          </ion-col>\n        </ion-row>\n      </ion-grid>\n    </ion-row>\n  </ion-grid>\n</ion-footer>"

/***/ }),

/***/ "./node_modules/shifty/dist/shifty.js":
/*!********************************************!*\
  !*** ./node_modules/shifty/dist/shifty.js ***!
  \********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

/*! Shifty 2.8.3 - https://github.com/jeremyckahn/shifty */
!function(t,n){ true?module.exports=n():undefined}(window,(function(){return function(t){var n={};function e(r){if(n[r])return n[r].exports;var i=n[r]={i:r,l:!1,exports:{}};return t[r].call(i.exports,i,i.exports,e),i.l=!0,i.exports}return e.m=t,e.c=n,e.d=function(t,n,r){e.o(t,n)||Object.defineProperty(t,n,{enumerable:!0,get:r})},e.r=function(t){"undefined"!=typeof Symbol&&Symbol.toStringTag&&Object.defineProperty(t,Symbol.toStringTag,{value:"Module"}),Object.defineProperty(t,"__esModule",{value:!0})},e.t=function(t,n){if(1&n&&(t=e(t)),8&n)return t;if(4&n&&"object"==typeof t&&t&&t.__esModule)return t;var r=Object.create(null);if(e.r(r),Object.defineProperty(r,"default",{enumerable:!0,value:t}),2&n&&"string"!=typeof t)for(var i in t)e.d(r,i,function(n){return t[n]}.bind(null,i));return r},e.n=function(t){var n=t&&t.__esModule?function(){return t.default}:function(){return t};return e.d(n,"a",n),n},e.o=function(t,n){return Object.prototype.hasOwnProperty.call(t,n)},e.p="",e(e.s=3)}([function(t,n,e){"use strict";(function(t){e.d(n,"e",(function(){return v})),e.d(n,"c",(function(){return _})),e.d(n,"b",(function(){return m})),e.d(n,"a",(function(){return b})),e.d(n,"d",(function(){return w}));var r=e(1);function i(t,n){for(var e=0;e<n.length;e++){var r=n[e];r.enumerable=r.enumerable||!1,r.configurable=!0,"value"in r&&(r.writable=!0),Object.defineProperty(t,r.key,r)}}function u(t){return(u="function"==typeof Symbol&&"symbol"==typeof Symbol.iterator?function(t){return typeof t}:function(t){return t&&"function"==typeof Symbol&&t.constructor===Symbol&&t!==Symbol.prototype?"symbol":typeof t})(t)}function o(t,n){var e=Object.keys(t);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(t);n&&(r=r.filter((function(n){return Object.getOwnPropertyDescriptor(t,n).enumerable}))),e.push.apply(e,r)}return e}function a(t){for(var n=1;n<arguments.length;n++){var e=null!=arguments[n]?arguments[n]:{};n%2?o(Object(e),!0).forEach((function(n){c(t,n,e[n])})):Object.getOwnPropertyDescriptors?Object.defineProperties(t,Object.getOwnPropertyDescriptors(e)):o(Object(e)).forEach((function(n){Object.defineProperty(t,n,Object.getOwnPropertyDescriptor(e,n))}))}return t}function c(t,n,e){return n in t?Object.defineProperty(t,n,{value:e,enumerable:!0,configurable:!0,writable:!0}):t[n]=e,t}var f="undefined"!=typeof window?window:t,s=f.requestAnimationFrame||f.webkitRequestAnimationFrame||f.oRequestAnimationFrame||f.msRequestAnimationFrame||f.mozCancelRequestAnimationFrame&&f.mozRequestAnimationFrame||setTimeout,l=function(){},h=null,p=null,d=a({},r),v=function(t,n,e,r,i,u,o){var a=t<u?0:(t-u)/i;for(var c in n){var f=o[c],s=f.call?f:d[f],l=e[c];n[c]=l+(r[c]-l)*s(a)}return n},y=function(t,n){var e=t._attachment,r=t._currentState,i=t._delay,u=t._easing,o=t._originalState,a=t._duration,c=t._step,f=t._targetState,s=t._timestamp,l=s+i+a,h=n>l?l:n,p=a-(l-h);h>=l?(c(f,e,p),t.stop(!0)):(t._applyFilter("beforeTween"),h<s+i?(h=1,a=1,s=1):s+=i,v(h,r,o,f,a,s,u),t._applyFilter("afterTween"),c(r,e,p))},_=function(){for(var t=b.now(),n=h;n;){var e=n._next;y(n,t),n=e}},m=function(t){var n=arguments.length>1&&void 0!==arguments[1]?arguments[1]:"linear",e={},r=u(n);if("string"===r||"function"===r)for(var i in t)e[i]=n;else for(var o in t)e[o]=n[o]||"linear";return e},g=function(t){if(t===h)(h=t._next)?h._previous=null:p=null;else if(t===p)(p=t._previous)?p._next=null:h=null;else{var n=t._previous,e=t._next;n._next=e,e._previous=n}t._previous=t._next=null},b=function(){function t(){var n=arguments.length>0&&void 0!==arguments[0]?arguments[0]:{},e=arguments.length>1&&void 0!==arguments[1]?arguments[1]:void 0;!function(t,n){if(!(t instanceof n))throw new TypeError("Cannot call a class as a function")}(this,t),this._currentState=n,this._configured=!1,this._filters=[],this._timestamp=null,this._next=null,this._previous=null,e&&this.setConfig(e)}var n,e,r;return n=t,(e=[{key:"_applyFilter",value:function(t){var n=!0,e=!1,r=void 0;try{for(var i,u=this._filters[Symbol.iterator]();!(n=(i=u.next()).done);n=!0){var o=i.value[t];o&&o(this)}}catch(t){e=!0,r=t}finally{try{n||null==u.return||u.return()}finally{if(e)throw r}}}},{key:"tween",value:function(){var n=arguments.length>0&&void 0!==arguments[0]?arguments[0]:void 0,e=this._attachment,r=this._configured;return!n&&r||this.setConfig(n),this._pausedAtTime=null,this._timestamp=t.now(),this._start(this.get(),e),this.resume()}},{key:"setConfig",value:function(){var n=this,e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:{},r=e.attachment,i=e.delay,u=void 0===i?0:i,o=e.duration,c=void 0===o?500:o,f=e.easing,s=e.from,h=e.promise,p=void 0===h?Promise:h,d=e.start,v=void 0===d?l:d,y=e.step,_=void 0===y?l:y,g=e.to;this._configured=!0,this._attachment=r,this._isPlaying=!1,this._pausedAtTime=null,this._scheduleId=null,this._delay=u,this._start=v,this._step=_,this._duration=c,this._currentState=a({},s||this.get()),this._originalState=this.get(),this._targetState=a({},g||this.get());var b=this._currentState;this._targetState=a({},b,{},this._targetState),this._easing=m(b,f);var w=t.filters;for(var O in this._filters.length=0,w)w[O].doesApply(this)&&this._filters.push(w[O]);return this._applyFilter("tweenCreated"),this._promise=new p((function(t,e){n._resolve=t,n._reject=e})),this._promise.catch(l),this}},{key:"get",value:function(){return a({},this._currentState)}},{key:"set",value:function(t){this._currentState=t}},{key:"pause",value:function(){if(this._isPlaying)return this._pausedAtTime=t.now(),this._isPlaying=!1,g(this),this}},{key:"resume",value:function(){if(null===this._timestamp)return this.tween();if(this._isPlaying)return this._promise;var n=t.now();return this._pausedAtTime&&(this._timestamp+=n-this._pausedAtTime,this._pausedAtTime=null),this._isPlaying=!0,null===h?(h=this,p=this,function t(){h&&(s.call(f,t,1e3/60),_())}()):(this._previous=p,p._next=this,p=this),this._promise}},{key:"seek",value:function(n){n=Math.max(n,0);var e=t.now();return this._timestamp+n===0?this:(this._timestamp=e-n,this._isPlaying||y(this,e),this)}},{key:"stop",value:function(){var t=arguments.length>0&&void 0!==arguments[0]&&arguments[0],n=this._attachment,e=this._currentState,r=this._easing,i=this._originalState,u=this._targetState;if(this._isPlaying)return this._isPlaying=!1,g(this),t?(this._applyFilter("beforeTween"),v(1,e,i,u,1,0,r),this._applyFilter("afterTween"),this._applyFilter("afterTweenEnd"),this._resolve(e,n)):this._reject(e,n),this}},{key:"isPlaying",value:function(){return this._isPlaying}},{key:"setScheduleFunction",value:function(n){t.setScheduleFunction(n)}},{key:"dispose",value:function(){for(var t in this)delete this[t]}}])&&i(n.prototype,e),r&&i(n,r),t}();function w(){var t=arguments.length>0&&void 0!==arguments[0]?arguments[0]:{},n=new b,e=n.tween(t);return e.tweenable=n,e}b.setScheduleFunction=function(t){return s=t},b.formulas=d,b.filters={},b.now=Date.now||function(){return+new Date}}).call(this,e(2))},function(t,n,e){"use strict";e.r(n),e.d(n,"linear",(function(){return r})),e.d(n,"easeInQuad",(function(){return i})),e.d(n,"easeOutQuad",(function(){return u})),e.d(n,"easeInOutQuad",(function(){return o})),e.d(n,"easeInCubic",(function(){return a})),e.d(n,"easeOutCubic",(function(){return c})),e.d(n,"easeInOutCubic",(function(){return f})),e.d(n,"easeInQuart",(function(){return s})),e.d(n,"easeOutQuart",(function(){return l})),e.d(n,"easeInOutQuart",(function(){return h})),e.d(n,"easeInQuint",(function(){return p})),e.d(n,"easeOutQuint",(function(){return d})),e.d(n,"easeInOutQuint",(function(){return v})),e.d(n,"easeInSine",(function(){return y})),e.d(n,"easeOutSine",(function(){return _})),e.d(n,"easeInOutSine",(function(){return m})),e.d(n,"easeInExpo",(function(){return g})),e.d(n,"easeOutExpo",(function(){return b})),e.d(n,"easeInOutExpo",(function(){return w})),e.d(n,"easeInCirc",(function(){return O})),e.d(n,"easeOutCirc",(function(){return S})),e.d(n,"easeInOutCirc",(function(){return j})),e.d(n,"easeOutBounce",(function(){return M})),e.d(n,"easeInBack",(function(){return k})),e.d(n,"easeOutBack",(function(){return P})),e.d(n,"easeInOutBack",(function(){return x})),e.d(n,"elastic",(function(){return T})),e.d(n,"swingFromTo",(function(){return E})),e.d(n,"swingFrom",(function(){return F})),e.d(n,"swingTo",(function(){return A})),e.d(n,"bounce",(function(){return I})),e.d(n,"bouncePast",(function(){return C})),e.d(n,"easeFromTo",(function(){return D})),e.d(n,"easeFrom",(function(){return q})),e.d(n,"easeTo",(function(){return Q}));
/*!
 * All equations are adapted from Thomas Fuchs'
 * [Scripty2](https://github.com/madrobby/scripty2/blob/master/src/effects/transitions/penner.js).
 *
 * Based on Easing Equations (c) 2003 [Robert
 * Penner](http://www.robertpenner.com/), all rights reserved. This work is
 * [subject to terms](http://www.robertpenner.com/easing_terms_of_use.html).
 */
/*!
 *  TERMS OF USE - EASING EQUATIONS
 *  Open source under the BSD License.
 *  Easing Equations (c) 2003 Robert Penner, all rights reserved.
 */
var r=function(t){return t},i=function(t){return Math.pow(t,2)},u=function(t){return-(Math.pow(t-1,2)-1)},o=function(t){return(t/=.5)<1?.5*Math.pow(t,2):-.5*((t-=2)*t-2)},a=function(t){return Math.pow(t,3)},c=function(t){return Math.pow(t-1,3)+1},f=function(t){return(t/=.5)<1?.5*Math.pow(t,3):.5*(Math.pow(t-2,3)+2)},s=function(t){return Math.pow(t,4)},l=function(t){return-(Math.pow(t-1,4)-1)},h=function(t){return(t/=.5)<1?.5*Math.pow(t,4):-.5*((t-=2)*Math.pow(t,3)-2)},p=function(t){return Math.pow(t,5)},d=function(t){return Math.pow(t-1,5)+1},v=function(t){return(t/=.5)<1?.5*Math.pow(t,5):.5*(Math.pow(t-2,5)+2)},y=function(t){return 1-Math.cos(t*(Math.PI/2))},_=function(t){return Math.sin(t*(Math.PI/2))},m=function(t){return-.5*(Math.cos(Math.PI*t)-1)},g=function(t){return 0===t?0:Math.pow(2,10*(t-1))},b=function(t){return 1===t?1:1-Math.pow(2,-10*t)},w=function(t){return 0===t?0:1===t?1:(t/=.5)<1?.5*Math.pow(2,10*(t-1)):.5*(2-Math.pow(2,-10*--t))},O=function(t){return-(Math.sqrt(1-t*t)-1)},S=function(t){return Math.sqrt(1-Math.pow(t-1,2))},j=function(t){return(t/=.5)<1?-.5*(Math.sqrt(1-t*t)-1):.5*(Math.sqrt(1-(t-=2)*t)+1)},M=function(t){return t<1/2.75?7.5625*t*t:t<2/2.75?7.5625*(t-=1.5/2.75)*t+.75:t<2.5/2.75?7.5625*(t-=2.25/2.75)*t+.9375:7.5625*(t-=2.625/2.75)*t+.984375},k=function(t){var n=1.70158;return t*t*((n+1)*t-n)},P=function(t){var n=1.70158;return(t-=1)*t*((n+1)*t+n)+1},x=function(t){var n=1.70158;return(t/=.5)<1?t*t*((1+(n*=1.525))*t-n)*.5:.5*((t-=2)*t*((1+(n*=1.525))*t+n)+2)},T=function(t){return-1*Math.pow(4,-8*t)*Math.sin((6*t-1)*(2*Math.PI)/2)+1},E=function(t){var n=1.70158;return(t/=.5)<1?t*t*((1+(n*=1.525))*t-n)*.5:.5*((t-=2)*t*((1+(n*=1.525))*t+n)+2)},F=function(t){var n=1.70158;return t*t*((n+1)*t-n)},A=function(t){var n=1.70158;return(t-=1)*t*((n+1)*t+n)+1},I=function(t){return t<1/2.75?7.5625*t*t:t<2/2.75?7.5625*(t-=1.5/2.75)*t+.75:t<2.5/2.75?7.5625*(t-=2.25/2.75)*t+.9375:7.5625*(t-=2.625/2.75)*t+.984375},C=function(t){return t<1/2.75?7.5625*t*t:t<2/2.75?2-(7.5625*(t-=1.5/2.75)*t+.75):t<2.5/2.75?2-(7.5625*(t-=2.25/2.75)*t+.9375):2-(7.5625*(t-=2.625/2.75)*t+.984375)},D=function(t){return(t/=.5)<1?.5*Math.pow(t,4):-.5*((t-=2)*Math.pow(t,3)-2)},q=function(t){return Math.pow(t,4)},Q=function(t){return Math.pow(t,.25)}},function(t,n){var e;e=function(){return this}();try{e=e||new Function("return this")()}catch(t){"object"==typeof window&&(e=window)}t.exports=e},function(t,n,e){"use strict";e.r(n);var r={};e.r(r),e.d(r,"doesApply",(function(){return x})),e.d(r,"tweenCreated",(function(){return T})),e.d(r,"beforeTween",(function(){return E})),e.d(r,"afterTween",(function(){return F}));var i,u,o=e(0),a=/(\d|-|\.)/,c=/([^\-0-9.]+)/g,f=/[0-9.-]+/g,s=(i=f.source,u=/,\s*/.source,new RegExp("rgb\\(".concat(i).concat(u).concat(i).concat(u).concat(i,"\\)"),"g")),l=/^.*\(/,h=/#([0-9]|[a-f]){3,6}/gi,p=function(t,n){return t.map((function(t,e){return"_".concat(n,"_").concat(e)}))};function d(t){return parseInt(t,16)}var v=function(t){return"rgb(".concat((n=t,3===(n=n.replace(/#/,"")).length&&(n=(n=n.split(""))[0]+n[0]+n[1]+n[1]+n[2]+n[2]),[d(n.substr(0,2)),d(n.substr(2,2)),d(n.substr(4,2))]).join(","),")");var n},y=function(t,n,e){var r=n.match(t),i=n.replace(t,"VAL");return r&&r.forEach((function(t){return i=i.replace("VAL",e(t))})),i},_=function(t){for(var n in t){var e=t[n];"string"==typeof e&&e.match(h)&&(t[n]=y(h,e,v))}},m=function(t){var n=t.match(f).map(Math.floor),e=t.match(l)[0];return"".concat(e).concat(n.join(","),")")},g=function(t){return t.match(f)},b=function(t){var n,e,r={};for(var i in t){var u=t[i];"string"==typeof u&&(r[i]={formatString:(n=u,e=void 0,e=n.match(c),e?(1===e.length||n.charAt(0).match(a))&&e.unshift(""):e=["",""],e.join("VAL")),chunkNames:p(g(u),i)})}return r},w=function(t,n){var e=function(e){g(t[e]).forEach((function(r,i){return t[n[e].chunkNames[i]]=+r})),delete t[e]};for(var r in n)e(r)},O=function(t,n){var e={};return n.forEach((function(n){e[n]=t[n],delete t[n]})),e},S=function(t,n){return n.map((function(n){return t[n]}))},j=function(t,n){return n.forEach((function(n){return t=t.replace("VAL",+n.toFixed(4))})),t},M=function(t,n){for(var e in n){var r=n[e],i=r.chunkNames,u=r.formatString,o=j(u,S(O(t,i),i));t[e]=y(s,o,m)}},k=function(t,n){var e=function(e){var r=n[e].chunkNames,i=t[e];if("string"==typeof i){var u=i.split(" "),o=u[u.length-1];r.forEach((function(n,e){return t[n]=u[e]||o}))}else r.forEach((function(n){return t[n]=i}));delete t[e]};for(var r in n)e(r)},P=function(t,n){for(var e in n){var r=n[e].chunkNames,i=t[r[0]];t[e]="string"==typeof i?r.map((function(n){var e=t[n];return delete t[n],e})).join(" "):i}},x=function(t){var n=t._currentState;return Object.keys(n).some((function(t){return"string"==typeof n[t]}))};function T(t){var n=t._currentState;[n,t._originalState,t._targetState].forEach(_),t._tokenData=b(n)}function E(t){var n=t._currentState,e=t._originalState,r=t._targetState,i=t._easing,u=t._tokenData;k(i,u),[n,e,r].forEach((function(t){return w(t,u)}))}function F(t){var n=t._currentState,e=t._originalState,r=t._targetState,i=t._easing,u=t._tokenData;[n,e,r].forEach((function(t){return M(t,u)})),P(i,u)}function A(t,n){var e=Object.keys(t);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(t);n&&(r=r.filter((function(n){return Object.getOwnPropertyDescriptor(t,n).enumerable}))),e.push.apply(e,r)}return e}function I(t){for(var n=1;n<arguments.length;n++){var e=null!=arguments[n]?arguments[n]:{};n%2?A(Object(e),!0).forEach((function(n){C(t,n,e[n])})):Object.getOwnPropertyDescriptors?Object.defineProperties(t,Object.getOwnPropertyDescriptors(e)):A(Object(e)).forEach((function(n){Object.defineProperty(t,n,Object.getOwnPropertyDescriptor(e,n))}))}return t}function C(t,n,e){return n in t?Object.defineProperty(t,n,{value:e,enumerable:!0,configurable:!0,writable:!0}):t[n]=e,t}var D=new o.a,q=o.a.filters,Q=function(t,n,e,r){var i=arguments.length>4&&void 0!==arguments[4]?arguments[4]:0,u=I({},t),a=Object(o.b)(t,r);for(var c in D._filters.length=0,D.set({}),D._currentState=u,D._originalState=t,D._targetState=n,D._easing=a,q)q[c].doesApply(D)&&D._filters.push(q[c]);D._applyFilter("tweenCreated"),D._applyFilter("beforeTween");var f=Object(o.e)(e,u,t,n,1,i,a);return D._applyFilter("afterTween"),f};function B(t){return function(t){if(Array.isArray(t)){for(var n=0,e=new Array(t.length);n<t.length;n++)e[n]=t[n];return e}}(t)||function(t){if(Symbol.iterator in Object(t)||"[object Arguments]"===Object.prototype.toString.call(t))return Array.from(t)}(t)||function(){throw new TypeError("Invalid attempt to spread non-iterable instance")}()}function N(t,n){for(var e=0;e<n.length;e++){var r=n[e];r.enumerable=r.enumerable||!1,r.configurable=!0,"value"in r&&(r.writable=!0),Object.defineProperty(t,r.key,r)}}function R(t,n){var e=n.get(t);if(!e)throw new TypeError("attempted to get private field on non-instance");return e.get?e.get.call(t):e.value}var z=function(){function t(){!function(t,n){if(!(t instanceof n))throw new TypeError("Cannot call a class as a function")}(this,t),L.set(this,{writable:!0,value:[]});for(var n=arguments.length,e=new Array(n),r=0;r<n;r++)e[r]=arguments[r];e.forEach(this.add.bind(this))}var n,e,r;return n=t,(e=[{key:"add",value:function(t){return R(this,L).push(t),t}},{key:"remove",value:function(t){var n=R(this,L).indexOf(t);return~n&&R(this,L).splice(n,1),t}},{key:"empty",value:function(){return this.tweenables.map(this.remove.bind(this))}},{key:"isPlaying",value:function(){return R(this,L).some((function(t){return t.isPlaying()}))}},{key:"play",value:function(){return R(this,L).forEach((function(t){return t.tween()})),this}},{key:"pause",value:function(){return R(this,L).forEach((function(t){return t.pause()})),this}},{key:"resume",value:function(){return R(this,L).forEach((function(t){return t.resume()})),this}},{key:"stop",value:function(t){return R(this,L).forEach((function(n){return n.stop(t)})),this}},{key:"tweenables",get:function(){return B(R(this,L))}},{key:"promises",get:function(){return R(this,L).map((function(t){return t._promise}))}}])&&N(n.prototype,e),r&&N(n,r),t}(),L=new WeakMap;function V(t,n,e,r,i,u){var o,a,c=0,f=0,s=0,l=0,h=0,p=0,d=function(t){return((c*t+f)*t+s)*t},v=function(t){return(3*c*t+2*f)*t+s},y=function(t){return t>=0?t:0-t};return c=1-(s=3*n)-(f=3*(r-n)-s),l=1-(p=3*e)-(h=3*(i-e)-p),o=t,a=function(t){return 1/(200*t)}(u),function(t){return((l*t+h)*t+p)*t}(function(t,n){var e,r,i,u,o,a;for(i=t,a=0;a<8;a++){if(u=d(i)-t,y(u)<n)return i;if(o=v(i),y(o)<1e-6)break;i-=u/o}if((i=t)<(e=0))return e;if(i>(r=1))return r;for(;e<r;){if(u=d(i),y(u-t)<n)return i;t>u?e=i:r=i,i=.5*(r-e)+e}return i}(o,a))}var W=function(t,n,e,r,i){var u=function(t,n,e,r){return function(i){return V(i,t,n,e,r,1)}}(n,e,r,i);return u.displayName=t,u.x1=n,u.y1=e,u.x2=r,u.y2=i,o.a.formulas[t]=u},G=function(t){return delete o.a.formulas[t]};e.d(n,"processTweens",(function(){return o.c})),e.d(n,"Tweenable",(function(){return o.a})),e.d(n,"tween",(function(){return o.d})),e.d(n,"interpolate",(function(){return Q})),e.d(n,"Scene",(function(){return z})),e.d(n,"setBezierFunction",(function(){return W})),e.d(n,"unsetBezierFunction",(function(){return G})),o.a.filters.token=r}])}));
//# sourceMappingURL=shifty.js.map

/***/ }),

/***/ "./src/app/pages/modals/air-setting-modal/air-setting-modal.page.scss":
/*!****************************************************************************!*\
  !*** ./src/app/pages/modals/air-setting-modal/air-setting-modal.page.scss ***!
  \****************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-content {\n  --background: #fff url('bg2.jpg') no-repeat center center / cover;\n  background-repeat: no-repeat;\n  background-size: 100% 100%;\n}\n\n.inner-scroll {\n  background: transparent !important;\n  margin-bottom: 0 !important;\n}\n\nion-toolbar,\nion-footer,\nion-list {\n  --background: transparent !important;\n  --ion-color-base: transparent !important;\n  --min-height: 60px;\n}\n\nion-header {\n  --ion-toolbar-background-color: rgba(0, 0, 0, 0);\n}\n\n.mode {\n  text-align: center;\n  height: 200px;\n  color: white;\n}\n\n.mode img {\n  height: 48px;\n  width: 48px;\n  border: 1px solid #fff;\n  border-radius: 100%;\n  padding: 5px;\n}\n\n.mode ion-row {\n  height: 100%;\n}\n\n.mode ion-col {\n  display: -webkit-box;\n  display: flex;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n          flex-direction: column;\n  -webkit-box-pack: center;\n          justify-content: center;\n  -webkit-box-align: center;\n          align-items: center;\n  height: 100% !important;\n}\n\n.dismiss {\n  text-align: center;\n  font-size: 40px;\n  color: #fff;\n}\n\n.mode ion-row {\n  height: 100px !important;\n}\n\nion-toolbar,\nion-footer,\nion-list {\n  --background: transparent !important;\n  --ion-color-base: transparent !important;\n  --min-height: 60px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy96aG91Ym8vUHJvamVjdC9TbWFydEhvbWU0LjAvc3JjL2FwcC9wYWdlcy9tb2RhbHMvYWlyLXNldHRpbmctbW9kYWwvYWlyLXNldHRpbmctbW9kYWwucGFnZS5zY3NzIiwic3JjL2FwcC9wYWdlcy9tb2RhbHMvYWlyLXNldHRpbmctbW9kYWwvYWlyLXNldHRpbmctbW9kYWwucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBRUUsaUVBQUE7RUFDQSw0QkFBQTtFQUNBLDBCQUFBO0FDQUY7O0FER0E7RUFDRSxrQ0FBQTtFQUNBLDJCQUFBO0FDQUY7O0FERUE7OztFQUdFLG9DQUFBO0VBQ0Esd0NBQUE7RUFDQSxrQkFBQTtBQ0NGOztBRENBO0VBQ0UsZ0RBQUE7QUNFRjs7QURERTtFQUNFLGtCQUFBO0VBQ0EsYUFBQTtFQUVBLFlBQUE7QUNHSjs7QURGSTtFQUNFLFlBQUE7RUFDQSxXQUFBO0VBQ0Esc0JBQUE7RUFDQSxtQkFBQTtFQUNBLFlBQUE7QUNJTjs7QURGSTtFQUNFLFlBQUE7QUNJTjs7QURGSTtFQUNFLG9CQUFBO0VBQUEsYUFBQTtFQUNBLDRCQUFBO0VBQUEsNkJBQUE7VUFBQSxzQkFBQTtFQUNBLHdCQUFBO1VBQUEsdUJBQUE7RUFDQSx5QkFBQTtVQUFBLG1CQUFBO0VBQ0EsdUJBQUE7QUNJTjs7QURERTtFQUNFLGtCQUFBO0VBQ0EsZUFBQTtFQUNBLFdBQUE7QUNJSjs7QURGRTtFQUNFLHdCQUFBO0FDS0o7O0FESEU7OztFQUdBLG9DQUFBO0VBQ0Esd0NBQUE7RUFDQSxrQkFBQTtBQ01GIiwiZmlsZSI6InNyYy9hcHAvcGFnZXMvbW9kYWxzL2Fpci1zZXR0aW5nLW1vZGFsL2Fpci1zZXR0aW5nLW1vZGFsLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1jb250ZW50IHtcbiAgLy8gICBiYWNrZ3JvdW5kLWltYWdlOiB1cmwoLi4vLi4vLi4vYXNzZXRzL2JnLmpwZyk7XG4gIC0tYmFja2dyb3VuZDogI2ZmZiB1cmwoLi4vLi4vLi4vLi4vYXNzZXRzL2JnMi5qcGcpIG5vLXJlcGVhdCBjZW50ZXIgY2VudGVyIC8gY292ZXI7XG4gIGJhY2tncm91bmQtcmVwZWF0OiBuby1yZXBlYXQ7XG4gIGJhY2tncm91bmQtc2l6ZTogMTAwJSAxMDAlO1xufVxuXG4uaW5uZXItc2Nyb2xsIHtcbiAgYmFja2dyb3VuZDogdHJhbnNwYXJlbnQgIWltcG9ydGFudDtcbiAgbWFyZ2luLWJvdHRvbTogMCAhaW1wb3J0YW50O1xufVxuaW9uLXRvb2xiYXIsXG5pb24tZm9vdGVyLFxuaW9uLWxpc3Qge1xuICAtLWJhY2tncm91bmQ6IHRyYW5zcGFyZW50ICFpbXBvcnRhbnQ7XG4gIC0taW9uLWNvbG9yLWJhc2U6IHRyYW5zcGFyZW50ICFpbXBvcnRhbnQ7XG4gIC0tbWluLWhlaWdodDogNjBweDtcbn1cbmlvbi1oZWFkZXIge1xuICAtLWlvbi10b29sYmFyLWJhY2tncm91bmQtY29sb3I6IHJnYmEoMCwgMCwgMCwgMCk7XG59IC5tb2RlIHtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgaGVpZ2h0OiAyMDBweDtcbiAgICAvLyBib3JkZXItdG9wOiAxcHggZGFzaGVkIHdoaXRlO1xuICAgIGNvbG9yOiB3aGl0ZTtcbiAgICBpbWcge1xuICAgICAgaGVpZ2h0OiA0OHB4O1xuICAgICAgd2lkdGg6IDQ4cHg7XG4gICAgICBib3JkZXI6IDFweCBzb2xpZCAjZmZmO1xuICAgICAgYm9yZGVyLXJhZGl1czogMTAwJTtcbiAgICAgIHBhZGRpbmc6IDVweDtcbiAgICB9XG4gICAgaW9uLXJvdyB7XG4gICAgICBoZWlnaHQ6IDEwMCU7XG4gICAgfVxuICAgIGlvbi1jb2wge1xuICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XG4gICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gICAgICBoZWlnaHQ6IDEwMCUgIWltcG9ydGFudDtcbiAgICB9XG4gIH1cbiAgLmRpc21pc3Mge1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICBmb250LXNpemU6IDQwcHg7XG4gICAgY29sb3I6ICNmZmY7XG4gIH1cbiAgLm1vZGUgaW9uLXJvd3tcbiAgICBoZWlnaHQ6IDEwMHB4ICFpbXBvcnRhbnQ7XG4gIH1cbiAgaW9uLXRvb2xiYXIsXG5pb24tZm9vdGVyLFxuaW9uLWxpc3Qge1xuICAtLWJhY2tncm91bmQ6IHRyYW5zcGFyZW50ICFpbXBvcnRhbnQ7XG4gIC0taW9uLWNvbG9yLWJhc2U6IHRyYW5zcGFyZW50ICFpbXBvcnRhbnQ7XG4gIC0tbWluLWhlaWdodDogNjBweDtcbn0iLCJpb24tY29udGVudCB7XG4gIC0tYmFja2dyb3VuZDogI2ZmZiB1cmwoLi4vLi4vLi4vLi4vYXNzZXRzL2JnMi5qcGcpIG5vLXJlcGVhdCBjZW50ZXIgY2VudGVyIC8gY292ZXI7XG4gIGJhY2tncm91bmQtcmVwZWF0OiBuby1yZXBlYXQ7XG4gIGJhY2tncm91bmQtc2l6ZTogMTAwJSAxMDAlO1xufVxuXG4uaW5uZXItc2Nyb2xsIHtcbiAgYmFja2dyb3VuZDogdHJhbnNwYXJlbnQgIWltcG9ydGFudDtcbiAgbWFyZ2luLWJvdHRvbTogMCAhaW1wb3J0YW50O1xufVxuXG5pb24tdG9vbGJhcixcbmlvbi1mb290ZXIsXG5pb24tbGlzdCB7XG4gIC0tYmFja2dyb3VuZDogdHJhbnNwYXJlbnQgIWltcG9ydGFudDtcbiAgLS1pb24tY29sb3ItYmFzZTogdHJhbnNwYXJlbnQgIWltcG9ydGFudDtcbiAgLS1taW4taGVpZ2h0OiA2MHB4O1xufVxuXG5pb24taGVhZGVyIHtcbiAgLS1pb24tdG9vbGJhci1iYWNrZ3JvdW5kLWNvbG9yOiByZ2JhKDAsIDAsIDAsIDApO1xufVxuXG4ubW9kZSB7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgaGVpZ2h0OiAyMDBweDtcbiAgY29sb3I6IHdoaXRlO1xufVxuLm1vZGUgaW1nIHtcbiAgaGVpZ2h0OiA0OHB4O1xuICB3aWR0aDogNDhweDtcbiAgYm9yZGVyOiAxcHggc29saWQgI2ZmZjtcbiAgYm9yZGVyLXJhZGl1czogMTAwJTtcbiAgcGFkZGluZzogNXB4O1xufVxuLm1vZGUgaW9uLXJvdyB7XG4gIGhlaWdodDogMTAwJTtcbn1cbi5tb2RlIGlvbi1jb2wge1xuICBkaXNwbGF5OiBmbGV4O1xuICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgaGVpZ2h0OiAxMDAlICFpbXBvcnRhbnQ7XG59XG5cbi5kaXNtaXNzIHtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBmb250LXNpemU6IDQwcHg7XG4gIGNvbG9yOiAjZmZmO1xufVxuXG4ubW9kZSBpb24tcm93IHtcbiAgaGVpZ2h0OiAxMDBweCAhaW1wb3J0YW50O1xufVxuXG5pb24tdG9vbGJhcixcbmlvbi1mb290ZXIsXG5pb24tbGlzdCB7XG4gIC0tYmFja2dyb3VuZDogdHJhbnNwYXJlbnQgIWltcG9ydGFudDtcbiAgLS1pb24tY29sb3ItYmFzZTogdHJhbnNwYXJlbnQgIWltcG9ydGFudDtcbiAgLS1taW4taGVpZ2h0OiA2MHB4O1xufSJdfQ== */"

/***/ }),

/***/ "./src/app/pages/modals/air-setting-modal/air-setting-modal.page.ts":
/*!**************************************************************************!*\
  !*** ./src/app/pages/modals/air-setting-modal/air-setting-modal.page.ts ***!
  \**************************************************************************/
/*! exports provided: AirSettingModalPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AirSettingModalPage", function() { return AirSettingModalPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");



var AirSettingModalPage = /** @class */ (function () {
    function AirSettingModalPage(navParams, modalCtrl) {
        this.navParams = navParams;
        this.modalCtrl = modalCtrl;
        this.dataList = [];
        this.dataList = navParams.get('Data');
    }
    AirSettingModalPage.prototype.ngOnInit = function () {
    };
    AirSettingModalPage.prototype.dismiss = function (data) {
        //  if (data != null) {
        this.modalCtrl.dismiss(data);
        // } else {
        //  this.modalCtrl.dismiss(data);
        // }
    };
    AirSettingModalPage.ctorParameters = function () { return [
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavParams"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"] }
    ]; };
    AirSettingModalPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-air-setting-modal',
            template: __webpack_require__(/*! raw-loader!./air-setting-modal.page.html */ "./node_modules/raw-loader/index.js!./src/app/pages/modals/air-setting-modal/air-setting-modal.page.html"),
            styles: [__webpack_require__(/*! ./air-setting-modal.page.scss */ "./src/app/pages/modals/air-setting-modal/air-setting-modal.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavParams"], _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"]])
    ], AirSettingModalPage);
    return AirSettingModalPage;
}());



/***/ }),

/***/ "./src/app/pages/thermostat/thermostat-routing.module.ts":
/*!***************************************************************!*\
  !*** ./src/app/pages/thermostat/thermostat-routing.module.ts ***!
  \***************************************************************/
/*! exports provided: ThermostatPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ThermostatPageRoutingModule", function() { return ThermostatPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _thermostat_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./thermostat.page */ "./src/app/pages/thermostat/thermostat.page.ts");




var routes = [
    {
        path: '',
        component: _thermostat_page__WEBPACK_IMPORTED_MODULE_3__["ThermostatPage"]
    }
];
var ThermostatPageRoutingModule = /** @class */ (function () {
    function ThermostatPageRoutingModule() {
    }
    ThermostatPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
        })
    ], ThermostatPageRoutingModule);
    return ThermostatPageRoutingModule;
}());



/***/ }),

/***/ "./src/app/pages/thermostat/thermostat.module.ts":
/*!*******************************************************!*\
  !*** ./src/app/pages/thermostat/thermostat.module.ts ***!
  \*******************************************************/
/*! exports provided: ThermostatPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ThermostatPageModule", function() { return ThermostatPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _thermostat_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./thermostat-routing.module */ "./src/app/pages/thermostat/thermostat-routing.module.ts");
/* harmony import */ var _thermostat_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./thermostat.page */ "./src/app/pages/thermostat/thermostat.page.ts");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ngx-translate/core */ "./node_modules/@ngx-translate/core/fesm5/ngx-translate-core.js");
/* harmony import */ var _pipes_bool_pipe__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../pipes/bool.pipe */ "./src/app/pipes/bool.pipe.ts");
/* harmony import */ var _modals_air_setting_modal_air_setting_modal_page__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../modals/air-setting-modal/air-setting-modal.page */ "./src/app/pages/modals/air-setting-modal/air-setting-modal.page.ts");










var ThermostatPageModule = /** @class */ (function () {
    function ThermostatPageModule() {
    }
    ThermostatPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
                _thermostat_routing_module__WEBPACK_IMPORTED_MODULE_5__["ThermostatPageRoutingModule"],
                _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__["TranslateModule"]
            ],
            declarations: [_thermostat_page__WEBPACK_IMPORTED_MODULE_6__["ThermostatPage"], _pipes_bool_pipe__WEBPACK_IMPORTED_MODULE_8__["BoolPipe"], _modals_air_setting_modal_air_setting_modal_page__WEBPACK_IMPORTED_MODULE_9__["AirSettingModalPage"]],
            entryComponents: [_modals_air_setting_modal_air_setting_modal_page__WEBPACK_IMPORTED_MODULE_9__["AirSettingModalPage"]]
        })
    ], ThermostatPageModule);
    return ThermostatPageModule;
}());



/***/ }),

/***/ "./src/app/pages/thermostat/thermostat.page.scss":
/*!*******************************************************!*\
  !*** ./src/app/pages/thermostat/thermostat.page.scss ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-content {\n  --background: #fff url('bg2.jpg') no-repeat center center / cover;\n  background-repeat: no-repeat;\n  background-size: 100% 100%;\n}\n\n.inner-scroll {\n  background: transparent !important;\n  margin-bottom: 0 !important;\n}\n\nion-toolbar,\nion-footer,\nion-list {\n  --background: transparent !important;\n  --ion-color-base: transparent !important;\n  --min-height: 60px;\n}\n\nion-header {\n  --ion-toolbar-background-color: rgba(0, 0, 0, 0);\n}\n\n.container {\n  height: 200px;\n  width: 200px;\n}\n\n.room-temp-row {\n  padding: 10px;\n  display: -webkit-box;\n  display: flex;\n  -webkit-box-pack: end;\n          justify-content: flex-end;\n}\n\n.temp-add,\n.temp-sub {\n  display: -webkit-box;\n  display: flex;\n  -webkit-box-pack: center;\n          justify-content: center;\n  -webkit-box-align: center;\n          align-items: center;\n}\n\n.temp-add ion-icon,\n.temp-sub ion-icon {\n  font-size: 50px;\n  color: #fff;\n}\n\n.temp-add ion-button,\n.temp-sub ion-button {\n  --background: transparent;\n}\n\n.room-temp {\n  height: 28px;\n  width: 104px;\n  background: rgba(0, 0, 0, 0.1);\n  border-radius: 100px;\n  border: 1px solid #fff;\n  font-size: 14px;\n  color: #fff;\n  text-align: center;\n  line-height: 28px;\n}\n\n.temp-show {\n  width: 200px;\n  height: 200px;\n  position: absolute;\n  color: white;\n}\n\n.temp-show span {\n  font-size: 65px;\n}\n\n.temp-show span ion-multi-picker {\n  display: -webkit-inline-box;\n  display: inline-flex;\n  padding: 0;\n}\n\n.temp-show span ion-multi-picker .multi-picker-text {\n  font-size: 75px;\n  color: #fff;\n}\n\n.temp-show p:first-child {\n  text-align: center;\n  margin: 0;\n  padding-top: 50px;\n}\n\n.temp-show p:last-child {\n  margin: 0;\n  font-size: 18px;\n  text-align: center;\n}\n\n.multi-picker-text {\n  color: rgba(0, 0, 0, 0.45);\n}\n\n.border-dividing .item-inner {\n  border-bottom: none !important;\n}\n\n.speed {\n  color: #fff;\n  -webkit-transition: all 1.5s;\n  transition: all 1.5s;\n  height: 48px;\n}\n\n.speed ion-col {\n  line-height: 38px;\n  height: 100%;\n}\n\n.speed ul {\n  margin: 0;\n  padding: 0;\n  display: -webkit-box;\n  display: flex;\n  justify-content: space-around;\n  list-style-type: none;\n  -webkit-box-align: center;\n          align-items: center;\n  height: 100%;\n}\n\n.speed ul li {\n  border: 1px solid white;\n  border-radius: 50%;\n  height: 32px;\n  width: 32px;\n  line-height: 30px;\n  text-align: center;\n  font-size: 15px;\n}\n\n.mode {\n  padding: 0 !important;\n  text-align: center;\n  height: 100px;\n  border-top: 1px dashed white;\n  color: white;\n}\n\n.mode img {\n  height: 48px;\n  width: 48px;\n  border: 1px solid #fff;\n  border-radius: 100%;\n  padding: 5px;\n}\n\n.mode ion-row {\n  height: 100%;\n}\n\n.mode ion-col {\n  display: -webkit-box;\n  display: flex;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n          flex-direction: column;\n  -webkit-box-pack: center;\n          justify-content: center;\n  -webkit-box-align: center;\n          align-items: center;\n  height: 100% !important;\n}\n\n.selected {\n  background-color: var(--ion-color-primary) !important;\n  border-color: var(--ion-color-primary) !important;\n}\n\n.cool,\n.cool1 {\n  background-color: #52a1f3;\n  border-color: #52a1f3 !important;\n}\n\n.hot,\n.hot1 {\n  background: #ff9900;\n  border-color: #ff9900 !important;\n}\n\n.shidu {\n  text-align: right;\n  padding-right: 26px;\n  color: #fff;\n  font-size: 13px;\n}\n\n.progressbar-text {\n  color: white !important;\n  font-size: 75px !important;\n}\n\n.clock {\n  text-align: center;\n  font-size: 14px;\n  color: red;\n  line-height: 50px;\n  height: 50px;\n}\n\n.clock img {\n  width: 18px;\n  height: 18px;\n}\n\n.col-clock {\n  text-align: center;\n  color: white;\n  min-height: 61px;\n}\n\n.col-clock img {\n  width: 28px;\n  height: 28px;\n}\n\n.mode-div {\n  display: -webkit-box;\n  display: flex;\n  height: 100%;\n  width: 100%;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n          flex-direction: column;\n  -webkit-box-pack: center;\n          justify-content: center;\n  -webkit-box-align: center;\n          align-items: center;\n}\n\n.border-top-none {\n  border-top: none !important;\n}\n\n.timer-div {\n  width: 80%;\n  height: 29px;\n  font-size: 14px;\n  color: white;\n  line-height: 30px;\n  text-align: center;\n  border: 1px solid #fff;\n  border-radius: 5px;\n}\n\n.timer-div span {\n  display: inline-block;\n  width: 9px;\n  height: 9px;\n  background-color: lightgreen;\n  border-radius: 100%;\n}\n\n.timer-close {\n  background-color: gainsboro !important;\n}\n\n.col-center {\n  display: -webkit-box;\n  display: flex;\n  -webkit-box-pack: center;\n          justify-content: center;\n}\n\n.eco-color {\n  background-color: #7ccd7c;\n  border-color: #7ccd7c !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy96aG91Ym8vUHJvamVjdC9TbWFydEhvbWU0LjAvc3JjL2FwcC9wYWdlcy90aGVybW9zdGF0L3RoZXJtb3N0YXQucGFnZS5zY3NzIiwic3JjL2FwcC9wYWdlcy90aGVybW9zdGF0L3RoZXJtb3N0YXQucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBRUUsaUVBQUE7RUFDQSw0QkFBQTtFQUNBLDBCQUFBO0FDQUY7O0FER0E7RUFDRSxrQ0FBQTtFQUNBLDJCQUFBO0FDQUY7O0FERUE7OztFQUdFLG9DQUFBO0VBQ0Esd0NBQUE7RUFDQSxrQkFBQTtBQ0NGOztBRENBO0VBQ0UsZ0RBQUE7QUNFRjs7QURBQTtFQUNFLGFBQUE7RUFDQSxZQUFBO0FDR0Y7O0FEQUE7RUFDRSxhQUFBO0VBQ0Esb0JBQUE7RUFBQSxhQUFBO0VBQ0EscUJBQUE7VUFBQSx5QkFBQTtBQ0dGOztBREFBOztFQUVFLG9CQUFBO0VBQUEsYUFBQTtFQUNBLHdCQUFBO1VBQUEsdUJBQUE7RUFDQSx5QkFBQTtVQUFBLG1CQUFBO0FDR0Y7O0FERkU7O0VBQ0EsZUFBQTtFQUNBLFdBQUE7QUNLRjs7QURGQTs7RUFDRSx5QkFBQTtBQ0tGOztBRFVBO0VBQ0UsWUFBQTtFQUNBLFlBQUE7RUFDQSw4QkFBQTtFQUNBLG9CQUFBO0VBRUEsc0JBQUE7RUFDQSxlQUFBO0VBQ0EsV0FBQTtFQUNBLGtCQUFBO0VBQ0EsaUJBQUE7QUNSRjs7QURXQTtFQUNFLFlBQUE7RUFDQSxhQUFBO0VBQ0Esa0JBQUE7RUFDQSxZQUFBO0FDUkY7O0FEVUU7RUFDTSxlQUFBO0FDUlI7O0FEVUk7RUFDRSwyQkFBQTtFQUFBLG9CQUFBO0VBQ0EsVUFBQTtBQ1JOOztBRFVNO0VBQ0UsZUFBQTtFQUNBLFdBQUE7QUNSUjs7QURjQTtFQUNFLGtCQUFBO0VBQ0EsU0FBQTtFQUNBLGlCQUFBO0FDWEY7O0FEbUJBO0VBQ0UsU0FBQTtFQUNBLGVBQUE7RUFDQSxrQkFBQTtBQ2pCRjs7QURvQkE7RUFFRSwwQkFBQTtBQ2xCRjs7QURzQkU7RUFDRSw4QkFBQTtBQ25CSjs7QUR1QkE7RUFDRSxXQUFBO0VBQ0EsNEJBQUE7RUFBQSxvQkFBQTtFQUNBLFlBQUE7QUNwQkY7O0FEc0JFO0VBQ0UsaUJBQUE7RUFDQSxZQUFBO0FDcEJKOztBRHVCRTtFQUNFLFNBQUE7RUFDQSxVQUFBO0VBQ0Esb0JBQUE7RUFBQSxhQUFBO0VBQ0EsNkJBQUE7RUFDQSxxQkFBQTtFQUNBLHlCQUFBO1VBQUEsbUJBQUE7RUFDQSxZQUFBO0FDckJKOztBRHVCSTtFQUNFLHVCQUFBO0VBQ0Esa0JBQUE7RUFDQSxZQUFBO0VBQ0EsV0FBQTtFQUNBLGlCQUFBO0VBQ0Esa0JBQUE7RUFDQSxlQUFBO0FDckJOOztBRDBCQTtFQUNFLHFCQUFBO0VBQ0Esa0JBQUE7RUFDQSxhQUFBO0VBQ0EsNEJBQUE7RUFDQSxZQUFBO0FDdkJGOztBRHlCRTtFQUNFLFlBQUE7RUFDQSxXQUFBO0VBQ0Esc0JBQUE7RUFDQSxtQkFBQTtFQUNBLFlBQUE7QUN2Qko7O0FEMEJFO0VBQ0UsWUFBQTtBQ3hCSjs7QUQyQkU7RUFDRSxvQkFBQTtFQUFBLGFBQUE7RUFDQSw0QkFBQTtFQUFBLDZCQUFBO1VBQUEsc0JBQUE7RUFDQSx3QkFBQTtVQUFBLHVCQUFBO0VBQ0EseUJBQUE7VUFBQSxtQkFBQTtFQUNBLHVCQUFBO0FDekJKOztBRDZCQTtFQUNFLHFEQUFBO0VBQ0EsaURBQUE7QUMxQkY7O0FENkJBOztFQUVHLHlCQUFBO0VBQ0QsZ0NBQUE7QUMxQkY7O0FEb0NBOztFQUVFLG1CQUFBO0VBQ0EsZ0NBQUE7QUNqQ0Y7O0FEb0NBO0VBQ0UsaUJBQUE7RUFDQSxtQkFBQTtFQUNBLFdBQUE7RUFDQSxlQUFBO0FDakNGOztBRG9DQTtFQUNFLHVCQUFBO0VBQ0EsMEJBQUE7QUNqQ0Y7O0FEb0NBO0VBQ0Usa0JBQUE7RUFDQSxlQUFBO0VBQ0EsVUFBQTtFQUNBLGlCQUFBO0VBQ0EsWUFBQTtBQ2pDRjs7QURvQ0E7RUFDRSxXQUFBO0VBQ0EsWUFBQTtBQ2pDRjs7QURvQ0E7RUFDRSxrQkFBQTtFQUNBLFlBQUE7RUFDQSxnQkFBQTtBQ2pDRjs7QURvQ0U7RUFDRSxXQUFBO0VBQ0EsWUFBQTtBQ2xDSjs7QURzQ0E7RUFDRSxvQkFBQTtFQUFBLGFBQUE7RUFDQSxZQUFBO0VBQ0EsV0FBQTtFQUNBLDRCQUFBO0VBQUEsNkJBQUE7VUFBQSxzQkFBQTtFQUNBLHdCQUFBO1VBQUEsdUJBQUE7RUFDQSx5QkFBQTtVQUFBLG1CQUFBO0FDbkNGOztBRHNDQTtFQUNFLDJCQUFBO0FDbkNGOztBRHNDQTtFQUNFLFVBQUE7RUFDQSxZQUFBO0VBRUEsZUFBQTtFQUNBLFlBQUE7RUFDQSxpQkFBQTtFQUNBLGtCQUFBO0VBQ0Esc0JBQUE7RUFDQSxrQkFBQTtBQ3BDRjs7QUR1Q0E7RUFDRSxxQkFBQTtFQUNBLFVBQUE7RUFDQSxXQUFBO0VBQ0EsNEJBQUE7RUFDQSxtQkFBQTtBQ3BDRjs7QUR1Q0E7RUFDRSxzQ0FBQTtBQ3BDRjs7QUR1Q0E7RUFDRSxvQkFBQTtFQUFBLGFBQUE7RUFDQSx3QkFBQTtVQUFBLHVCQUFBO0FDcENGOztBRHVDQTtFQUNFLHlCQUFBO0VBQ0EsZ0NBQUE7QUNwQ0YiLCJmaWxlIjoic3JjL2FwcC9wYWdlcy90aGVybW9zdGF0L3RoZXJtb3N0YXQucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWNvbnRlbnQge1xuICAvLyAgIGJhY2tncm91bmQtaW1hZ2U6IHVybCguLi8uLi8uLi9hc3NldHMvYmcuanBnKTtcbiAgLS1iYWNrZ3JvdW5kOiAjZmZmIHVybCguLi8uLi8uLi9hc3NldHMvYmcyLmpwZykgbm8tcmVwZWF0IGNlbnRlciBjZW50ZXIgLyBjb3ZlcjtcbiAgYmFja2dyb3VuZC1yZXBlYXQ6IG5vLXJlcGVhdDtcbiAgYmFja2dyb3VuZC1zaXplOiAxMDAlIDEwMCU7XG59XG5cbi5pbm5lci1zY3JvbGwge1xuICBiYWNrZ3JvdW5kOiB0cmFuc3BhcmVudCAhaW1wb3J0YW50O1xuICBtYXJnaW4tYm90dG9tOiAwICFpbXBvcnRhbnQ7XG59XG5pb24tdG9vbGJhcixcbmlvbi1mb290ZXIsXG5pb24tbGlzdCB7XG4gIC0tYmFja2dyb3VuZDogdHJhbnNwYXJlbnQgIWltcG9ydGFudDtcbiAgLS1pb24tY29sb3ItYmFzZTogdHJhbnNwYXJlbnQgIWltcG9ydGFudDtcbiAgLS1taW4taGVpZ2h0OiA2MHB4O1xufVxuaW9uLWhlYWRlciB7XG4gIC0taW9uLXRvb2xiYXItYmFja2dyb3VuZC1jb2xvcjogcmdiYSgwLCAwLCAwLCAwKTtcbn1cbi5jb250YWluZXIge1xuICBoZWlnaHQ6IDIwMHB4O1xuICB3aWR0aDogMjAwcHg7XG59XG5cbi5yb29tLXRlbXAtcm93IHtcbiAgcGFkZGluZzogMTBweDtcbiAgZGlzcGxheTogZmxleDtcbiAganVzdGlmeS1jb250ZW50OiBmbGV4LWVuZDtcbn1cblxuLnRlbXAtYWRkLFxuLnRlbXAtc3ViIHtcbiAgZGlzcGxheTogZmxleDtcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIGlvbi1pY29ue1xuICBmb250LXNpemU6IDUwcHg7XG4gIGNvbG9yOiAjZmZmO1xuXG4gIH1cbmlvbi1idXR0b257XG4gIC0tYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XG5cbn1cbiAgLy8gLmJ1dHRvbiB7XG4gICAgLy8gYmFja2dyb3VuZC1jb2xvcjogI2ZmZiAhaW1wb3J0YW50O1xuICAgIC8vIGNvbG9yOiBjb2xvcigkY29sb3JzLCBwcmltYXJ5MSkgIWltcG9ydGFudDtcbiAgICAvLyBmb250LXNpemU6IDMwcHg7XG4gICAgLy8gZm9udC13ZWlnaHQ6IGJvbGQ7XG4gICAgLy8gd2lkdGg6IDQ2cHg7XG4gICAgLy8gaGVpZ2h0OiA0NnB4O1xuICAgIC8vIGJhY2tncm91bmQ6IHJnYmEoMCwgMCwgMCwgMCk7XG4gICAgLy8gY29sb3I6IHdoaXRlO1xuICAvLyB9XG59XG5cbi5yb29tLXRlbXAge1xuICBoZWlnaHQ6IDI4cHg7XG4gIHdpZHRoOiAxMDRweDtcbiAgYmFja2dyb3VuZDogcmdiYSgwLCAwLCAwLCAwLjEpO1xuICBib3JkZXItcmFkaXVzOiAxMDBweDtcbiAgLy8gYm9yZGVyOiAxcHggc29saWQgIzUyYTFmMztcbiAgYm9yZGVyOiAxcHggc29saWQgI2ZmZjtcbiAgZm9udC1zaXplOiAxNHB4O1xuICBjb2xvcjogI2ZmZjtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBsaW5lLWhlaWdodDogMjhweDtcbn1cblxuLnRlbXAtc2hvdyB7XG4gIHdpZHRoOiAyMDBweDtcbiAgaGVpZ2h0OiAyMDBweDtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICBjb2xvcjogcmdiYSgyNTUsIDI1NSwgMjU1LCAxKTtcblxuICBzcGFuIHtcbiAgICAgICAgZm9udC1zaXplOiA2NXB4O1xuXG4gICAgaW9uLW11bHRpLXBpY2tlciB7XG4gICAgICBkaXNwbGF5OiBpbmxpbmUtZmxleDtcbiAgICAgIHBhZGRpbmc6IDA7XG5cbiAgICAgIC5tdWx0aS1waWNrZXItdGV4dCB7XG4gICAgICAgIGZvbnQtc2l6ZTogNzVweDtcbiAgICAgICAgY29sb3I6ICNmZmY7XG4gICAgICB9XG4gICAgfVxuICB9XG59XG5cbi50ZW1wLXNob3cgcDpmaXJzdC1jaGlsZCB7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgbWFyZ2luOiAwO1xuICBwYWRkaW5nLXRvcDogNTBweDtcblxuICAvLyBwYWRkaW5nLWxlZnQ6IDIwcHg7XG4gIHNwYW46Zmlyc3QtY2hpbGQge1xuICAgIC8vIGZvbnQtc2l6ZTogNzVweDtcbiAgfVxufVxuXG4udGVtcC1zaG93IHA6bGFzdC1jaGlsZCB7XG4gIG1hcmdpbjogMDtcbiAgZm9udC1zaXplOiAxOHB4O1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG59XG5cbi5tdWx0aS1waWNrZXItdGV4dCB7XG4gIC8vIGZvbnQtc2l6ZTogMTRweDtcbiAgY29sb3I6IHJnYmEoMCwgMCwgMCwgMC40NSk7XG59XG5cbi5ib3JkZXItZGl2aWRpbmcge1xuICAuaXRlbS1pbm5lciB7XG4gICAgYm9yZGVyLWJvdHRvbTogbm9uZSAhaW1wb3J0YW50O1xuICB9XG59XG5cbi5zcGVlZCB7XG4gIGNvbG9yOiAjZmZmO1xuICB0cmFuc2l0aW9uOiBhbGwgMS41cztcbiAgaGVpZ2h0OiA0OHB4O1xuXG4gIGlvbi1jb2wge1xuICAgIGxpbmUtaGVpZ2h0OiAzOHB4O1xuICAgIGhlaWdodDogMTAwJTtcbiAgfVxuXG4gIHVsIHtcbiAgICBtYXJnaW46IDA7XG4gICAgcGFkZGluZzogMDtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIGp1c3RpZnktY29udGVudDogc3BhY2UtYXJvdW5kO1xuICAgIGxpc3Qtc3R5bGUtdHlwZTogbm9uZTtcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgIGhlaWdodDogMTAwJTtcblxuICAgIGxpIHtcbiAgICAgIGJvcmRlcjogMXB4IHNvbGlkIHdoaXRlO1xuICAgICAgYm9yZGVyLXJhZGl1czogNTAlO1xuICAgICAgaGVpZ2h0OiAzMnB4O1xuICAgICAgd2lkdGg6IDMycHg7XG4gICAgICBsaW5lLWhlaWdodDogMzBweDtcbiAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICAgIGZvbnQtc2l6ZTogMTVweDtcbiAgICB9XG4gIH1cbn1cblxuLm1vZGUge1xuICBwYWRkaW5nOiAwICFpbXBvcnRhbnQ7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgaGVpZ2h0OiAxMDBweDtcbiAgYm9yZGVyLXRvcDogMXB4IGRhc2hlZCB3aGl0ZTtcbiAgY29sb3I6IHdoaXRlO1xuXG4gIGltZyB7XG4gICAgaGVpZ2h0OiA0OHB4O1xuICAgIHdpZHRoOiA0OHB4O1xuICAgIGJvcmRlcjogMXB4IHNvbGlkICNmZmY7XG4gICAgYm9yZGVyLXJhZGl1czogMTAwJTtcbiAgICBwYWRkaW5nOiA1cHg7XG4gIH1cblxuICBpb24tcm93IHtcbiAgICBoZWlnaHQ6IDEwMCU7XG4gIH1cblxuICBpb24tY29sIHtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICBoZWlnaHQ6IDEwMCUgIWltcG9ydGFudDtcbiAgfVxufVxuXG4uc2VsZWN0ZWR7XG4gIGJhY2tncm91bmQtY29sb3I6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KSAhaW1wb3J0YW50O1xuICBib3JkZXItY29sb3I6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KSAhaW1wb3J0YW50O1xuICBcbn1cbi5jb29sLFxuLmNvb2wxIHtcbiAgIGJhY2tncm91bmQtY29sb3I6IzUyYTFmMztcbiAgYm9yZGVyLWNvbG9yOiM1MmExZjMgIWltcG9ydGFudDtcblxufVxuXG5cblxuLy8gLmNvb2x7XG4vLyAgIGJhY2tncm91bmQ6ICNmZjk5MDA7XG4vLyAgIGJvcmRlci1jb2xvcjogI2ZmOTkwMDtcbi8vIH1cbi5ob3QsXG4uaG90MSB7XG4gIGJhY2tncm91bmQ6ICNmZjk5MDA7XG4gIGJvcmRlci1jb2xvcjogI2ZmOTkwMCAhaW1wb3J0YW50O1xufVxuXG4uc2hpZHUge1xuICB0ZXh0LWFsaWduOiByaWdodDtcbiAgcGFkZGluZy1yaWdodDogMjZweDtcbiAgY29sb3I6ICNmZmY7XG4gIGZvbnQtc2l6ZTogMTNweDtcbn1cblxuLnByb2dyZXNzYmFyLXRleHQge1xuICBjb2xvcjogd2hpdGUgIWltcG9ydGFudDtcbiAgZm9udC1zaXplOiA3NXB4ICFpbXBvcnRhbnQ7XG59XG5cbi5jbG9jayB7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgZm9udC1zaXplOiAxNHB4O1xuICBjb2xvcjogcmVkO1xuICBsaW5lLWhlaWdodDogNTBweDtcbiAgaGVpZ2h0OiA1MHB4O1xufVxuXG4uY2xvY2sgaW1nIHtcbiAgd2lkdGg6IDE4cHg7XG4gIGhlaWdodDogMThweDtcbn1cblxuLmNvbC1jbG9jayB7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgY29sb3I6IHdoaXRlO1xuICBtaW4taGVpZ2h0OiA2MXB4O1xuXG4gIC8vIGhlaWdodDogODZweDtcbiAgaW1nIHtcbiAgICB3aWR0aDogMjhweDtcbiAgICBoZWlnaHQ6IDI4cHg7XG4gIH1cbn1cblxuLm1vZGUtZGl2IHtcbiAgZGlzcGxheTogZmxleDtcbiAgaGVpZ2h0OiAxMDAlO1xuICB3aWR0aDogMTAwJTtcbiAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG59XG5cbi5ib3JkZXItdG9wLW5vbmUge1xuICBib3JkZXItdG9wOiBub25lICFpbXBvcnRhbnQ7XG59XG5cbi50aW1lci1kaXYge1xuICB3aWR0aDogODAlO1xuICBoZWlnaHQ6IDI5cHg7XG4gIC8vIGJhY2tncm91bmQ6ICNjY2M7XG4gIGZvbnQtc2l6ZTogMTRweDtcbiAgY29sb3I6IHdoaXRlO1xuICBsaW5lLWhlaWdodDogMzBweDtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBib3JkZXI6IDFweCBzb2xpZCAjZmZmO1xuICBib3JkZXItcmFkaXVzOiA1cHg7XG59XG5cbi50aW1lci1kaXYgc3BhbiB7XG4gIGRpc3BsYXk6IGlubGluZS1ibG9jaztcbiAgd2lkdGg6IDlweDtcbiAgaGVpZ2h0OiA5cHg7XG4gIGJhY2tncm91bmQtY29sb3I6IGxpZ2h0Z3JlZW47XG4gIGJvcmRlci1yYWRpdXM6IDEwMCU7XG59XG5cbi50aW1lci1jbG9zZSB7XG4gIGJhY2tncm91bmQtY29sb3I6IGdhaW5zYm9ybyAhaW1wb3J0YW50O1xufVxuXG4uY29sLWNlbnRlciB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xufVxuXG4uZWNvLWNvbG9yIHtcbiAgYmFja2dyb3VuZC1jb2xvcjogIzdjY2Q3YztcbiAgYm9yZGVyLWNvbG9yOiAjN2NjZDdjICFpbXBvcnRhbnQ7XG59XG4iLCJpb24tY29udGVudCB7XG4gIC0tYmFja2dyb3VuZDogI2ZmZiB1cmwoLi4vLi4vLi4vYXNzZXRzL2JnMi5qcGcpIG5vLXJlcGVhdCBjZW50ZXIgY2VudGVyIC8gY292ZXI7XG4gIGJhY2tncm91bmQtcmVwZWF0OiBuby1yZXBlYXQ7XG4gIGJhY2tncm91bmQtc2l6ZTogMTAwJSAxMDAlO1xufVxuXG4uaW5uZXItc2Nyb2xsIHtcbiAgYmFja2dyb3VuZDogdHJhbnNwYXJlbnQgIWltcG9ydGFudDtcbiAgbWFyZ2luLWJvdHRvbTogMCAhaW1wb3J0YW50O1xufVxuXG5pb24tdG9vbGJhcixcbmlvbi1mb290ZXIsXG5pb24tbGlzdCB7XG4gIC0tYmFja2dyb3VuZDogdHJhbnNwYXJlbnQgIWltcG9ydGFudDtcbiAgLS1pb24tY29sb3ItYmFzZTogdHJhbnNwYXJlbnQgIWltcG9ydGFudDtcbiAgLS1taW4taGVpZ2h0OiA2MHB4O1xufVxuXG5pb24taGVhZGVyIHtcbiAgLS1pb24tdG9vbGJhci1iYWNrZ3JvdW5kLWNvbG9yOiByZ2JhKDAsIDAsIDAsIDApO1xufVxuXG4uY29udGFpbmVyIHtcbiAgaGVpZ2h0OiAyMDBweDtcbiAgd2lkdGg6IDIwMHB4O1xufVxuXG4ucm9vbS10ZW1wLXJvdyB7XG4gIHBhZGRpbmc6IDEwcHg7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGp1c3RpZnktY29udGVudDogZmxleC1lbmQ7XG59XG5cbi50ZW1wLWFkZCxcbi50ZW1wLXN1YiB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xufVxuLnRlbXAtYWRkIGlvbi1pY29uLFxuLnRlbXAtc3ViIGlvbi1pY29uIHtcbiAgZm9udC1zaXplOiA1MHB4O1xuICBjb2xvcjogI2ZmZjtcbn1cbi50ZW1wLWFkZCBpb24tYnV0dG9uLFxuLnRlbXAtc3ViIGlvbi1idXR0b24ge1xuICAtLWJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xufVxuXG4ucm9vbS10ZW1wIHtcbiAgaGVpZ2h0OiAyOHB4O1xuICB3aWR0aDogMTA0cHg7XG4gIGJhY2tncm91bmQ6IHJnYmEoMCwgMCwgMCwgMC4xKTtcbiAgYm9yZGVyLXJhZGl1czogMTAwcHg7XG4gIGJvcmRlcjogMXB4IHNvbGlkICNmZmY7XG4gIGZvbnQtc2l6ZTogMTRweDtcbiAgY29sb3I6ICNmZmY7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgbGluZS1oZWlnaHQ6IDI4cHg7XG59XG5cbi50ZW1wLXNob3cge1xuICB3aWR0aDogMjAwcHg7XG4gIGhlaWdodDogMjAwcHg7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgY29sb3I6IHdoaXRlO1xufVxuLnRlbXAtc2hvdyBzcGFuIHtcbiAgZm9udC1zaXplOiA2NXB4O1xufVxuLnRlbXAtc2hvdyBzcGFuIGlvbi1tdWx0aS1waWNrZXIge1xuICBkaXNwbGF5OiBpbmxpbmUtZmxleDtcbiAgcGFkZGluZzogMDtcbn1cbi50ZW1wLXNob3cgc3BhbiBpb24tbXVsdGktcGlja2VyIC5tdWx0aS1waWNrZXItdGV4dCB7XG4gIGZvbnQtc2l6ZTogNzVweDtcbiAgY29sb3I6ICNmZmY7XG59XG5cbi50ZW1wLXNob3cgcDpmaXJzdC1jaGlsZCB7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgbWFyZ2luOiAwO1xuICBwYWRkaW5nLXRvcDogNTBweDtcbn1cbi50ZW1wLXNob3cgcDpsYXN0LWNoaWxkIHtcbiAgbWFyZ2luOiAwO1xuICBmb250LXNpemU6IDE4cHg7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbn1cblxuLm11bHRpLXBpY2tlci10ZXh0IHtcbiAgY29sb3I6IHJnYmEoMCwgMCwgMCwgMC40NSk7XG59XG5cbi5ib3JkZXItZGl2aWRpbmcgLml0ZW0taW5uZXIge1xuICBib3JkZXItYm90dG9tOiBub25lICFpbXBvcnRhbnQ7XG59XG5cbi5zcGVlZCB7XG4gIGNvbG9yOiAjZmZmO1xuICB0cmFuc2l0aW9uOiBhbGwgMS41cztcbiAgaGVpZ2h0OiA0OHB4O1xufVxuLnNwZWVkIGlvbi1jb2wge1xuICBsaW5lLWhlaWdodDogMzhweDtcbiAgaGVpZ2h0OiAxMDAlO1xufVxuLnNwZWVkIHVsIHtcbiAgbWFyZ2luOiAwO1xuICBwYWRkaW5nOiAwO1xuICBkaXNwbGF5OiBmbGV4O1xuICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWFyb3VuZDtcbiAgbGlzdC1zdHlsZS10eXBlOiBub25lO1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xuICBoZWlnaHQ6IDEwMCU7XG59XG4uc3BlZWQgdWwgbGkge1xuICBib3JkZXI6IDFweCBzb2xpZCB3aGl0ZTtcbiAgYm9yZGVyLXJhZGl1czogNTAlO1xuICBoZWlnaHQ6IDMycHg7XG4gIHdpZHRoOiAzMnB4O1xuICBsaW5lLWhlaWdodDogMzBweDtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBmb250LXNpemU6IDE1cHg7XG59XG5cbi5tb2RlIHtcbiAgcGFkZGluZzogMCAhaW1wb3J0YW50O1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIGhlaWdodDogMTAwcHg7XG4gIGJvcmRlci10b3A6IDFweCBkYXNoZWQgd2hpdGU7XG4gIGNvbG9yOiB3aGl0ZTtcbn1cbi5tb2RlIGltZyB7XG4gIGhlaWdodDogNDhweDtcbiAgd2lkdGg6IDQ4cHg7XG4gIGJvcmRlcjogMXB4IHNvbGlkICNmZmY7XG4gIGJvcmRlci1yYWRpdXM6IDEwMCU7XG4gIHBhZGRpbmc6IDVweDtcbn1cbi5tb2RlIGlvbi1yb3cge1xuICBoZWlnaHQ6IDEwMCU7XG59XG4ubW9kZSBpb24tY29sIHtcbiAgZGlzcGxheTogZmxleDtcbiAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIGhlaWdodDogMTAwJSAhaW1wb3J0YW50O1xufVxuXG4uc2VsZWN0ZWQge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSkgIWltcG9ydGFudDtcbiAgYm9yZGVyLWNvbG9yOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSkgIWltcG9ydGFudDtcbn1cblxuLmNvb2wsXG4uY29vbDEge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjNTJhMWYzO1xuICBib3JkZXItY29sb3I6ICM1MmExZjMgIWltcG9ydGFudDtcbn1cblxuLmhvdCxcbi5ob3QxIHtcbiAgYmFja2dyb3VuZDogI2ZmOTkwMDtcbiAgYm9yZGVyLWNvbG9yOiAjZmY5OTAwICFpbXBvcnRhbnQ7XG59XG5cbi5zaGlkdSB7XG4gIHRleHQtYWxpZ246IHJpZ2h0O1xuICBwYWRkaW5nLXJpZ2h0OiAyNnB4O1xuICBjb2xvcjogI2ZmZjtcbiAgZm9udC1zaXplOiAxM3B4O1xufVxuXG4ucHJvZ3Jlc3NiYXItdGV4dCB7XG4gIGNvbG9yOiB3aGl0ZSAhaW1wb3J0YW50O1xuICBmb250LXNpemU6IDc1cHggIWltcG9ydGFudDtcbn1cblxuLmNsb2NrIHtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBmb250LXNpemU6IDE0cHg7XG4gIGNvbG9yOiByZWQ7XG4gIGxpbmUtaGVpZ2h0OiA1MHB4O1xuICBoZWlnaHQ6IDUwcHg7XG59XG5cbi5jbG9jayBpbWcge1xuICB3aWR0aDogMThweDtcbiAgaGVpZ2h0OiAxOHB4O1xufVxuXG4uY29sLWNsb2NrIHtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBjb2xvcjogd2hpdGU7XG4gIG1pbi1oZWlnaHQ6IDYxcHg7XG59XG4uY29sLWNsb2NrIGltZyB7XG4gIHdpZHRoOiAyOHB4O1xuICBoZWlnaHQ6IDI4cHg7XG59XG5cbi5tb2RlLWRpdiB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGhlaWdodDogMTAwJTtcbiAgd2lkdGg6IDEwMCU7XG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xufVxuXG4uYm9yZGVyLXRvcC1ub25lIHtcbiAgYm9yZGVyLXRvcDogbm9uZSAhaW1wb3J0YW50O1xufVxuXG4udGltZXItZGl2IHtcbiAgd2lkdGg6IDgwJTtcbiAgaGVpZ2h0OiAyOXB4O1xuICBmb250LXNpemU6IDE0cHg7XG4gIGNvbG9yOiB3aGl0ZTtcbiAgbGluZS1oZWlnaHQ6IDMwcHg7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgYm9yZGVyOiAxcHggc29saWQgI2ZmZjtcbiAgYm9yZGVyLXJhZGl1czogNXB4O1xufVxuXG4udGltZXItZGl2IHNwYW4ge1xuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG4gIHdpZHRoOiA5cHg7XG4gIGhlaWdodDogOXB4O1xuICBiYWNrZ3JvdW5kLWNvbG9yOiBsaWdodGdyZWVuO1xuICBib3JkZXItcmFkaXVzOiAxMDAlO1xufVxuXG4udGltZXItY2xvc2Uge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiBnYWluc2Jvcm8gIWltcG9ydGFudDtcbn1cblxuLmNvbC1jZW50ZXIge1xuICBkaXNwbGF5OiBmbGV4O1xuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbn1cblxuLmVjby1jb2xvciB7XG4gIGJhY2tncm91bmQtY29sb3I6ICM3Y2NkN2M7XG4gIGJvcmRlci1jb2xvcjogIzdjY2Q3YyAhaW1wb3J0YW50O1xufSJdfQ== */"

/***/ }),

/***/ "./src/app/pages/thermostat/thermostat.page.ts":
/*!*****************************************************!*\
  !*** ./src/app/pages/thermostat/thermostat.page.ts ***!
  \*****************************************************/
/*! exports provided: ThermostatPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ThermostatPage", function() { return ThermostatPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _common_variable__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../common/variable */ "./src/app/common/variable.ts");
/* harmony import */ var progressbar_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! progressbar.js */ "./node_modules/progressbar.js/src/main.js");
/* harmony import */ var progressbar_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(progressbar_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _services_global_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../services/global.service */ "./src/app/services/global.service.ts");
/* harmony import */ var _services_tools_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../services/tools.service */ "./src/app/services/tools.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _modals_air_setting_modal_air_setting_modal_page__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../modals/air-setting-modal/air-setting-modal.page */ "./src/app/pages/modals/air-setting-modal/air-setting-modal.page.ts");









var ThermostatPage = /** @class */ (function () {
    function ThermostatPage(route, globalService$, tools, modalController, router) {
        this.route = route;
        this.globalService$ = globalService$;
        this.tools = tools;
        this.modalController = modalController;
        this.router = router;
        this.code = 'switch_state';
        this.value = 0;
        this.paramData = {};
        this.temp = 16;
        this.tempMax = 30;
        this.tempMin = 15;
        this.modeKV = [];
        this.speedKV = [];
        this.tempKv = [];
        // speed: number;
        this.airData = {};
        this.tempColumns = [];
        // settingTempData: any;
        this.selectedMode = {};
        this.selectedSpped = {};
        this.setInfo = { type: '', value: '' };
        this.airTypeParam = {};
        this.airSetInfo = {};
        this.tempTimeoutObj = null;
        this.queryParams = this.route.snapshot.queryParams;
        console.log(this.queryParams);
        this.id = this.queryParams.id;
        this.name = this.queryParams.name;
        this.mac = this.queryParams.mac;
        this.paramData = this.queryParams.data;
    }
    ThermostatPage.prototype.ngOnDestroy = function () {
        this.deviceDataSubscribe.unsubscribe();
    };
    ThermostatPage.prototype.ngAfterViewInit = function () {
        //Called after ngAfterContentInit when the component's view has been initialized. Applies to components only.
        //Add 'implements AfterViewInit' to the class.
    };
    ThermostatPage.prototype.ngOnInit = function () {
        var _this = this;
        this.airTypeParam = {
            "MonitorID": 6,
            "FnID": 1,
            "airParam": {
                "floorHeating": [
                    {
                        "F_ID": 23,
                        "F_AirTypeCode": "yssAir",
                        "F_ParamsCode": "floorHeating",
                        "F_ParamsName": "地暖阀回差",
                        "F_ParamsName_En": "Floor heating valve hysteresis",
                        "F_Icon": "",
                        "F_Class": "",
                        "F_Sort": 1,
                        "F_paramsValue": 0
                    }
                ],
                "backlightDelay": [
                    {
                        "F_ID": 22,
                        "F_AirTypeCode": "yssAir",
                        "F_ParamsCode": "backlightDelay",
                        "F_ParamsName": "背光延迟时间",
                        "F_ParamsName_En": "Backlight delay time",
                        "F_Icon": "",
                        "F_Class": "",
                        "F_Sort": 1,
                        "F_paramsValue": 0
                    }
                ],
                "tempDeviation": [
                    {
                        "F_ID": 25,
                        "F_AirTypeCode": "yssAir",
                        "F_ParamsCode": "tempDeviation",
                        "F_ParamsName": "温度偏移",
                        "F_ParamsName_En": "Temperature offset",
                        "F_Icon": "",
                        "F_Class": "",
                        "F_Sort": 1,
                        "F_paramsValue": 0
                    }
                ],
                "setTemp": [
                    {
                        "F_ID": 8,
                        "F_AirTypeCode": "yssAir",
                        "F_ParamsCode": "setTemp",
                        "F_ParamsName": "设置温度",
                        "F_ParamsName_En": "Set temperature",
                        "F_Icon": "",
                        "F_Class": "",
                        "F_Sort": 1,
                        "F_paramsValue": 0
                    }
                ],
                "open": [
                    {
                        "F_ID": 7,
                        "F_AirTypeCode": "yssAir",
                        "F_ParamsCode": "open",
                        "F_ParamsName": "开关状态",
                        "F_ParamsName_En": "switch status",
                        "F_Icon": "",
                        "F_Class": "",
                        "F_Sort": 1,
                        "F_paramsValue": 0
                    }
                ],
                "roomTemp": [
                    {
                        "F_ID": 6,
                        "F_AirTypeCode": "yssAir",
                        "F_ParamsCode": "roomTemp",
                        "F_ParamsName": "环境温度",
                        "F_ParamsName_En": "Ambient temperature",
                        "F_Icon": "",
                        "F_Class": "",
                        "F_Sort": 1,
                        "F_paramsValue": 0
                    }
                ],
                "speedMode": [
                    {
                        "F_ID": 10,
                        "F_AirTypeCode": "yssAir",
                        "F_ParamsCode": "speedMode",
                        "F_ParamsName": "风速模式",
                        "F_ParamsName_En": "Wind speed mode",
                        "F_Icon": "",
                        "F_Class": "",
                        "F_Sort": 1,
                        "F_paramsValue": 0
                    }
                ],
                "value1": [
                    {
                        "F_ID": 14,
                        "F_AirTypeCode": "yssAir",
                        "F_ParamsCode": "value1",
                        "F_ParamsName": "水阀1关",
                        "F_ParamsName_En": "Water valve 1 off",
                        "F_Icon": "",
                        "F_Class": "",
                        "F_Sort": 1,
                        "F_paramsValue": 0
                    },
                    {
                        "F_ID": 15,
                        "F_AirTypeCode": "yssAir",
                        "F_ParamsCode": "value1",
                        "F_ParamsName": "水阀1开",
                        "F_ParamsName_En": "Water valve 1 open",
                        "F_Icon": "",
                        "F_Class": "",
                        "F_Sort": 1,
                        "F_paramsValue": 1
                    }
                ],
                "speed": [
                    {
                        "F_ID": 13,
                        "F_AirTypeCode": "yssAir",
                        "F_ParamsCode": "speed",
                        "F_ParamsName": "高",
                        "F_ParamsName_En": "high",
                        "F_Icon": "",
                        "F_Class": "",
                        "F_Sort": 1,
                        "F_paramsValue": 3
                    },
                    {
                        "F_ID": 12,
                        "F_AirTypeCode": "yssAir",
                        "F_ParamsCode": "speed",
                        "F_ParamsName": "中",
                        "F_ParamsName_En": "in",
                        "F_Icon": "",
                        "F_Class": "",
                        "F_Sort": 2,
                        "F_paramsValue": 2
                    },
                    {
                        "F_ID": 11,
                        "F_AirTypeCode": "yssAir",
                        "F_ParamsCode": "speed",
                        "F_ParamsName": "低",
                        "F_ParamsName_En": "low",
                        "F_Icon": "",
                        "F_Class": "",
                        "F_Sort": 3,
                        "F_paramsValue": 1
                    }
                ],
                "coolOffline": [
                    {
                        "F_ID": 21,
                        "F_AirTypeCode": "yssAir",
                        "F_ParamsCode": "coolOffline",
                        "F_ParamsName": "制冷下限",
                        "F_ParamsName_En": "Lower cooling limit",
                        "F_Icon": "",
                        "F_Class": "",
                        "F_Sort": 1,
                        "F_paramsValue": 0
                    }
                ],
                "value2": [
                    {
                        "F_ID": 16,
                        "F_AirTypeCode": "yssAir",
                        "F_ParamsCode": "value2",
                        "F_ParamsName": "水阀2关",
                        "F_ParamsName_En": "Water valve 2 off",
                        "F_Icon": "",
                        "F_Class": "",
                        "F_Sort": 1,
                        "F_paramsValue": 0
                    },
                    {
                        "F_ID": 17,
                        "F_AirTypeCode": "yssAir",
                        "F_ParamsCode": "value2",
                        "F_ParamsName": "水阀2开",
                        "F_ParamsName_En": "Water valve 2 open",
                        "F_Icon": "",
                        "F_Class": "",
                        "F_Sort": 1,
                        "F_paramsValue": 1
                    }
                ],
                "mode": [
                    {
                        "F_ID": 1,
                        "F_AirTypeCode": "yssAir",
                        "F_ParamsCode": "mode",
                        "F_ParamsName": "地暖模式",
                        "F_ParamsName_En": "Floor heating mode",
                        "F_Icon": "dinuan.png",
                        "F_Class": "hot",
                        "F_Sort": 1,
                        "F_paramsValue": 0
                    },
                    {
                        "F_ID": 2,
                        "F_AirTypeCode": "yssAir",
                        "F_ParamsCode": "mode",
                        "F_ParamsName": "热风模式",
                        "F_ParamsName_En": "Hot air mode",
                        "F_Icon": "nuanfeng.png",
                        "F_Class": "hot",
                        "F_Sort": 2,
                        "F_paramsValue": 1
                    },
                    {
                        "F_ID": 3,
                        "F_AirTypeCode": "yssAir",
                        "F_ParamsCode": "mode",
                        "F_ParamsName": "制冷模式",
                        "F_ParamsName_En": "Cooling mode",
                        "F_Icon": "cool.png",
                        "F_Class": "cool",
                        "F_Sort": 3,
                        "F_paramsValue": 2
                    },
                    {
                        "F_ID": 4,
                        "F_AirTypeCode": "yssAir",
                        "F_ParamsCode": "mode",
                        "F_ParamsName": "通风模式",
                        "F_ParamsName_En": "Ventilation mode",
                        "F_Icon": "songfeng.png",
                        "F_Class": "cool1",
                        "F_Sort": 4,
                        "F_paramsValue": 3
                    },
                    {
                        "F_ID": 5,
                        "F_AirTypeCode": "yssAir",
                        "F_ParamsCode": "mode",
                        "F_ParamsName": "地暖&热风模式",
                        "F_ParamsName_En": "Floor heating & hot air mode",
                        "F_Icon": "nuanfeng1.png",
                        "F_Class": "hot",
                        "F_Sort": 5,
                        "F_paramsValue": 4
                    }
                ],
                "keyboardLock": [
                    {
                        "F_ID": 24,
                        "F_AirTypeCode": "yssAir",
                        "F_ParamsCode": "keyboardLock",
                        "F_ParamsName": "键盘锁",
                        "F_ParamsName_En": "Keyboard lock",
                        "F_Icon": "",
                        "F_Class": "",
                        "F_Sort": 1,
                        "F_paramsValue": 0
                    }
                ],
                "hotUpperLimit": [
                    {
                        "F_ID": 20,
                        "F_AirTypeCode": "yssAir",
                        "F_ParamsCode": "hotUpperLimit",
                        "F_ParamsName": "制热上限",
                        "F_ParamsName_En": "Heating limit",
                        "F_Icon": "",
                        "F_Class": "",
                        "F_Sort": 1,
                        "F_paramsValue": 0
                    }
                ],
                "linkage": [
                    {
                        "F_ID": 18,
                        "F_AirTypeCode": "yssAir",
                        "F_ParamsCode": "linkage",
                        "F_ParamsName": "联动关",
                        "F_ParamsName_En": "Linkage off",
                        "F_Icon": "",
                        "F_Class": "",
                        "F_Sort": 1,
                        "F_paramsValue": 0
                    },
                    {
                        "F_ID": 19,
                        "F_AirTypeCode": "yssAir",
                        "F_ParamsCode": "linkage",
                        "F_ParamsName": "联动开",
                        "F_ParamsName_En": "Linkage open",
                        "F_Icon": "",
                        "F_Class": "",
                        "F_Sort": 1,
                        "F_paramsValue": 1
                    }
                ],
                "eco": [
                    {
                        "F_ID": 9,
                        "F_AirTypeCode": "yssAir",
                        "F_ParamsCode": "eco",
                        "F_ParamsName": "节能模式",
                        "F_ParamsName_En": "Energy saving mode",
                        "F_Icon": "",
                        "F_Class": "",
                        "F_Sort": 1,
                        "F_paramsValue": 0
                    }
                ]
            },
            "airGetInfo": {
                "floorHeating": "F114",
                "backlightDelay": "F113",
                "tempDeviation": "F116",
                "setTemp": "F14",
                "open": "F12",
                "roomTemp": "F11",
                "serviceAddress2": "F61,F62,F63,F64,F65",
                "speedMode": "F16",
                "value1": "F18",
                "speed": "F17",
                "coolOffline": "F112",
                "value2": "F19",
                "mode": "F13",
                "keyboardLock": "F115",
                "serviceAddress1": "F61,F62,F63,F64,F65",
                "hotUpperLimit": "F111",
                "linkage": "F110",
                "eco": "F15"
            },
            "airSetInfo": {
                "coolOffline": 7,
                "keyboardLock": 12,
                "backlightDelay": 8,
                "open": 1,
                "hotUpperLimit": 6,
                "setTemp": 3,
                "eco": 5,
                "speed": 4,
                "mode": 2,
                "value2": 11,
                "value1": 10,
                "tempDeviation": 13
            }
        };
        this.airSetInfo = this.airTypeParam.airSetInfo;
        if (this.airTypeParam.airParam) {
            this.modeKV = this.airTypeParam.airParam["mode"];
            this.speedKV = this.airTypeParam.airParam['speed'];
        }
        this.setCircle();
        // 设备实时数据接收
        this.initDeviceData();
        this.deviceDataSubscribe = this.globalService$.globalVar.subscribe(function (res) {
            if (res.mac && res.mac === _this.mac) {
                _this.initDeviceData();
            }
        });
    };
    ThermostatPage.prototype.initDeviceData = function () {
        var deviceDatas = this.globalService$.DeviceData;
        if (!deviceDatas || !deviceDatas[this.mac]) {
            return;
        }
        console.log("我变化啦");
        console.log(deviceDatas[this.mac]);
        var deviceData = deviceDatas[this.mac];
        this.roomTempData = deviceData.temp_envi;
        this.temp = deviceData.temp_set;
        if (this.setInfo.type === 'setTemp') {
            if (this.temp == this.setInfo.value) {
                this.dismissLoading();
            }
        }
        this.keyboardLock = deviceData.key_lock;
        this.linkage = deviceData.state_link; // 联动
        this.valve1 = deviceData.state_water1; // 水阀1
        this.valve2 = deviceData.state_water2; // 水阀2
        this.open = this.tools.parseToBooleanByString(deviceData.switch_state);
        if (this.setInfo.type === 'open') {
            if (this.open == this.setInfo.value) {
                this.dismissLoading();
            }
        }
        this.speedMode = this.tools.parseToBooleanByString(deviceData.mode_fan);
        console.log(this.speedMode);
        var speedValue = deviceData.state_fan;
        this.getSpeedState(speedValue, deviceData.mode_fan); // 获取风速状态
        this.eco = this.tools.parseToBooleanByString(deviceData.mode_save);
        if (this.setInfo.type === 'eco') {
            if (this.eco == this.setInfo.value) {
                this.dismissLoading();
            }
        }
        this.hotUpperLimit = deviceData.hot_up;
        this.coolOffline = deviceData.cold_down;
        this.getModeState(deviceData.mode_work); // 获取模式状态
        this.setCircleNum();
    };
    ThermostatPage.prototype.controlDevice = function (code, value) {
        var params = {
            type: 'set',
            mac: this.queryParams.mac,
            set: {
                code: code,
                value: [value]
            }
        };
        console.log(params);
        _common_variable__WEBPACK_IMPORTED_MODULE_3__["Variable"].socketObject.sendMessage(params);
        this.tools.showLoading('');
    };
    ThermostatPage.prototype.getTempColumns = function () {
        var t = [];
        for (var i = this.tempMin; i <= this.tempMax; i++) {
            t.push({ text: "" + i, value: i });
        }
        this.tempColumns = [
            {
                options: t
            }
        ];
    };
    ThermostatPage.prototype.getTempNum = function (data) {
        var num = Number(data);
        return num;
    };
    ThermostatPage.prototype.setCircle = function () {
        this.barCircleObj = new progressbar_js__WEBPACK_IMPORTED_MODULE_4__["Circle"](document.getElementById('circlebar'), {
            strokeWidth: 3,
            easing: 'easeInOut',
            duration: 500,
            color: '#52A1F3',
            trailColor: '#eee',
            trailWidth: 3,
            svgStyle: null,
        });
        // this.setCircleNum();
    };
    ThermostatPage.prototype.setCircleNum = function () {
        this.getTempColumns();
        var num = (this.temp * 1 - this.tempMin * 1) / (this.tempMax * 1 - this.tempMin * 1);
        console.log(num);
        this.barCircleObj.animate(num);
    };
    ThermostatPage.prototype.tempAdd = function () {
        this.temp = Number(this.temp);
        if (this.temp < this.tempMax) {
            this.temp++;
            // this.setCircleNum();
            this.setTempoutTemp();
        }
    };
    ThermostatPage.prototype.setTempoutTemp = function () {
        var _this = this;
        if (this.tempTimeoutObj) {
            clearTimeout(this.tempTimeoutObj);
        }
        this.tempTimeoutObj = setTimeout(function () {
            _this.setCircleNum();
            _this.setAirTemp();
        }, 500);
    };
    ThermostatPage.prototype.setAirTemp = function () {
        // Variable.socketObject.sendMessage(this.monitorID, this.airSetInfo['setTemp'], Number(this.temp))
        this.controlDevice('temp_set', this.temp);
        this.checkSetInfo('setTemp', this.temp);
    };
    ThermostatPage.prototype.tempSub = function () {
        this.temp = Number(this.temp);
        if (this.temp > this.tempMin) {
            this.temp--;
            // this.setCircleNum();
            this.setTempoutTemp();
        }
    };
    ThermostatPage.prototype.changeTemp = function () {
        this.setCircleNum();
        this.setAirTemp();
    };
    ThermostatPage.prototype.modeChange = function () {
    };
    ThermostatPage.prototype.setOpen = function () {
        this.open = !this.open;
        this.controlDevice('switch_state', this.open ? 1 : 0);
        // Variable.socketObject.sendMessage(this.monitorID, this.airSetInfo['open'], this.open ? 1 : 0)
        this.checkSetInfo('open', this.open);
    };
    ThermostatPage.prototype.setEco = function () {
        this.eco = !this.eco;
        // Variable.socketObject.sendMessage(this.monitorID, this.airSetInfo['eco'], this.eco ? 1 : 0)
        this.controlDevice('mode_save', this.eco ? 1 : 0);
        this.checkSetInfo('eco', this.eco);
    };
    ThermostatPage.prototype.setSpeed = function (data) {
        this.speedMode = true;
        this.selectedSpped = data;
        // this.setAir(data['F_Mode'], data['F_Code']);
        // Variable.socketObject.sendMessage(this.monitorID, this.airSetInfo['speed'], data.F_paramsValue)
        this.controlDevice('state_fan', data.F_paramsValue);
        this.checkSetInfo('speed', data.F_ID);
    };
    ThermostatPage.prototype.setSpeedMode = function () {
        this.selectedSpped = {};
        this.speedMode = false;
        // this.setAir(data['F_Mode'], data['F_Code']);
        // Variable.socketObject.sendMessage(this.monitorID, this.airSetInfo['speed'], 0)
        this.controlDevice('state_fan', 0);
        this.checkSetInfo('speedMode', true);
    };
    ThermostatPage.prototype.setMode = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var modalObj;
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.modalController.create({
                            component: _modals_air_setting_modal_air_setting_modal_page__WEBPACK_IMPORTED_MODULE_8__["AirSettingModalPage"],
                            componentProps: {
                                Data: this.modeKV
                            }
                        })];
                    case 1:
                        modalObj = _a.sent();
                        modalObj.present();
                        // 模态框被关闭后回回调该方法 res 为返回值
                        modalObj.onDidDismiss().then(function (res) {
                            res = res.data;
                            console.log(res);
                            if (res != null) {
                                _this.selectedMode = res;
                                // Variable.socketObject.sendMessage(this.monitorID, this.airSetInfo['mode'], res.F_paramsValue)
                                _this.controlDevice('mode_set', res.F_paramsValue);
                                _this.checkSetInfo('mode', res.F_ID);
                            }
                        });
                        return [2 /*return*/];
                }
            });
        });
    };
    ThermostatPage.prototype.setAir = function (mode, code) {
        var setID = this.airParams.F_SetID;
        var data = setID + "," + mode + "," + code; //42 主机标号 模式 参数
        // Variable.socketObject.setAir(data, this.airParams.F_MonitorID, this.airParams.F_SetFnID);
    };
    ThermostatPage.prototype.checkSetInfo = function (type, value) {
        this.setInfo.type = type;
        this.setInfo.value = value;
    };
    ThermostatPage.prototype.getSpeedState = function (speed, speedMode) {
        if (speedMode == '0') {
            this.speedMode = false;
            if (this.setInfo.type === 'speedMode') {
                this.dismissLoading();
            }
            this.selectedSpped = {};
        }
        else {
            var temp_1 = {};
            this.speedKV.forEach(function (element) {
                if (element.F_paramsValue == speed) {
                    temp_1 = element;
                    // this.speedMode = false;
                }
            });
            if (temp_1) {
                if (this.setInfo.type === 'speed') {
                    if (temp_1["F_ID"] == this.setInfo.value) {
                        this.dismissLoading();
                    }
                }
            }
            this.selectedSpped = temp_1;
        }
    };
    ThermostatPage.prototype.getModeState = function (modeValue) {
        var _this = this;
        this.modeKV.forEach(function (element) {
            if (element.F_paramsValue == modeValue) {
                _this.selectedMode = element;
                if (_this.eco) {
                    if (element.F_Class == 'hot') {
                        _this.tempMax = _this.hotUpperLimit;
                        _this.tempMin = 15;
                    }
                    else if (element.F_Class == 'cool') {
                        _this.tempMin = _this.coolOffline;
                        _this.tempMax = 30;
                    }
                    else {
                        _this.tempMin = 15;
                        _this.tempMax = 30;
                    }
                }
                else {
                    _this.tempMin = 15;
                    _this.tempMax = 30;
                }
                if (_this.setInfo.type === 'mode') {
                    if (element.F_ID == _this.setInfo.value) {
                        _this.dismissLoading();
                    }
                }
            }
        });
    };
    ThermostatPage.prototype.dismissLoading = function () {
        this.setInfo.type = '';
        this.setInfo.value = '';
        this.tools.dismissLoading();
    };
    ThermostatPage.prototype.goMorePage = function () {
        this.router.navigate(['/thermostat-detail'], { queryParams: this.queryParams });
    };
    ThermostatPage.ctorParameters = function () { return [
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"] },
        { type: _services_global_service__WEBPACK_IMPORTED_MODULE_5__["GlobalService"] },
        { type: _services_tools_service__WEBPACK_IMPORTED_MODULE_6__["ToolsService"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__["ModalController"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] }
    ]; };
    ThermostatPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-thermostat',
            template: __webpack_require__(/*! raw-loader!./thermostat.page.html */ "./node_modules/raw-loader/index.js!./src/app/pages/thermostat/thermostat.page.html"),
            styles: [__webpack_require__(/*! ./thermostat.page.scss */ "./src/app/pages/thermostat/thermostat.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"], _services_global_service__WEBPACK_IMPORTED_MODULE_5__["GlobalService"], _services_tools_service__WEBPACK_IMPORTED_MODULE_6__["ToolsService"], _ionic_angular__WEBPACK_IMPORTED_MODULE_7__["ModalController"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]])
    ], ThermostatPage);
    return ThermostatPage;
}());



/***/ }),

/***/ "./src/app/pipes/bool.pipe.ts":
/*!************************************!*\
  !*** ./src/app/pipes/bool.pipe.ts ***!
  \************************************/
/*! exports provided: BoolPipe */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BoolPipe", function() { return BoolPipe; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var BoolPipe = /** @class */ (function () {
    function BoolPipe() {
    }
    BoolPipe.prototype.transform = function (value) {
        var args = [];
        for (var _i = 1; _i < arguments.length; _i++) {
            args[_i - 1] = arguments[_i];
        }
        if (parseInt(value)) {
            var n = parseInt(value);
            if (n == 0) {
                return false;
            }
            else {
                return true;
            }
        }
        else {
            return false;
        }
    };
    BoolPipe = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Pipe"])({
            name: 'bool'
        })
    ], BoolPipe);
    return BoolPipe;
}());



/***/ })

}]);
//# sourceMappingURL=pages-thermostat-thermostat-module-es5.js.map