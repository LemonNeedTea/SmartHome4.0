(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-device-catalogue-device-catalogue-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/pages/device-catalogue/device-catalogue.page.html":
/*!*********************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/pages/device-catalogue/device-catalogue.page.html ***!
  \*********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button></ion-back-button>\n    </ion-buttons>\n    <ion-title>分类</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content fullscreen forceOverscroll='true'>\n    <!-- Searchbar with cancel button always shown -->\n    <ion-searchbar placeholder=\"搜索\"></ion-searchbar>\n  <div class=\"cate_content\">\n    <div class=\"cate_left\">\n      <ul class=\"my-list\">\n        <li *ngFor=\"let item of categoryList\" (click)=\"setType(item.id)\"\n          [ngClass]=\"{'left-select': item.id===selectCategoryID}\">\n          <ion-text>\n            {{item.name}}\n          </ion-text>\n        </li>\n\n\n\n      </ul>\n    </div>\n\n    <div class=\"cate_right\">\n      <ion-grid >\n        <ion-row>\n          <ion-col  (click)=\"goDeviceConfig(type)\" size=\"4\" *ngFor=\"let type of showTypeList\">\n            <ion-img class=\"img\" [src]=\"type.img\"></ion-img>\n            <ion-text>\n              {{type.name}}\n            </ion-text>\n          </ion-col>\n        </ion-row>\n      </ion-grid>\n    </div>\n\n\n  </div>\n</ion-content>\n\n"

/***/ }),

/***/ "./src/app/pages/device-catalogue/device-catalogue-routing.module.ts":
/*!***************************************************************************!*\
  !*** ./src/app/pages/device-catalogue/device-catalogue-routing.module.ts ***!
  \***************************************************************************/
/*! exports provided: DeviceCataloguePageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DeviceCataloguePageRoutingModule", function() { return DeviceCataloguePageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _device_catalogue_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./device-catalogue.page */ "./src/app/pages/device-catalogue/device-catalogue.page.ts");




const routes = [
    {
        path: '',
        component: _device_catalogue_page__WEBPACK_IMPORTED_MODULE_3__["DeviceCataloguePage"]
    }
];
let DeviceCataloguePageRoutingModule = class DeviceCataloguePageRoutingModule {
};
DeviceCataloguePageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], DeviceCataloguePageRoutingModule);



/***/ }),

/***/ "./src/app/pages/device-catalogue/device-catalogue.module.ts":
/*!*******************************************************************!*\
  !*** ./src/app/pages/device-catalogue/device-catalogue.module.ts ***!
  \*******************************************************************/
/*! exports provided: DeviceCataloguePageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DeviceCataloguePageModule", function() { return DeviceCataloguePageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _device_catalogue_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./device-catalogue-routing.module */ "./src/app/pages/device-catalogue/device-catalogue-routing.module.ts");
/* harmony import */ var _device_catalogue_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./device-catalogue.page */ "./src/app/pages/device-catalogue/device-catalogue.page.ts");







let DeviceCataloguePageModule = class DeviceCataloguePageModule {
};
DeviceCataloguePageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _device_catalogue_routing_module__WEBPACK_IMPORTED_MODULE_5__["DeviceCataloguePageRoutingModule"]
        ],
        declarations: [_device_catalogue_page__WEBPACK_IMPORTED_MODULE_6__["DeviceCataloguePage"]]
    })
], DeviceCataloguePageModule);



/***/ }),

/***/ "./src/app/pages/device-catalogue/device-catalogue.page.scss":
/*!*******************************************************************!*\
  !*** ./src/app/pages/device-catalogue/device-catalogue.page.scss ***!
  \*******************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "@charset \"UTF-8\";\n.cate_content {\n  width: 100%;\n  height: 100%;\n  /*首先看高度100% 是否管用  如果没有作用我们要给元素设置绝对定位*/\n  display: -webkit-box;\n  display: flex;\n}\n.cate_content .cate_left {\n  width: 100px;\n  height: 100%;\n  border-right: 1px solid #eee;\n  overflow-y: auto;\n  color: #666;\n  max-width: 250px;\n}\n.cate_content .cate_left .item-selected {\n  border-left: 3px;\n  border-left-style: solid;\n  background-color: #eee;\n}\n.cate_content .cate_left ion-item {\n  padding: 0;\n  text-align: center;\n}\n.cate_content .cate_left ion-item .item-inner {\n  padding: 0;\n}\n.my-list {\n  list-style: none;\n  /*去掉小圆点*/\n  padding: 0;\n}\n.my-list li {\n  text-align: center;\n  height: 40px;\n  line-height: 40px;\n  font-size: 14px;\n}\n.left-select {\n  color: var(--ion-color-primary);\n}\n.cate_right {\n  width: 100%;\n}\n.cate_right ion-grid {\n  width: 100%;\n}\n.cate_right ion-col {\n  display: -webkit-box;\n  display: flex;\n  -webkit-box-pack: center;\n          justify-content: center;\n  -webkit-box-align: center;\n          align-items: center;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n          flex-direction: column;\n}\n.cate_right .img {\n  height: 50px;\n  width: 50px;\n}\n.cate_right ion-text {\n  font-size: 12px;\n  margin: 15px 0;\n  color: #333;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvZGV2aWNlLWNhdGFsb2d1ZS9kZXZpY2UtY2F0YWxvZ3VlLnBhZ2Uuc2NzcyIsIi9Vc2Vycy96aG91Ym8vUHJvamVjdC9TbWFydEhvbWU0LjAvc3JjL2FwcC9wYWdlcy9kZXZpY2UtY2F0YWxvZ3VlL2RldmljZS1jYXRhbG9ndWUucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLGdCQUFnQjtBQ0FoQjtFQUNFLFdBQUE7RUFDQSxZQUFBO0VBQ0EscUNBQUE7RUFDQSxvQkFBQTtFQUFBLGFBQUE7QURFRjtBQ0FFO0VBQ0UsWUFBQTtFQUNBLFlBQUE7RUFDQSw0QkFBQTtFQUNBLGdCQUFBO0VBQ0EsV0FBQTtFQUNBLGdCQUFBO0FERUo7QUNDSTtFQUNFLGdCQUFBO0VBQ0Esd0JBQUE7RUFFQSxzQkFBQTtBREFOO0FDR0k7RUFDRSxVQUFBO0VBQ0Esa0JBQUE7QURETjtBQ0dNO0VBQ0UsVUFBQTtBRERSO0FDWUE7RUFDRSxnQkFBQTtFQUFrQixRQUFBO0VBRWxCLFVBQUE7QURURjtBQ1dBO0VBQ0Usa0JBQUE7RUFDQSxZQUFBO0VBQ0EsaUJBQUE7RUFDQSxlQUFBO0FEUkY7QUNVQTtFQUNFLCtCQUFBO0FEUEY7QUNTQTtFQUNJLFdBQUE7QUROSjtBQ1FBO0VBQ0ksV0FBQTtBRExKO0FDT0E7RUFDSSxvQkFBQTtFQUFBLGFBQUE7RUFDQSx3QkFBQTtVQUFBLHVCQUFBO0VBQ0EseUJBQUE7VUFBQSxtQkFBQTtFQUNBLDRCQUFBO0VBQUEsNkJBQUE7VUFBQSxzQkFBQTtBREpKO0FDTUE7RUFDSSxZQUFBO0VBQ0EsV0FBQTtBREhKO0FDS0E7RUFDSSxlQUFBO0VBQ0EsY0FBQTtFQUNBLFdBQUE7QURGSiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL2RldmljZS1jYXRhbG9ndWUvZGV2aWNlLWNhdGFsb2d1ZS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJAY2hhcnNldCBcIlVURi04XCI7XG4uY2F0ZV9jb250ZW50IHtcbiAgd2lkdGg6IDEwMCU7XG4gIGhlaWdodDogMTAwJTtcbiAgLyrpppblhYjnnIvpq5jluqYxMDAlIOaYr+WQpueuoeeUqCAg5aaC5p6c5rKh5pyJ5L2c55So5oiR5Lus6KaB57uZ5YWD57Sg6K6+572u57ud5a+55a6a5L2NKi9cbiAgZGlzcGxheTogZmxleDtcbn1cbi5jYXRlX2NvbnRlbnQgLmNhdGVfbGVmdCB7XG4gIHdpZHRoOiAxMDBweDtcbiAgaGVpZ2h0OiAxMDAlO1xuICBib3JkZXItcmlnaHQ6IDFweCBzb2xpZCAjZWVlO1xuICBvdmVyZmxvdy15OiBhdXRvO1xuICBjb2xvcjogIzY2NjtcbiAgbWF4LXdpZHRoOiAyNTBweDtcbn1cbi5jYXRlX2NvbnRlbnQgLmNhdGVfbGVmdCAuaXRlbS1zZWxlY3RlZCB7XG4gIGJvcmRlci1sZWZ0OiAzcHg7XG4gIGJvcmRlci1sZWZ0LXN0eWxlOiBzb2xpZDtcbiAgYmFja2dyb3VuZC1jb2xvcjogI2VlZTtcbn1cbi5jYXRlX2NvbnRlbnQgLmNhdGVfbGVmdCBpb24taXRlbSB7XG4gIHBhZGRpbmc6IDA7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbn1cbi5jYXRlX2NvbnRlbnQgLmNhdGVfbGVmdCBpb24taXRlbSAuaXRlbS1pbm5lciB7XG4gIHBhZGRpbmc6IDA7XG59XG5cbi5teS1saXN0IHtcbiAgbGlzdC1zdHlsZTogbm9uZTtcbiAgLyrljrvmjonlsI/lnIbngrkqL1xuICBwYWRkaW5nOiAwO1xufVxuXG4ubXktbGlzdCBsaSB7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgaGVpZ2h0OiA0MHB4O1xuICBsaW5lLWhlaWdodDogNDBweDtcbiAgZm9udC1zaXplOiAxNHB4O1xufVxuXG4ubGVmdC1zZWxlY3Qge1xuICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xufVxuXG4uY2F0ZV9yaWdodCB7XG4gIHdpZHRoOiAxMDAlO1xufVxuXG4uY2F0ZV9yaWdodCBpb24tZ3JpZCB7XG4gIHdpZHRoOiAxMDAlO1xufVxuXG4uY2F0ZV9yaWdodCBpb24tY29sIHtcbiAgZGlzcGxheTogZmxleDtcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XG59XG5cbi5jYXRlX3JpZ2h0IC5pbWcge1xuICBoZWlnaHQ6IDUwcHg7XG4gIHdpZHRoOiA1MHB4O1xufVxuXG4uY2F0ZV9yaWdodCBpb24tdGV4dCB7XG4gIGZvbnQtc2l6ZTogMTJweDtcbiAgbWFyZ2luOiAxNXB4IDA7XG4gIGNvbG9yOiAjMzMzO1xufSIsIi5jYXRlX2NvbnRlbnQge1xuICB3aWR0aDogMTAwJTtcbiAgaGVpZ2h0OiAxMDAlO1xuICAvKummluWFiOeci+mrmOW6pjEwMCUg5piv5ZCm566h55SoICDlpoLmnpzmsqHmnInkvZznlKjmiJHku6zopoHnu5nlhYPntKDorr7nva7nu53lr7nlrprkvY0qL1xuICBkaXNwbGF5OiBmbGV4O1xuXG4gIC5jYXRlX2xlZnQge1xuICAgIHdpZHRoOiAxMDBweDtcbiAgICBoZWlnaHQ6IDEwMCU7XG4gICAgYm9yZGVyLXJpZ2h0OiAxcHggc29saWQgI2VlZTtcbiAgICBvdmVyZmxvdy15OiBhdXRvO1xuICAgIGNvbG9yOiAjNjY2O1xuICAgIG1heC13aWR0aDogMjUwcHg7XG4gICAgLy8gICBtaW4td2lkdGg6IDk1cHg7XG5cbiAgICAuaXRlbS1zZWxlY3RlZCB7XG4gICAgICBib3JkZXItbGVmdDogM3B4O1xuICAgICAgYm9yZGVyLWxlZnQtc3R5bGU6IHNvbGlkO1xuICAgICAgLy8gYm9yZGVyLWNvbG9yOiBjb2xvcigkY29sb3JzLCBwcmltYXJ5KTtcbiAgICAgIGJhY2tncm91bmQtY29sb3I6ICNlZWU7XG4gICAgfVxuXG4gICAgaW9uLWl0ZW0ge1xuICAgICAgcGFkZGluZzogMDtcbiAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcblxuICAgICAgLml0ZW0taW5uZXIge1xuICAgICAgICBwYWRkaW5nOiAwO1xuICAgICAgfVxuXG4gICAgICAvLyBpbWd7XG4gICAgICAvLyAgICAgd2lkdGg6IDIwcHg7XG4gICAgICAvLyAgICAgaGVpZ2h0OiAyMHB4O1xuICAgICAgLy8gfVxuICAgIH1cbiAgfVxufVxuXG4ubXktbGlzdCB7XG4gIGxpc3Qtc3R5bGU6IG5vbmU7IC8q5Y675o6J5bCP5ZyG54K5Ki9cbiAgLy8gICBtYXJnaW46IDA7XG4gIHBhZGRpbmc6IDA7XG59XG4ubXktbGlzdCBsaSB7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgaGVpZ2h0OiA0MHB4O1xuICBsaW5lLWhlaWdodDogNDBweDtcbiAgZm9udC1zaXplOiAxNHB4O1xufVxuLmxlZnQtc2VsZWN0IHtcbiAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KTtcbn1cbi5jYXRlX3JpZ2h0IHtcbiAgICB3aWR0aDogMTAwJTtcbn1cbi5jYXRlX3JpZ2h0IGlvbi1ncmlke1xuICAgIHdpZHRoOiAxMDAlO1xufVxuLmNhdGVfcmlnaHQgaW9uLWNvbHtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gICAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcbn1cbi5jYXRlX3JpZ2h0IC5pbWd7XG4gICAgaGVpZ2h0OiA1MHB4O1xuICAgIHdpZHRoOiA1MHB4O1xufVxuLmNhdGVfcmlnaHQgaW9uLXRleHR7XG4gICAgZm9udC1zaXplOiAxMnB4O1xuICAgIG1hcmdpbjogMTVweCAwO1xuICAgIGNvbG9yOiAjMzMzO1xufVxuIl19 */"

/***/ }),

/***/ "./src/app/pages/device-catalogue/device-catalogue.page.ts":
/*!*****************************************************************!*\
  !*** ./src/app/pages/device-catalogue/device-catalogue.page.ts ***!
  \*****************************************************************/
/*! exports provided: DeviceCataloguePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DeviceCataloguePage", function() { return DeviceCataloguePage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _services_request_device_request_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../services/request/device-request.service */ "./src/app/services/request/device-request.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");




let DeviceCataloguePage = class DeviceCataloguePage {
    constructor(device, router) {
        this.device = device;
        this.router = router;
        this.initData();
    }
    initData() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            yield this.device.getProductList().then((res) => {
                this.typeList = res.typeList;
                this.categoryList = res.categoryList;
            });
            this.selectCategoryID = this.categoryList[0].id;
            this.getshowTypeList();
        });
    }
    setType(id) {
        this.selectCategoryID = id;
        this.getshowTypeList();
    }
    getshowTypeList() {
        this.showTypeList = this.typeList.filter(item => {
            if (item.categoryId === this.selectCategoryID) {
                return item;
            }
        });
    }
    goDeviceConfig(data) {
        this.router.navigate(['/device-config'], { queryParams: { code: data.code, name: data.name } });
    }
    ngOnInit() {
    }
};
DeviceCataloguePage.ctorParameters = () => [
    { type: _services_request_device_request_service__WEBPACK_IMPORTED_MODULE_2__["DeviceRequestService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"] }
];
DeviceCataloguePage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-device-catalogue',
        template: __webpack_require__(/*! raw-loader!./device-catalogue.page.html */ "./node_modules/raw-loader/index.js!./src/app/pages/device-catalogue/device-catalogue.page.html"),
        styles: [__webpack_require__(/*! ./device-catalogue.page.scss */ "./src/app/pages/device-catalogue/device-catalogue.page.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_services_request_device_request_service__WEBPACK_IMPORTED_MODULE_2__["DeviceRequestService"],
        _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"]])
], DeviceCataloguePage);



/***/ })

}]);
//# sourceMappingURL=pages-device-catalogue-device-catalogue-module-es2015.js.map