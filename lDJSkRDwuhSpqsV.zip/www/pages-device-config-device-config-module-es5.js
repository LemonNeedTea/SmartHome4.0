(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-device-config-device-config-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/pages/device-config/device-config.page.html":
/*!***************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/pages/device-config/device-config.page.html ***!
  \***************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header > \n  <ion-toolbar color=\"light\">\n    <ion-buttons slot=\"start\">\n      <ion-back-button></ion-back-button>\n    </ion-buttons>\n    <ion-title>配置向导</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content padding>\n<ion-img [src]=\"img\"></ion-img>\n</ion-content>\n<ion-footer>\n    <ion-item lines=\"none\">\n      <ion-label>已完成上述操作</ion-label>\n    <ion-checkbox color=\"primary\" slot=\"start\" [(ngModel)]='check'></ion-checkbox>\n    </ion-item>\n  \n  <ion-toolbar class=\"next\">\n    <ion-title>\n    <ion-button size='small' color='light' [disabled]='!check' (click)=\"goWifiSettting()\">下一步</ion-button>\n\n    </ion-title>\n  </ion-toolbar>\n</ion-footer>"

/***/ }),

/***/ "./src/app/pages/device-config/device-config-routing.module.ts":
/*!*********************************************************************!*\
  !*** ./src/app/pages/device-config/device-config-routing.module.ts ***!
  \*********************************************************************/
/*! exports provided: DeviceConfigPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DeviceConfigPageRoutingModule", function() { return DeviceConfigPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _device_config_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./device-config.page */ "./src/app/pages/device-config/device-config.page.ts");




var routes = [
    {
        path: '',
        component: _device_config_page__WEBPACK_IMPORTED_MODULE_3__["DeviceConfigPage"]
    }
];
var DeviceConfigPageRoutingModule = /** @class */ (function () {
    function DeviceConfigPageRoutingModule() {
    }
    DeviceConfigPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
        })
    ], DeviceConfigPageRoutingModule);
    return DeviceConfigPageRoutingModule;
}());



/***/ }),

/***/ "./src/app/pages/device-config/device-config.module.ts":
/*!*************************************************************!*\
  !*** ./src/app/pages/device-config/device-config.module.ts ***!
  \*************************************************************/
/*! exports provided: DeviceConfigPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DeviceConfigPageModule", function() { return DeviceConfigPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _device_config_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./device-config-routing.module */ "./src/app/pages/device-config/device-config-routing.module.ts");
/* harmony import */ var _device_config_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./device-config.page */ "./src/app/pages/device-config/device-config.page.ts");







var DeviceConfigPageModule = /** @class */ (function () {
    function DeviceConfigPageModule() {
    }
    DeviceConfigPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
                _device_config_routing_module__WEBPACK_IMPORTED_MODULE_5__["DeviceConfigPageRoutingModule"]
            ],
            declarations: [_device_config_page__WEBPACK_IMPORTED_MODULE_6__["DeviceConfigPage"]]
        })
    ], DeviceConfigPageModule);
    return DeviceConfigPageModule;
}());



/***/ }),

/***/ "./src/app/pages/device-config/device-config.page.scss":
/*!*************************************************************!*\
  !*** ./src/app/pages/device-config/device-config.page.scss ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-button {\n  width: 200px !important;\n}\n\nion-footer ion-toolbar {\n  --min-height: 60px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy96aG91Ym8vUHJvamVjdC9TbWFydEhvbWU0LjAvc3JjL2FwcC9wYWdlcy9kZXZpY2UtY29uZmlnL2RldmljZS1jb25maWcucGFnZS5zY3NzIiwic3JjL2FwcC9wYWdlcy9kZXZpY2UtY29uZmlnL2RldmljZS1jb25maWcucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksdUJBQUE7QUNDSjs7QURFQTtFQUNFLGtCQUFBO0FDQ0YiLCJmaWxlIjoic3JjL2FwcC9wYWdlcy9kZXZpY2UtY29uZmlnL2RldmljZS1jb25maWcucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWJ1dHRvbntcbiAgICB3aWR0aDogMjAwcHggIWltcG9ydGFudDtcbn1cblxuaW9uLWZvb3RlciBpb24tdG9vbGJhciB7XG4gIC0tbWluLWhlaWdodDogNjBweDtcbn0iLCJpb24tYnV0dG9uIHtcbiAgd2lkdGg6IDIwMHB4ICFpbXBvcnRhbnQ7XG59XG5cbmlvbi1mb290ZXIgaW9uLXRvb2xiYXIge1xuICAtLW1pbi1oZWlnaHQ6IDYwcHg7XG59Il19 */"

/***/ }),

/***/ "./src/app/pages/device-config/device-config.page.ts":
/*!***********************************************************!*\
  !*** ./src/app/pages/device-config/device-config.page.ts ***!
  \***********************************************************/
/*! exports provided: DeviceConfigPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DeviceConfigPage", function() { return DeviceConfigPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _services_request_device_request_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../services/request/device-request.service */ "./src/app/services/request/device-request.service.ts");




var DeviceConfigPage = /** @class */ (function () {
    function DeviceConfigPage(route, device, router) {
        var _this = this;
        this.route = route;
        this.device = device;
        this.router = router;
        this.queryParams = this.route.snapshot.queryParams;
        console.log(this.queryParams);
        this.device.getInfoByTypeID(this.queryParams.code).then(function (res) {
            console.log(res);
            _this.img = res.img;
        });
    }
    DeviceConfigPage.prototype.ngOnInit = function () {
    };
    DeviceConfigPage.prototype.goWifiSettting = function () {
        this.router.navigate(['/wifi-setting'], { queryParams: this.queryParams });
    };
    DeviceConfigPage.ctorParameters = function () { return [
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"] },
        { type: _services_request_device_request_service__WEBPACK_IMPORTED_MODULE_3__["DeviceRequestService"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] }
    ]; };
    DeviceConfigPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-device-config',
            template: __webpack_require__(/*! raw-loader!./device-config.page.html */ "./node_modules/raw-loader/index.js!./src/app/pages/device-config/device-config.page.html"),
            styles: [__webpack_require__(/*! ./device-config.page.scss */ "./src/app/pages/device-config/device-config.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"], _services_request_device_request_service__WEBPACK_IMPORTED_MODULE_3__["DeviceRequestService"],
            _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]])
    ], DeviceConfigPage);
    return DeviceConfigPage;
}());



/***/ })

}]);
//# sourceMappingURL=pages-device-config-device-config-module-es5.js.map