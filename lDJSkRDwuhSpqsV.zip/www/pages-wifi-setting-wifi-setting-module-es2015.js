(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-wifi-setting-wifi-setting-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/pages/wifi-setting/wifi-setting.page.html":
/*!*************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/pages/wifi-setting/wifi-setting.page.html ***!
  \*************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n  <ion-toolbar color=\"light\">\n    <ion-buttons slot=\"start\">\n      <ion-back-button></ion-back-button>\n    </ion-buttons>\n    <ion-title>WIFI配置</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content class=\"ion-padding\">\n  <div class=\"wifi-icon\">\n  <ion-icon name=\"wifi\"  ></ion-icon>\n\n  </div>\n  <ion-list margin-top margin-bottom>\n\n    <ion-item>\n      <ion-input type=\"text\" tabindex=\"20\" (keyup.enter)=\"moveFocus(b)\" placeholder=\"WIFI\" [(ngModel)]=\"ssid\" required></ion-input>\n    </ion-item>\n        <ion-item>\n          <ion-input [type]=\"passwordType\" (keyup.enter)=\"moveFocus(c)\" #b placeholder=\"Password\" [(ngModel)]=\"password\"\n            required></ion-input>\n          <ion-icon (click)='hideShowPassword()' [name]=\"passwordIcon\" item-right></ion-icon>\n        </ion-item>\n            <ion-item lines=\"none\">\n              <ion-label style=\"font-size: 14px;\" color='medium'>允许记住密码</ion-label>\n              <ion-checkbox color=\"primary\" slot=\"start\" [(ngModel)]='check'></ion-checkbox>\n            </ion-item>\n  </ion-list>\n</ion-content>\n\n<ion-footer>\n  <ion-toolbar class=\"next\">\n    <ion-title>\n      <ion-button size='small' color='light'  (click)=\"goWifiPush()\">下一步</ion-button>\n\n    </ion-title>\n  </ion-toolbar>\n</ion-footer>"

/***/ }),

/***/ "./src/app/pages/wifi-setting/wifi-setting-routing.module.ts":
/*!*******************************************************************!*\
  !*** ./src/app/pages/wifi-setting/wifi-setting-routing.module.ts ***!
  \*******************************************************************/
/*! exports provided: WifiSettingPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "WifiSettingPageRoutingModule", function() { return WifiSettingPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _wifi_setting_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./wifi-setting.page */ "./src/app/pages/wifi-setting/wifi-setting.page.ts");




const routes = [
    {
        path: '',
        component: _wifi_setting_page__WEBPACK_IMPORTED_MODULE_3__["WifiSettingPage"]
    }
];
let WifiSettingPageRoutingModule = class WifiSettingPageRoutingModule {
};
WifiSettingPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], WifiSettingPageRoutingModule);



/***/ }),

/***/ "./src/app/pages/wifi-setting/wifi-setting.module.ts":
/*!***********************************************************!*\
  !*** ./src/app/pages/wifi-setting/wifi-setting.module.ts ***!
  \***********************************************************/
/*! exports provided: WifiSettingPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "WifiSettingPageModule", function() { return WifiSettingPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _wifi_setting_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./wifi-setting-routing.module */ "./src/app/pages/wifi-setting/wifi-setting-routing.module.ts");
/* harmony import */ var _wifi_setting_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./wifi-setting.page */ "./src/app/pages/wifi-setting/wifi-setting.page.ts");







let WifiSettingPageModule = class WifiSettingPageModule {
};
WifiSettingPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _wifi_setting_routing_module__WEBPACK_IMPORTED_MODULE_5__["WifiSettingPageRoutingModule"]
        ],
        declarations: [_wifi_setting_page__WEBPACK_IMPORTED_MODULE_6__["WifiSettingPage"]]
    })
], WifiSettingPageModule);



/***/ }),

/***/ "./src/app/pages/wifi-setting/wifi-setting.page.scss":
/*!***********************************************************!*\
  !*** ./src/app/pages/wifi-setting/wifi-setting.page.scss ***!
  \***********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-button {\n  width: 200px !important;\n}\n\nion-footer ion-toolbar {\n  --min-height: 60px;\n}\n\n.wifi-icon {\n  font-size: 130px;\n  text-align: center;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy96aG91Ym8vUHJvamVjdC9TbWFydEhvbWU0LjAvc3JjL2FwcC9wYWdlcy93aWZpLXNldHRpbmcvd2lmaS1zZXR0aW5nLnBhZ2Uuc2NzcyIsInNyYy9hcHAvcGFnZXMvd2lmaS1zZXR0aW5nL3dpZmktc2V0dGluZy5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSx1QkFBQTtBQ0NKOztBREVBO0VBQ0Usa0JBQUE7QUNDRjs7QURDQTtFQUNJLGdCQUFBO0VBQ0Esa0JBQUE7QUNFSiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL3dpZmktc2V0dGluZy93aWZpLXNldHRpbmcucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWJ1dHRvbntcbiAgICB3aWR0aDogMjAwcHggIWltcG9ydGFudDtcbn1cblxuaW9uLWZvb3RlciBpb24tdG9vbGJhciB7XG4gIC0tbWluLWhlaWdodDogNjBweDtcbn1cbi53aWZpLWljb257XG4gICAgZm9udC1zaXplOiAxMzBweDtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG59IiwiaW9uLWJ1dHRvbiB7XG4gIHdpZHRoOiAyMDBweCAhaW1wb3J0YW50O1xufVxuXG5pb24tZm9vdGVyIGlvbi10b29sYmFyIHtcbiAgLS1taW4taGVpZ2h0OiA2MHB4O1xufVxuXG4ud2lmaS1pY29uIHtcbiAgZm9udC1zaXplOiAxMzBweDtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xufSJdfQ== */"

/***/ }),

/***/ "./src/app/pages/wifi-setting/wifi-setting.page.ts":
/*!*********************************************************!*\
  !*** ./src/app/pages/wifi-setting/wifi-setting.page.ts ***!
  \*********************************************************/
/*! exports provided: WifiSettingPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "WifiSettingPage", function() { return WifiSettingPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");



let WifiSettingPage = class WifiSettingPage {
    constructor(route, router) {
        this.route = route;
        this.router = router;
        this.passwordType = 'password';
        this.passwordIcon = 'eye-off';
        this.queryParams = this.route.snapshot.queryParams;
    }
    ngOnInit() {
    }
    hideShowPassword() {
        this.passwordType = this.passwordType === 'text' ? 'password' : 'text';
        this.passwordIcon = this.passwordIcon === 'eye-off' ? 'eye' : 'eye-off';
    }
    goWifiPush() {
        const param = {
            code: this.queryParams.code,
            name: this.queryParams.name,
            ssid: this.ssid,
            password: this.password
        };
        this.router.navigate(['/wifi-push'], { queryParams: param });
    }
};
WifiSettingPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] }
];
WifiSettingPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-wifi-setting',
        template: __webpack_require__(/*! raw-loader!./wifi-setting.page.html */ "./node_modules/raw-loader/index.js!./src/app/pages/wifi-setting/wifi-setting.page.html"),
        styles: [__webpack_require__(/*! ./wifi-setting.page.scss */ "./src/app/pages/wifi-setting/wifi-setting.page.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"],
        _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]])
], WifiSettingPage);



/***/ })

}]);
//# sourceMappingURL=pages-wifi-setting-wifi-setting-module-es2015.js.map